package com.gameframes.app

import android.content.Context

/** One-shot root helpers (only used when the person says they are a root user). */
object RootTools {

    /** True when a root shell is really available (KernelSU / Magisk asked and allowed it). */
    fun hasRoot(): Boolean = run("id").contains("uid=0")

    /**
     * Grants permissions without the system dialogs and protects the app during long games:
     * mic + notifications, overlay, screen-capture consent, battery whitelist, active standby bucket.
     */
    fun setup(c: Context): Boolean {
        val pkg = c.packageName
        val out = run(
            "id; " +
                "pm grant $pkg android.permission.RECORD_AUDIO; " +
                "pm grant $pkg android.permission.POST_NOTIFICATIONS; " +
                "appops set $pkg SYSTEM_ALERT_WINDOW allow; " +
                "appops set $pkg PROJECT_MEDIA allow; " +
                "cmd deviceidle whitelist +$pkg; " +
                "am set-standby-bucket $pkg active"
        )
        return out.contains("uid=0")
    }

    /** Turns an accessibility service on without opening Settings (root only). */
    fun enableAccessibility(component: String): Boolean {
        val cur = run("settings get secure enabled_accessibility_services").trim()
        val list = if (cur.isEmpty() || cur == "null") component
        else if (cur.split(':').contains(component)) cur else "$cur:$component"
        run("settings put secure enabled_accessibility_services '$list'; settings put secure accessibility_enabled 1")
        return run("settings get secure enabled_accessibility_services").contains(component)
    }

    private fun run(script: String): String = try {
        val p = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor()
        text
    } catch (_: Exception) {
        ""
    }
}
