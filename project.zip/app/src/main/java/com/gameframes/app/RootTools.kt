package com.gameframes.app

import android.content.Context

/** One-shot root helpers (only used when the person says they are a root user). */
object RootTools {

    /** True when a root shell is really available (KernelSU / Magisk asked and allowed it). */
    fun hasRoot(): Boolean = run("id").contains("uid=0")

    /**
     * Grants permissions without the system dialogs and protects the app during long games:
     * mic + notifications, overlay, screen-capture consent, battery whitelist, active standby bucket.
     */
    fun setup(c: Context): Boolean {
        val pkg = c.packageName
        val out = run(
            "id; " +
                "pm grant $pkg android.permission.RECORD_AUDIO; " +
                "pm grant $pkg android.permission.POST_NOTIFICATIONS; " +
                "appops set $pkg SYSTEM_ALERT_WINDOW allow; " +
                "appops set $pkg PROJECT_MEDIA allow; " +
                "cmd deviceidle whitelist +$pkg; " +
                "am set-standby-bucket $pkg active"
        )
        return out.contains("uid=0")
    }

    /** Runs a shell script as root and returns its output. */
    fun shell(script: String): String = run(script)

    private fun run(script: String): String = try {
        val p = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor()
        text
    } catch (_: Exception) {
        ""
    }
}
