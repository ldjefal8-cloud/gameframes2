package com.gameframes.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.min

/** Cyan, the idle colour of the game-panel look (turns red while recording, orange when the phone is hot). */
val RM_CYAN = Color.parseColor("#00E5FF")
val RM_TILE = Color.parseColor("#E63A3C41")
val RM_TILE_TEXT = Color.parseColor("#B8BAC2")

/**
 * Background of the side drawer in the "game space" style: near-black body whose inner side is cut in a
 * chevron, lit by a glowing accent edge made of a thin line plus short bright dashes.
 */
class RmEdgeBg(context: Context, private val right: Boolean) : View(context) {
    var accent = RM_CYAN
        set(v) { if (field != v) { field = v; invalidate() } }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun slant() = min(context.dp(44), (width * 0.16f).toInt())

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = slant().toFloat()
        val body = Path()
        val edge = Path()
        if (right) {
            body.moveTo(s, 0f); body.lineTo(w, 0f); body.lineTo(w, h); body.lineTo(s, h); body.lineTo(0f, h / 2f); body.close()
            edge.moveTo(s, 0f); edge.lineTo(0f, h / 2f); edge.lineTo(s, h)
        } else {
            body.moveTo(0f, 0f); body.lineTo(w - s, 0f); body.lineTo(w, h / 2f); body.lineTo(w - s, h); body.lineTo(0f, h); body.close()
            edge.moveTo(w - s, 0f); edge.lineTo(w, h / 2f); edge.lineTo(w - s, h)
        }
        fill.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#F2050607"), Color.parseColor("#F20D0F12"), Shader.TileMode.CLAMP)
        c.drawPath(body, fill)

        glow.strokeWidth = context.dp(8).toFloat()
        glow.color = (accent and 0x00FFFFFF) or 0x66000000
        glow.maskFilter = BlurMaskFilter(context.dp(9).toFloat(), BlurMaskFilter.Blur.NORMAL)
        c.drawPath(edge, glow)

        line.strokeWidth = context.dp(2).toFloat(); line.color = accent
        c.drawPath(edge, line)

        // bright dashes just inside the edge, like the lit segments of the real panel
        c.save()
        c.translate(if (right) context.dp(6).toFloat() else -context.dp(6).toFloat(), 0f)
        dash.strokeWidth = context.dp(4).toFloat()
        dash.color = (accent and 0x00FFFFFF) or 0xCC000000.toInt()
        dash.pathEffect = DashPathEffect(floatArrayOf(context.dp(14).toFloat(), context.dp(7).toFloat()), 0f)
        c.drawPath(edge, dash)
        c.restore()
    }
}

/**
 * The round "disk" gauge of the panel: big italic number, unit, a disk whose rim fills with the accent colour
 * according to the value, and a small caption underneath.
 */
class RmGauge(context: Context) : View(context) {
    var valueText = "–"
        set(v) { if (field != v) { field = v; invalidate() } }
    var unit = "°C"
    var caption = "BATTERY"
    var frac = 0f
        set(v) { if (field != v) { field = v; invalidate() } }
    var accent = RM_CYAN
        set(v) { if (field != v) { field = v; invalidate() } }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; color = Color.WHITE
        typeface = Typeface.create(Fonts.bold, Typeface.BOLD_ITALIC)
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; color = RM_TILE_TEXT
        typeface = Typeface.create(Fonts.medium, Typeface.ITALIC); letterSpacing = 0.18f
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val disk = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(104), context.dp(122))

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        num.textSize = context.dp(26).toFloat()
        c.drawText(valueText, cx, context.dp(28).toFloat(), num)
        small.textSize = context.dp(11).toFloat()
        c.drawText(unit, cx, context.dp(43).toFloat(), small)

        val cy = context.dp(80).toFloat()
        val rx = context.dp(46).toFloat(); val ry = context.dp(19).toFloat()
        ring.strokeWidth = context.dp(3).toFloat()
        ring.color = Color.parseColor("#55FFFFFF")
        c.drawOval(RectF(cx - rx, cy - ry, cx + rx, cy + ry), ring)
        // value arc on the rim
        ring.color = accent
        c.drawArc(RectF(cx - rx, cy - ry, cx + rx, cy + ry), -90f, 360f * frac.coerceIn(0f, 1f), false, ring)
        ring.strokeWidth = context.dp(2).toFloat()
        ring.color = Color.parseColor("#33FFFFFF")
        c.drawOval(RectF(cx - rx * 0.74f, cy - ry * 0.74f, cx + rx * 0.74f, cy + ry * 0.74f), ring)
        disk.shader = LinearGradient(0f, cy - ry, 0f, cy + ry, Color.parseColor("#000000"), Color.parseColor("#2A2C30"), Shader.TileMode.CLAMP)
        c.drawOval(RectF(cx - rx * 0.6f, cy - ry * 0.6f, cx + rx * 0.6f, cy + ry * 0.6f), disk)

        small.textSize = context.dp(10).toFloat()
        c.drawText(caption, cx, context.dp(116).toFloat(), small)
    }
}
