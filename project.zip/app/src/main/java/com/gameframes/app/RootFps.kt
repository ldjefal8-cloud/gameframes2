package com.gameframes.app

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.math.roundToInt

/**
 * Measures the REAL frame rate of the foreground app (the game) by reading SurfaceFlinger's
 * frame timestamps through a root shell (`dumpsys SurfaceFlinger --latency`).
 * fps == -1 means "no data" (no root, or the game layer was not found).
 */
class RootFps {

    @Volatile var fps = -1
    @Volatile var ok = false

    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null
    @Volatile private var alive = true
    private var thread: Thread? = null

    fun start() {
        thread = Thread({ loop() }, "gf-rootfps").also {
            it.isDaemon = true
            it.start()
        }
    }

    fun stop() {
        alive = false
        try { out?.write("exit\n"); out?.flush() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
    }

    private fun sh(cmd: String): String {
        val o = out ?: return ""
        val i = inp ?: return ""
        val mark = "__GF_END__"
        o.write("$cmd\necho $mark\n")
        o.flush()
        val sb = StringBuilder()
        while (true) {
            val l = i.readLine() ?: break
            if (l == mark) break
            sb.append(l).append('\n')
        }
        return sb.toString()
    }

    private fun loop() {
        try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            proc = p
            out = BufferedWriter(OutputStreamWriter(p.outputStream))
            inp = BufferedReader(InputStreamReader(p.inputStream))
            if (!sh("id").contains("uid=0")) return
            ok = true
            // keep the recorder alive while a heavy game eats the RAM, and exempt it from doze
            sh("echo -900 > /proc/${android.os.Process.myPid()}/oom_score_adj")
            sh("cmd deviceidle whitelist +com.gameframes.app")

            var layer = ""
            var tick = 0
            var misses = 0
            while (alive) {
                // the expensive lookups (dumpsys window / --list) run rarely; --latency is cheap
                if (layer.isEmpty() || misses >= 3 || tick % 20 == 0) {
                    val pkg = focusedPackage()
                    if (pkg.isNotEmpty()) layer = findLayer(pkg)
                    misses = 0
                }
                tick++
                val v = if (layer.isEmpty()) -1 else measure(layer)
                fps = v
                if (v <= 0) misses++ else misses = 0
                Thread.sleep(1500)
            }
        } catch (_: Exception) {
            // keep the app working without the real-FPS reading
        } finally {
            stop()
        }
    }

    private val winRe = Regex("""\s([A-Za-z0-9_.]+)/[A-Za-z0-9_.$]+""")

    private fun focusedPackage(): String {
        val text = sh("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        for (line in text.lines()) {
            val m = winRe.find(line) ?: continue
            val pkg = m.groupValues[1]
            if (pkg != "com.gameframes.app" && pkg != "com.android.systemui") return pkg
        }
        return ""
    }

    private fun findLayer(pkg: String): String {
        val names = sh("dumpsys SurfaceFlinger --list").lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.contains("Background for") }
        return names.firstOrNull { it.startsWith("SurfaceView") && it.contains("BLAST") }
            ?: names.firstOrNull { it.startsWith("SurfaceView") }
            ?: names.firstOrNull { it.contains("BLAST") }
            ?: names.firstOrNull()
            ?: ""
    }

    private fun measure(layer: String): Int {
        val safe = layer.replace("'", "'\\''")
        val lines = sh("dumpsys SurfaceFlinger --latency '$safe'").lines()
        val now = System.nanoTime()               // same clock (CLOCK_MONOTONIC) as SurfaceFlinger
        val times = ArrayList<Long>()
        for (l in lines.drop(1)) {
            val parts = l.trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t >= 9_000_000_000_000_000_000L) continue
            if (t >= now - 1_000_000_000L && t <= now + 200_000_000L) times.add(t)
        }
        if (times.size < 2) return times.size
        val span = times.maxOrNull()!! - times.minOrNull()!!
        if (span <= 0L) return -1
        return ((times.size - 1) * 1_000_000_000.0 / span).roundToInt()
    }
}
