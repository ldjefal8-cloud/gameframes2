package com.gameframes.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

/**
 * "Hidden from the video" without the black squares that FLAG_SECURE leaves behind.
 * While one of our panels is open during a recording (and the person chose "hidden from video"),
 * the recorder stops taking new frames, so the video simply keeps the last clean frame until the panel is
 * closed. Panels register here when they open/close; the screen recorder does the freezing.
 */
object VideoMask {
    private val holders = HashSet<String>()
    private var sent = false
    private val h = Handler(Looper.getMainLooper())

    /** Freezes the video first (if needed), then runs [add] so no frame with the panel ever reaches the file. */
    fun open(c: Context, key: String, add: () -> Unit) {
        set(c, key, true)
        if (needed(c)) h.postDelayed({ add() }, 90) else add()
    }

    /** Call after the panel window was removed: the video resumes a moment later, on a clean screen. */
    fun close(c: Context, key: String) {
        if (!holders.contains(key)) return
        h.postDelayed({ set(c, key, false) }, 160)
    }

    fun set(c: Context, key: String, open: Boolean) {
        if (open) holders.add(key) else holders.remove(key)
        update(c)
    }

    /** True when a panel opened now would end up in the video, i.e. the freeze is needed before showing it. */
    fun needed(c: Context) = RecorderService.running && Prefs.bubbleVideoMode(c) in 1..2

    /** Also called from the services' periodic ticks, so a recording that starts/stops mid-panel stays correct. */
    fun update(c: Context) {
        if (!RecorderService.running) { sent = false; return }
        val want = holders.isNotEmpty() && Prefs.bubbleVideoMode(c) in 1..2 && !RecorderService.paused
        if (want == sent) return
        sent = want
        try {
            c.startService(
                Intent(c, RecorderService::class.java)
                    .setAction(if (want) RecorderService.ACTION_FREEZE else RecorderService.ACTION_UNFREEZE)
            )
        } catch (_: Exception) {}
    }
}
