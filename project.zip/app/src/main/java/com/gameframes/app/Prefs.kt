package com.gameframes.app

import android.content.Context
import android.content.Intent

/** Saved settings, shared by the app screen, the floating button and the capture activity. */
object Prefs {
    val HEIGHTS = listOf(720, 1080, 1440, 2160, 0)                 // short side in px, 0 = native
    val FPS_LIST = listOf(24, 30, 45, 60, 90, 120, 144)
    val BITRATES = listOf(0, 2, 4, 6, 8, 12, 16, 20, 30, 40, 60, 80, 100)  // Mbps, 0 = auto
    val SPLITS = listOf(0, 10, 20, 30, 60)                         // minutes, 0 = never split
    val DELAYS = listOf(0, 3, 5, 10)

    // user type: 0 = not chosen yet, 1 = normal, 2 = root
    const val K_MODE = "mode"
    const val K_QUALITY = "q"
    const val K_FPS = "fps"
    const val K_BITRATE = "br"
    const val K_ORIENT = "orient"
    const val K_AUDIO = "audio"
    const val K_DELAY = "delay"
    const val K_SPLIT = "split"
    const val K_PRESET = "preset"
    const val K_OVERLAY = "overlay"
    const val K_BUBBLE = "bubble"
    const val K_HIDE_BUBBLE = "hidebubble"
    const val K_ROOT_FEATURES = "rootfeat"
    const val K_BUBBLE_VIDEO = "bvid"      // 0 always visible, 1 hidden from the video only, 2 hidden while recording
    const val K_BUBBLE_X = "bx"
    const val K_BUBBLE_Y = "by"
    const val K_CODEC = "codec"            // 0 auto, 1 H.264, 2 HEVC (H.265)

    // standalone FPS meter
    const val K_FPS_ON = "fpson"
    const val K_FPS_REC_LINE = "fpsrec"    // also show REC fps while recording
    const val K_FPS_SIZE = "fpssize"       // text size sp
    const val K_FPS_X = "fx"
    const val K_FPS_Y = "fy"
    const val K_HUD_TEMP = "hudtemp"       // show battery temperature next to FPS
    const val K_HUD_BAT = "hudbat"         // show battery level next to FPS

    // crosshair
    const val K_XH_ON = "xhon"
    const val K_XH_SHAPE = "xhshape"
    const val K_XH_SIZE = "xhsize"         // dp
    const val K_XH_THICK = "xhthick"       // tenths of dp
    const val K_XH_GAP = "xhgap"           // dp
    const val K_XH_ALPHA = "xhalpha"       // 10..100
    const val K_XH_COLOR = "xhcolor"
    const val K_XH_DX = "xhdx"
    const val K_XH_DY = "xhdy"
    const val K_XH_OUTLINE = "xhoutline"
    const val K_XH_STEP = "xhstep"         // index into XH_STEPS: how far one nudge moves the crosshair
    const val K_XHP_X = "xpx"              // position of the on-game crosshair panel
    const val K_XHP_Y = "xpy"
    val XH_STEPS = listOf(1, 2, 5, 10, 20)  // dp per nudge
    val XH_COLORS = listOf(0xFF30D158.toInt(), 0xFFFF453A.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD60A.toInt(),
        0xFF0A84FF.toInt(), 0xFFFF2D92.toInt(), 0xFF00E5FF.toInt(), 0xFFBF5AF2.toInt())

    // auto clicker
    val CL_INTERVALS = listOf(20, 30, 50, 80, 100, 150, 200, 300, 500, 1000, 2000, 5000)   // ms between taps
    val CL_DURS = listOf(10, 30, 60, 100, 300, 800)                                        // ms a tap is held
    val CL_RND = listOf(0, 10, 25, 50)                                                     // % random interval
    val CL_JIT = listOf(0, 2, 5, 10)                                                       // px random offset
    val CL_MAX = listOf(0, 10, 50, 100, 500, 1000)                                         // stop after N taps, 0 = never
    val CL_SEC = listOf(0, 10, 30, 60, 300)                                                // stop after N seconds
    val CL_DELAY = listOf(0, 1, 3, 5)                                                      // countdown before start
    val CL_SIZES = listOf(36, 48, 60, 72)                                                  // marker size dp
    const val K_CL_INT = "clint"       // indexes into the lists above
    const val K_CL_DUR = "cldur"
    const val K_CL_RND = "clrnd"
    const val K_CL_JIT = "cljit"
    const val K_CL_MAX = "clmax"
    const val K_CL_SEC = "clsec"
    const val K_CL_DELAY = "cldelay"
    const val K_CL_SIZE = "clsize"
    const val K_CL_MODE = "clmode"     // 0 one after another, 1 all together, 2 swipe A -> B
    const val K_CL_N = "cln"           // how many markers (1..8)
    const val K_CL_MASK = "clmask"     // bit i set = marker i is on
    const val K_CL_HIDE = "clhide"     // hide the markers while it is tapping
    const val K_CL_BX = "clbx"
    const val K_CL_BY = "clby"
    const val K_CL_PX = "clpx"         // settings panel position
    const val K_CL_PY = "clpy"
    // side drawer (swipe from the screen edge, like a game space panel)
    const val K_SIDE_ON = "sideon"
    const val K_SIDE_EDGE = "sideedge"   // 0 left, 1 right
    const val K_SIDE_H = "sideh"         // handle height dp
    const val K_SIDE_Y = "sidey"         // handle distance from the top, dp
    const val K_SIDE_HINT = "sidehint"   // draw a thin line where the handle is
    const val K_KEEP_ON = "keepon"       // keep the screen awake while the side bar is on
    fun clX(i: Int) = "clx$i"
    fun clY(i: Int) = "cly$i"

    private fun sp(c: Context) = c.getSharedPreferences("gf", Context.MODE_PRIVATE)

    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun isRootUser(c: Context) = int(c, K_MODE, 0) == 2

    /** How the floating button behaves in the recorded video (old "hide while recording" switch maps to 2). */
    fun bubbleVideoMode(c: Context): Int {
        val v = int(c, K_BUBBLE_VIDEO, -1)
        return if (v in 0..2) v else if (bool(c, K_HIDE_BUBBLE, false)) 2 else 0
    }

    private fun idx(c: Context, k: String, d: Int, size: Int) = int(c, k, d).coerceIn(0, size - 1)

    /** Intent that starts [RecorderService] with the saved settings. */
    fun recorderIntent(c: Context, code: Int, data: Intent, delayOverride: Int? = null): Intent =
        Intent(c, RecorderService::class.java)
            .setAction(RecorderService.ACTION_START)
            .putExtra("code", code)
            .putExtra("data", data)
            .putExtra("height", HEIGHTS[idx(c, K_QUALITY, 1, HEIGHTS.size)])
            .putExtra("fps", FPS_LIST[idx(c, K_FPS, 3, FPS_LIST.size)])
            .putExtra("bitrate", BITRATES[idx(c, K_BITRATE, 0, BITRATES.size)] * 1_000_000)
            .putExtra("orient", idx(c, K_ORIENT, 0, 3))
            .putExtra("audio", idx(c, K_AUDIO, 1, 4))
            .putExtra("delay", delayOverride ?: DELAYS[idx(c, K_DELAY, 1, DELAYS.size)])
            .putExtra("split", SPLITS[idx(c, K_SPLIT, 3, SPLITS.size)])
            .putExtra("codec", idx(c, K_CODEC, 0, 3))
            .putExtra("rootfps", false)
}
