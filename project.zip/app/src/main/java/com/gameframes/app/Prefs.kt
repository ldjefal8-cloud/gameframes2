package com.gameframes.app

import android.content.Context
import android.content.Intent

/** Saved settings, shared by the app screen, the floating button and the capture activity. */
object Prefs {
    val HEIGHTS = listOf(720, 1080, 1440, 2160, 0)                 // short side in px, 0 = native
    val FPS_LIST = listOf(24, 30, 45, 60, 90, 120, 144)
    val BITRATES = listOf(0, 2, 4, 6, 8, 12, 16, 20, 30, 40, 60, 80, 100)  // Mbps, 0 = auto
    val SPLITS = listOf(0, 10, 20, 30, 60)                         // minutes, 0 = never split
    val DELAYS = listOf(0, 3, 5, 10)

    // user type: 0 = not chosen yet, 1 = normal, 2 = root
    const val K_MODE = "mode"
    const val K_QUALITY = "q"
    const val K_FPS = "fps"
    const val K_BITRATE = "br"
    const val K_ORIENT = "orient"
    const val K_AUDIO = "audio"
    const val K_DELAY = "delay"
    const val K_SPLIT = "split"
    const val K_PRESET = "preset"
    const val K_OVERLAY = "overlay"
    const val K_BUBBLE = "bubble"
    const val K_HIDE_BUBBLE = "hidebubble"
    const val K_ROOT_FEATURES = "rootfeat"
    const val K_BUBBLE_X = "bx"
    const val K_BUBBLE_Y = "by"

    private fun sp(c: Context) = c.getSharedPreferences("gf", Context.MODE_PRIVATE)

    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun isRootUser(c: Context) = int(c, K_MODE, 0) == 2

    private fun idx(c: Context, k: String, d: Int, size: Int) = int(c, k, d).coerceIn(0, size - 1)

    /** Intent that starts [RecorderService] with the saved settings. */
    fun recorderIntent(c: Context, code: Int, data: Intent, delayOverride: Int? = null): Intent =
        Intent(c, RecorderService::class.java)
            .setAction(RecorderService.ACTION_START)
            .putExtra("code", code)
            .putExtra("data", data)
            .putExtra("height", HEIGHTS[idx(c, K_QUALITY, 1, HEIGHTS.size)])
            .putExtra("fps", FPS_LIST[idx(c, K_FPS, 3, FPS_LIST.size)])
            .putExtra("bitrate", BITRATES[idx(c, K_BITRATE, 0, BITRATES.size)] * 1_000_000)
            .putExtra("orient", idx(c, K_ORIENT, 0, 3))
            .putExtra("audio", idx(c, K_AUDIO, 1, 4))
            .putExtra("delay", delayOverride ?: DELAYS[idx(c, K_DELAY, 1, DELAYS.size)])
            .putExtra("split", SPLITS[idx(c, K_SPLIT, 3, SPLITS.size)])
            .putExtra("overlay", bool(c, K_OVERLAY, true))
            .putExtra("rootfps", isRootUser(c) && bool(c, K_ROOT_FEATURES, true))
}
