package com.gameframes.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * Side panel (like Red Magic's game panel).
 * An almost invisible strip on the screen edge; swipe inward from it and a panel with the tools opens.
 *
 * "Hide from video": while recording, the floating button is gone and the strip draws nothing, so the
 * video has no icon and no black square. If the panel is opened during that time the recording is
 * paused automatically and resumed when the panel closes, so the panel never ends up in the video.
 */
class EdgeService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.edge.close"
        private const val CHANNEL = "edge"
        @Volatile var instance: EdgeService? = null
        val alive get() = instance != null
        fun reload() { instance?.apply { handler.post { rebuildStrip(); applyAwake() } } }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var strip: View? = null
    private var stripLp: WindowManager.LayoutParams? = null
    private var panelRoot: FrameLayout? = null
    private var awakeView: View? = null
    private var pausedByUs = false

    private class TileRef(val view: LinearLayout, val active: () -> Boolean)
    private val tiles = ArrayList<TileRef>()
    private var infoText: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updateStripLook()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_EDGE_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات»", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        try { startFg() } catch (e: Exception) {
            Toast.makeText(this, "تعذّر تشغيل القائمة الجانبية: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        rebuildStrip()
        applyAwake()
        handler.post(tick)
        return START_NOT_STICKY
    }

    // ---------------- edge strip ----------------

    private fun hidingFromVideo() = RecorderService.running && Prefs.bool(this, Prefs.K_HIDE_BUBBLE, false)

    private fun rebuildStrip() {
        strip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        strip = null
        val side = Prefs.int(this, Prefs.K_EDGE_SIDE, 0)
        val pct = Prefs.int(this, Prefs.K_EDGE_SIZE, 35).coerceIn(10, 100)
        val dm = realMetrics()

        val v = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(3).toFloat()
                setColor(Color.parseColor("#59FFFFFF"))
            }
        }
        val p = WindowManager.LayoutParams(
            dp(14), dm.heightPixels * pct / 100,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = (if (side == 0) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL }

        var x0 = 0f; var y0 = 0f; var opened = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; opened = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val inward = if (side == 0) e.rawX - x0 else x0 - e.rawX
                    if (!opened && inward > dp(24) && abs(e.rawY - y0) < inward * 1.6f) {
                        opened = true
                        openPanel()
                    }
                    true
                }
                else -> true
            }
        }
        stripLp = p; strip = v
        try { wm.addView(v, p) } catch (_: Exception) { strip = null }
        updateStripLook()
    }

    /** The strip is a faint pill; while recording with "hide from video" it draws nothing at all. */
    private fun updateStripLook() {
        val v = strip ?: return
        val a = if (hidingFromVideo()) 0f else 1f
        if (v.alpha != a) v.alpha = a
    }

    // ---------------- panel ----------------

    private fun openPanel() {
        if (panelRoot != null) return
        if (hidingFromVideo() && Prefs.bool(this, Prefs.K_EDGE_PAUSE, true) &&
            RecorderService.running && !RecorderService.paused
        ) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PAUSE))
            pausedByUs = true
            handler.postDelayed({ attachPanel() }, 180)
        } else {
            attachPanel()
        }
    }

    private fun closePanel() {
        val r = panelRoot ?: return
        panelRoot = null
        tiles.clear()
        infoText = null
        try { wm.removeView(r) } catch (_: Exception) {}
        if (pausedByUs) {
            pausedByUs = false
            handler.postDelayed({
                if (RecorderService.running && RecorderService.paused) {
                    startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_RESUME))
                }
            }, 220)
        }
    }

    private fun attachPanel() {
        if (panelRoot != null) return
        val side = Prefs.int(this, Prefs.K_EDGE_SIDE, 0)
        val dm = realMetrics()
        val panelW = minOf(dp(320), dm.widthPixels * 8 / 10)

        val root = FrameLayout(this)
        val scrim = View(this).apply {
            setBackgroundColor(Color.parseColor("#66000000"))
            setOnClickListener { closePanel() }
        }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val r = dp(26).toFloat()
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101014"))
                setStroke(dp(1), GLASS_EDGE_BOT)
                cornerRadii = if (side == 0) floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f) else floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            }
            setPadding(dp(14), dp(18), dp(14), dp(14))
        }

        // header
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Game Frames", 19f, Color.WHITE).apply { typeface = Fonts.bold(context) },
            LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(glassCircle(28, IconView.CLOSE, Color.parseColor("#33FFFFFF")).apply { setOnClickListener { closePanel() } },
            LinearLayout.LayoutParams(dp(28), dp(28)))
        card.addView(head)
        val info = label("", 12f, LABEL2).apply { setPadding(0, dp(2), 0, dp(10)) }
        infoText = info
        card.addView(info)

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buildTiles(body)
        body.addView(caption("إعدادات القائمة"))
        body.addView(ChipRow(this, listOf("على اليسار", "على اليمين"), Prefs.int(this, Prefs.K_EDGE_SIDE, 0).coerceIn(0, 1)) {
            Prefs.setInt(this, Prefs.K_EDGE_SIDE, it)
            closePanel(); reload()
        })
        body.addView(sliderRow("ارتفاع منطقة السحب", 10, 100, Prefs.int(this, Prefs.K_EDGE_SIZE, 35), "%") {
            Prefs.setInt(this, Prefs.K_EDGE_SIZE, it)
            handler.removeCallbacks(reloadRun); handler.postDelayed(reloadRun, 400)
        })
        body.addView(switchRow("إيقاف التسجيل مؤقتًا أثناء فتح القائمة", "عند «إخفاء من الفيديو» حتى لا تظهر القائمة في الفيديو",
            Prefs.bool(this, Prefs.K_EDGE_PAUSE, true)) { on -> Prefs.setBool(this, Prefs.K_EDGE_PAUSE, on); true })
        card.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(body)
        }, LinearLayout.LayoutParams(-1, 0, 1f))

        val cp = FrameLayout.LayoutParams(panelW, -1, if (side == 0) Gravity.START else Gravity.END)
        root.addView(card, cp)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try { wm.addView(root, p) } catch (_: Exception) { return }
        panelRoot = root

        card.translationX = if (side == 0) -panelW.toFloat() else panelW.toFloat()
        card.animate().translationX(0f).setDuration(180).start()
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(180).start()

        refreshInfo()
        refreshTiles()
    }

    private val reloadRun = Runnable { reload() }

    private fun refreshInfo() {
        val t = infoText ?: return
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        var batt = ""
        if (bi != null) {
            val lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10.0
            if (lvl >= 0) batt += "البطارية ${lvl * 100 / scale}%"
            if (temp > 0) batt += "  ·  %.1f°C".format(temp)
        }
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = "  ·  الذاكرة الحرة ${mi.availMem / 1048576} MB"
        t.text = batt + ram
    }

    private fun refreshTiles() {
        for (t in tiles) {
            val on = try { t.active() } catch (_: Exception) { false }
            t.view.background = if (on) rounded(Color.parseColor("#660A84FF"), 16, IOS_BLUE, 1)
            else rounded(Color.parseColor("#26FFFFFF"), 16, GLASS_EDGE_BOT, 1)
        }
    }

    private fun makeTile(kind: Int, text: String, active: () -> Boolean, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(11), dp(4), dp(9))
        }
        t.addView(IconView(this, kind, Color.WHITE), LinearLayout.LayoutParams(dp(30), dp(30)))
        t.addView(label(text, 11f, Color.WHITE).apply { gravity = Gravity.CENTER; maxLines = 2 },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
        t.setOnClickListener {
            onClick()
            handler.postDelayed({ refreshTiles() }, 350)
        }
        tiles.add(TileRef(t, active))
        return t
    }

    private fun buildTiles(body: LinearLayout) {
        val list = ArrayList<LinearLayout>()

        list += makeTile(IconView.REC, "تسجيل / إنهاء", { RecorderService.running }) {
            pausedByUs = false
            if (RecorderService.running) {
                startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            } else {
                closePanel()
                handler.postDelayed({
                    startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }, 250)
            }
        }
        list += makeTile(IconView.PAUSE, "إيقاف مؤقت", { RecorderService.running && RecorderService.paused }) {
            if (RecorderService.running) {
                pausedByUs = false
                val a = if (RecorderService.paused) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE
                startService(Intent(this, RecorderService::class.java).setAction(a))
            } else Toast.makeText(this, "لا يوجد تسجيل شغّال", Toast.LENGTH_SHORT).show()
        }
        list += makeTile(IconView.SCREEN, "الزر العائم", { BubbleService.alive }) {
            if (BubbleService.alive) {
                Prefs.setBool(this, Prefs.K_BUBBLE, false)
                stopService(Intent(this, BubbleService::class.java))
            } else {
                Prefs.setBool(this, Prefs.K_BUBBLE, true)
                startForegroundService(Intent(this, BubbleService::class.java))
            }
        }
        list += makeTile(IconView.FPS, "عدّاد FPS", { FpsOverlayService.alive }) {
            if (FpsOverlayService.alive) {
                Prefs.setBool(this, Prefs.K_FPS_ON, false)
                stopService(Intent(this, FpsOverlayService::class.java))
            } else {
                Prefs.setBool(this, Prefs.K_FPS_ON, true)
                if (Prefs.isRootUser(this)) {
                    startForegroundService(Intent(this, FpsOverlayService::class.java))
                } else {
                    closePanel()
                    startActivity(Intent(this, CaptureActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("fps", true))
                }
            }
        }
        list += makeTile(IconView.CROSS, "كروس هير", { CrosshairService.alive }) {
            if (CrosshairService.alive) {
                Prefs.setBool(this, Prefs.K_XH_ON, false)
                stopService(Intent(this, CrosshairService::class.java))
            } else {
                Prefs.setBool(this, Prefs.K_XH_ON, true)
                startForegroundService(Intent(this, CrosshairService::class.java))
            }
        }
        list += makeTile(IconView.TAP, "لوحة النقر التلقائي", { ClickerService.alive }) {
            if (ClickerService.alive) {
                Prefs.setBool(this, Prefs.K_AC_ON, false)
                stopService(Intent(this, ClickerService::class.java))
            } else {
                Prefs.setBool(this, Prefs.K_AC_ON, true)
                startForegroundService(Intent(this, ClickerService::class.java))
            }
        }
        list += makeTile(IconView.PLAY, "تشغيل / إيقاف النقر", { ClickerService.running }) {
            if (!ClickerService.alive) {
                Toast.makeText(this, "شغّل لوحة النقر التلقائي أولًا", Toast.LENGTH_SHORT).show()
            } else {
                closePanel()
                handler.postDelayed({ ClickerService.toggle() }, 250)
            }
        }
        list += makeTile(IconView.EYE_OFF, "إخفاء من الفيديو", { Prefs.bool(this, Prefs.K_HIDE_BUBBLE, false) }) {
            Prefs.setBool(this, Prefs.K_HIDE_BUBBLE, !Prefs.bool(this, Prefs.K_HIDE_BUBBLE, false))
        }
        list += makeTile(IconView.SCREEN, "إبقاء الشاشة مضاءة", { Prefs.bool(this, Prefs.K_KEEP_AWAKE, false) }) {
            Prefs.setBool(this, Prefs.K_KEEP_AWAKE, !Prefs.bool(this, Prefs.K_KEEP_AWAKE, false))
            applyAwake()
        }
        list += makeTile(IconView.BOLT, "تنظيف الذاكرة (روت)", { false }) {
            if (Prefs.isRootUser(this)) {
                Toast.makeText(this, "جارٍ تنظيف الذاكرة…", Toast.LENGTH_SHORT).show()
                Thread {
                    RootTools.shell("sync; echo 3 > /proc/sys/vm/drop_caches; am kill-all")
                    handler.post { refreshInfo(); Toast.makeText(this, "تم", Toast.LENGTH_SHORT).show() }
                }.start()
            } else {
                Toast.makeText(this, "هذه الميزة تحتاج وضع الروت", Toast.LENGTH_SHORT).show()
            }
        }
        list += makeTile(IconView.CHEVRON, "فتح التطبيق", { false }) {
            closePanel()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        var i = 0
        while (i < list.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            for (j in 0 until 3) {
                val lp = LinearLayout.LayoutParams(0, dp(82), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                if (i + j < list.size) row.addView(list[i + j], lp) else row.addView(View(this), lp)
            }
            body.addView(row)
            i += 3
        }
    }

    // ---------------- keep screen awake ----------------

    private fun applyAwake() {
        val want = Prefs.bool(this, Prefs.K_KEEP_AWAKE, false)
        if (want && awakeView == null) {
            val v = View(this)
            val p = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            try { wm.addView(v, p); awakeView = v } catch (_: Exception) {}
        } else if (!want && awakeView != null) {
            try { wm.removeView(awakeView) } catch (_: Exception) {}
            awakeView = null
        }
    }

    // ---------------- service plumbing ----------------

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Side panel", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 10,
            Intent(this, EdgeService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("القائمة الجانبية شغّالة: اسحب من حافة الشاشة")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(6, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(6, n)
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        panelRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelRoot = null
        strip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        strip = null
        awakeView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        awakeView = null
        if (pausedByUs && RecorderService.running && RecorderService.paused) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_RESUME))
        }
        super.onDestroy()
    }
}
