package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Draggable floating control over any app/game:
 *  - tap the bubble to open the controls,
 *  - idle: ▶ start recording, recording: ⏸ pause / ▶ resume and ■ end.
 * Very light: a few plain views, refreshed twice a second.
 */
class BubbleService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.bubble.close"
        private const val CHANNEL = "bubble"
        @Volatile var alive = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var main: TextView
    private lateinit var btnA: TextView
    private lateinit var btnB: TextView
    private lateinit var btnX: TextView
    private var expanded = false

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        alive = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBubble()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_MIN)
        )
        val close = PendingIntent.getService(
            this, 5,
            Intent(this, BubbleService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("الزر العائم شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إغلاق الزر", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
    }

    private fun circle(text: String, bg: Int, sizeDp: Int, textSp: Float): TextView =
        TextView(this).apply {
            this.text = text
            textSize = textSp
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(bg, sizeDp / 2)
            minWidth = dp(sizeDp)
            minHeight = dp(sizeDp)
        }

    private fun buildBubble() {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        main = circle("●", 0xE6121821.toInt(), 46, 15f).apply { setTextColor(Color.parseColor("#ef4444")) }
        btnA = circle("▶", 0xE62563EB.toInt(), 42, 16f)
        btnB = circle("■", 0xE6B91C1C.toInt(), 42, 16f)
        btnX = circle("✕", 0xE6374151.toInt(), 34, 13f)

        fun lpOf() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(4), 0, dp(4), 0) }
        b.addView(main, lpOf())
        b.addView(btnA, lpOf())
        b.addView(btnB, lpOf())
        b.addView(btnX, lpOf())

        btnA.setOnClickListener { onA() }
        btnB.setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            setExpanded(false)
        }
        btnX.setOnClickListener {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopSelf()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = Prefs.int(this@BubbleService, Prefs.K_BUBBLE_X, dp(8))
            y = Prefs.int(this@BubbleService, Prefs.K_BUBBLE_Y, dp(220))
        }
        lp = params

        // drag by the main circle; a short tap opens / closes the controls
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        main.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = sx + dx.toInt()
                        params.y = sy + dy.toInt()
                        try { wm.updateViewLayout(b, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.K_BUBBLE_X, params.x)
                        Prefs.setInt(this, Prefs.K_BUBBLE_Y, params.y)
                    } else {
                        setExpanded(!expanded)
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(b, params)
            box = b
        } catch (_: Exception) {
            box = null
            stopSelf()
        }
        refresh()
    }

    private fun onA() {
        when {
            !RecorderService.running -> {
                startActivity(
                    Intent(this, CaptureActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                setExpanded(false)
            }
            RecorderService.paused -> {
                startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_RESUME))
            }
            else -> {
                startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PAUSE))
            }
        }
    }

    private fun setExpanded(v: Boolean) {
        expanded = v
        refresh()
    }

    private fun refresh() {
        val b = box ?: return
        val running = RecorderService.running
        val paused = RecorderService.paused

        // optionally hide the bubble while recording so it never appears in the video
        val hide = running && !paused && Prefs.bool(this, Prefs.K_HIDE_BUBBLE, false)
        b.visibility = if (hide) View.GONE else View.VISIBLE

        if (running) {
            val s = RecorderService.recordedSec()
            main.text = if (paused) "⏸" else "%02d:%02d".format(s / 60, s % 60)
            main.textSize = if (paused) 15f else 11f
            main.setTextColor(if (paused) Color.parseColor("#fbbf24") else Color.parseColor("#ef4444"))
        } else {
            main.text = "●"
            main.textSize = 15f
            main.setTextColor(Color.parseColor("#4ade80"))
        }

        btnA.text = when {
            !running -> "▶"
            paused -> "▶"
            else -> "⏸"
        }
        btnA.visibility = if (expanded) View.VISIBLE else View.GONE
        btnB.visibility = if (expanded && running) View.VISIBLE else View.GONE
        btnX.visibility = if (expanded && !running) View.VISIBLE else View.GONE
        // keep the bubble on screen when the layout width changes
        try { lp?.let { wm.updateViewLayout(b, it) } } catch (_: Exception) {}
    }

    override fun onDestroy() {
        alive = false
        handler.removeCallbacks(tick)
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }
}
