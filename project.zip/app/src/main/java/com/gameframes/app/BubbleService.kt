package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Draggable floating control over any app/game:
 *  - tap the bubble to open the controls,
 *  - idle: ▶ start recording, recording: ⏸ pause / ▶ resume and ■ end.
 * Very light: a few plain views, refreshed twice a second.
 */
class BubbleService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.bubble.close"
        private const val CHANNEL = "bubble"
        @Volatile var alive = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var main: TextView
    private lateinit var mainIcon: IconView
    private lateinit var boxMain: FrameLayout
    private lateinit var fa: FrameLayout
    private lateinit var fb: FrameLayout
    private lateinit var fx: FrameLayout
    private lateinit var iconA: IconView
    private var expanded = false

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        alive = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBubble()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_MIN)
        )
        val close = PendingIntent.getService(
            this, 5,
            Intent(this, BubbleService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("الزر العائم شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إغلاق الزر", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
    }

    private fun buildBubble() {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                cornerRadius = dp(40).toFloat()
                setColor(Color.parseColor("#CC1C1C1E"))
                setStroke(dp(1), Color.parseColor("#40FFFFFF"))
            }
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        // main circle: record dot when idle, running time while recording (time lives here now)
        main = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 12f
            minWidth = dp(46); minHeight = dp(46)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#33FFFFFF"))
            }
        }
        mainIcon = IconView(this, IconView.REC, IOS_RED)
        val mainBox = FrameLayout(this).apply {
            addView(main, FrameLayout.LayoutParams(dp(46), dp(46)))
            addView(mainIcon, FrameLayout.LayoutParams(dp(46), dp(46)))
        }
        boxMain = mainBox
        fa = glassCircle(42, IconView.PLAY, IOS_BLUE)
        fb = glassCircle(42, IconView.STOP, IOS_RED)
        fx = glassCircle(34, IconView.CLOSE, Color.parseColor("#66787880"))
        iconA = fa.getChildAt(0) as IconView

        fun lpOf(sz: Int) = LinearLayout.LayoutParams(dp(sz), dp(sz)).apply { setMargins(dp(3), 0, dp(3), 0) }
        b.addView(mainBox, lpOf(46))
        b.addView(fa, lpOf(42))
        b.addView(fb, lpOf(42))
        b.addView(fx, lpOf(34))

        fa.setOnClickListener { onA() }
        fb.setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            setExpanded(false)
        }
        fx.setOnClickListener {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopSelf()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = Prefs.int(this@BubbleService, Prefs.K_BUBBLE_X, dp(8))
            y = Prefs.int(this@BubbleService, Prefs.K_BUBBLE_Y, dp(220))
        }
        lp = params

        // drag by the main circle; a short tap opens / closes the controls
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        mainBox.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = sx + dx.toInt()
                        params.y = sy + dy.toInt()
                        try { wm.updateViewLayout(b, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.K_BUBBLE_X, params.x)
                        Prefs.setInt(this, Prefs.K_BUBBLE_Y, params.y)
                    } else {
                        setExpanded(!expanded)
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(b, params)
            box = b
        } catch (_: Exception) {
            box = null
            stopSelf()
        }
        refresh()
    }

    private fun onA() {
        when {
            !RecorderService.running -> {
                startActivity(
                    Intent(this, CaptureActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                setExpanded(false)
            }
            RecorderService.paused -> {
                startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_RESUME))
            }
            else -> {
                startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_PAUSE))
            }
        }
    }

    private fun setExpanded(v: Boolean) {
        expanded = v
        refresh()
    }

    private fun refresh() {
        val b = box ?: return
        val running = RecorderService.running
        val paused = RecorderService.paused

        // optionally hide the bubble while recording so it never appears in the video
        val hide = running && !paused && Prefs.bool(this, Prefs.K_HIDE_BUBBLE, false)
        b.visibility = if (hide) View.GONE else View.VISIBLE

        if (running) {
            val s = RecorderService.recordedSec()
            main.text = "%02d:%02d".format(s / 60, s % 60)
            main.setTextColor(if (paused) IOS_ORANGE else IOS_RED)
            mainIcon.visibility = View.GONE
        } else {
            main.text = ""
            mainIcon.visibility = View.VISIBLE
            mainIcon.set(IconView.REC, IOS_RED)
        }

        iconA.set(if (running && !paused) IconView.PAUSE else IconView.PLAY, Color.WHITE)
        (fa.background as? GradientDrawable)?.setColor(
            if (running && !paused) Color.parseColor("#B3FF9F0A") else Color.parseColor("#E60A84FF")
        )
        fa.visibility = if (expanded) View.VISIBLE else View.GONE
        fb.visibility = if (expanded && running) View.VISIBLE else View.GONE
        fx.visibility = if (expanded && !running) View.VISIBLE else View.GONE
        try { lp?.let { wm.updateViewLayout(b, it) } } catch (_: Exception) {}
    }

    override fun onDestroy() {
        alive = false
        handler.removeCallbacks(tick)
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }
}
