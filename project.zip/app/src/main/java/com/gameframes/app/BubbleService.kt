package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.abs

/**
 * Draggable floating control over any app/game, shaped like the big record button:
 *  - collapsed: just the big round button (shows the running time while recording);
 *  - tap it to open the bar: pause / stop (while recording), crosshair settings, and ✕ to fold it back;
 *  - when the bar is open and nothing is recording, the big button starts a recording.
 * The ✕ only folds the bar; fully closing is done from the app switch or the notification action.
 * Very light: a few plain views, refreshed twice a second.
 */
class BubbleService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.bubble.close"
        private const val CHANNEL = "bubble"
        private const val BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        @Volatile var alive = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var rec: RecordButton
    private lateinit var bPause: FrameLayout
    private lateinit var bStop: FrameLayout
    private lateinit var bXh: FrameLayout
    private lateinit var bFold: FrameLayout
    private lateinit var pauseIcon: IconView
    private lateinit var pillBg: GradientDrawable
    private var panel: XhPanel? = null
    private var expanded = false

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (alive) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        alive = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBubble()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_MIN)
        )
        val close = PendingIntent.getService(
            this, 5,
            Intent(this, BubbleService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("الزر العائم شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إغلاق الزر", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
    }

    private fun buildBubble() {
        pillBg = GradientDrawable().apply {
            cornerRadius = dp(40).toFloat()
            setColor(Color.parseColor("#CC1C1C1E"))
            setStroke(dp(1), Color.parseColor("#40FFFFFF"))
        }
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        // the big round button (same look as the record button of the app)
        rec = RecordButton(this, 64)
        val recWrap = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1C1C1E"))
                setStroke(dp(1), Color.parseColor("#40FFFFFF"))
            }
            addView(rec, FrameLayout.LayoutParams(dp(64), dp(64)))
        }

        bPause = glassCircle(46, IconView.PAUSE, Color.parseColor("#B3FF9F0A"))
        pauseIcon = bPause.getChildAt(0) as IconView
        bStop = glassCircle(46, IconView.STOP, Color.parseColor("#B3FF453A"), Color.WHITE)
        bXh = glassCircle(42, IconView.CROSS, Color.parseColor("#66787880"))
        bFold = glassCircle(36, IconView.CLOSE, Color.parseColor("#66787880"))

        fun lpOf(sz: Int) = LinearLayout.LayoutParams(dp(sz), dp(sz)).apply { setMargins(dp(3), 0, dp(3), 0) }
        // the big button stays leftmost so it never jumps when the bar opens
        b.addView(recWrap, lpOf(64))
        b.addView(bPause, lpOf(46))
        b.addView(bStop, lpOf(46))
        b.addView(bXh, lpOf(42))
        b.addView(bFold, lpOf(36))

        bPause.setOnClickListener {
            val a = if (RecorderService.paused) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE
            startService(Intent(this, RecorderService::class.java).setAction(a))
        }
        bStop.setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            setExpanded(false)
        }
        bXh.setOnClickListener { togglePanel() }
        bFold.setOnClickListener { setExpanded(false) }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = Prefs.int(this@BubbleService, Prefs.K_BUBBLE_X, dp(8))
            y = Prefs.int(this@BubbleService, Prefs.K_BUBBLE_Y, dp(220))
        }
        lp = params

        // drag by the big button; a short tap uses it
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        recWrap.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = sx + dx.toInt()
                        params.y = sy + dy.toInt()
                        try { wm.updateViewLayout(b, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.K_BUBBLE_X, params.x)
                        Prefs.setInt(this, Prefs.K_BUBBLE_Y, params.y)
                    } else {
                        onBig()
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(b, params)
            box = b
        } catch (_: Exception) {
            box = null
            stopSelf()
        }
        refresh()
    }

    /** Collapsed: open the bar. Open + idle: start recording. Open + recording: fold the bar. */
    private fun onBig() {
        when {
            !expanded -> setExpanded(true)
            !RecorderService.running -> {
                startActivity(
                    Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                setExpanded(false)
            }
            else -> setExpanded(false)
        }
    }

    private fun togglePanel() {
        val p = panel
        if (p != null && p.shown) {
            p.hide()
            return
        }
        val np = p ?: XhPanel(this, wm).also { panel = it }
        np.show()
        refresh()
    }

    private fun setExpanded(v: Boolean) {
        expanded = v
        refresh()
    }

    private fun refresh() {
        val b = box ?: return
        val params = lp ?: return
        val running = RecorderService.running
        val paused = RecorderService.paused
        val mode = Prefs.bubbleVideoMode(this)
        val recording = running && !paused

        // 1 = visible to you but kept out of the video (secure window); 2 = hidden while recording
        params.flags = BASE_FLAGS or (if (mode == 1) WindowManager.LayoutParams.FLAG_SECURE else 0)
        b.visibility = if (recording && mode == 2) View.GONE else View.VISIBLE
        panel?.applyVideoMode(mode, recording)

        if (running) {
            val s = RecorderService.recordedSec()
            rec.state = if (paused) 2 else 1
            rec.timeText = "%02d:%02d".format(s / 60, s % 60)
        } else {
            rec.state = 0
            rec.timeText = null
        }

        pauseIcon.set(if (recording) IconView.PAUSE else IconView.PLAY, Color.WHITE)
        pillBg.setColor(Color.parseColor("#CC1C1C1E"))
        (bPause.background as? GradientDrawable)?.setColor(
            if (recording) Color.parseColor("#B3FF9F0A") else Color.parseColor("#E60A84FF")
        )
        b.background = if (expanded) pillBg else null
        bPause.visibility = if (expanded && running) View.VISIBLE else View.GONE
        bStop.visibility = if (expanded && running) View.VISIBLE else View.GONE
        bXh.visibility = if (expanded) View.VISIBLE else View.GONE
        bFold.visibility = if (expanded) View.VISIBLE else View.GONE
        panel?.sync()
        try { wm.updateViewLayout(b, params) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        alive = false
        handler.removeCallbacks(tick)
        panel?.hide()
        panel = null
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }
}
