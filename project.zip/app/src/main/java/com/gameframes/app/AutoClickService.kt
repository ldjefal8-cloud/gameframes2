package com.gameframes.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Performs the taps. Android only lets an app tap on top of other apps through an accessibility
 * service. It never reads the screen (canRetrieveWindowContent = false, no events).
 */
class AutoClickService : AccessibilityService() {

    companion object {
        @Volatile var instance: AutoClickService? = null
        val enabled get() = instance != null
    }

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** One tap on every point at the same moment. Returns false if Android refused the gesture. */
    fun tap(points: List<Pair<Float, Float>>, holdMs: Long, done: (Boolean) -> Unit): Boolean {
        if (points.isEmpty()) return false
        val b = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        for ((x, y) in points.take(max)) {
            val path = Path().apply { moveTo(x, y); lineTo(x, y) }
            b.addStroke(GestureDescription.StrokeDescription(path, 0L, holdMs.coerceAtLeast(1L)))
        }
        return try {
            dispatchGesture(b.build(), object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { done(true) }
                override fun onCancelled(g: GestureDescription?) { done(false) }
            }, null)
        } catch (_: Exception) { false }
    }
}
