package com.gameframes.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.view.accessibility.AccessibilityEvent

/**
 * Only job: perform the taps / swipes the auto clicker asks for, at the places the person chose.
 * It never reads the screen content (no events are used). Turned on once from Accessibility settings.
 */
class ClickerAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: ClickerAccessibilityService? = null
        val connected get() = instance != null
        const val COMPONENT = "com.gameframes.app/com.gameframes.app.ClickerAccessibilityService"
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    /** Takes a normal system screenshot (used by the side bar). */
    fun screenshot(): Boolean = try { performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) } catch (_: Exception) { false }

    /** Taps all [points] at the same moment, each held for [durMs]. [done] runs when the system finished it. */
    fun tap(points: List<PointF>, durMs: Long, done: () -> Unit): Boolean {
        val b = GestureDescription.Builder()
        val n = points.size.coerceAtMost(GestureDescription.getMaxStrokeCount())
        for (i in 0 until n) {
            val path = Path().apply { moveTo(points[i].x, points[i].y) }
            b.addStroke(GestureDescription.StrokeDescription(path, 0L, durMs.coerceAtLeast(1L)))
        }
        return send(b.build(), done)
    }

    fun swipe(a: PointF, bp: PointF, durMs: Long, done: () -> Unit): Boolean {
        val path = Path().apply { moveTo(a.x, a.y); lineTo(bp.x, bp.y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durMs.coerceAtLeast(1L)))
            .build()
        return send(g, done)
    }

    private fun send(g: GestureDescription, done: () -> Unit): Boolean = try {
        dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done() }
        }, null)
    } catch (_: Exception) {
        false
    }
}
