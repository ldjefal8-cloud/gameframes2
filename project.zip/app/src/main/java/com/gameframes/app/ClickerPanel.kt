package com.gameframes.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

/**
 * Settings panel of the auto clicker, floating over the game: press mode, speed, hold time, randomness,
 * limits, start delay and marker size. Every choice is saved at once and read by [ClickerService] on the next tap.
 */
class ClickerPanel(private val c: Context, private val wm: WindowManager) {

    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var accText: TextView
    private var built = false
    var shown = false
        private set

    private fun dp(n: Int) = c.dp(n)

    fun show() {
        if (shown) return
        if (!built) build()
        refreshAccessibility()
        shown = true
        VideoMask.open(c, "clicker") {
            if (shown) try { wm.addView(root, lp) } catch (_: Exception) { shown = false }
        }
    }

    fun hide() {
        if (!shown) return
        shown = false
        try { wm.removeView(root) } catch (_: Exception) {}
        VideoMask.close(c, "clicker")
    }

    private fun refreshAccessibility() {
        val on = ClickerAccessibilityService.connected
        accText.text = if (on) "خدمة الضغط: مفعّلة ✓" else "خدمة الضغط: غير مفعّلة (مطلوبة لإرسال الضغطات)"
        accText.setTextColor(if (on) IOS_GREEN else IOS_ORANGE)
    }

    private fun ms(v: Int) = if (v >= 1000) "${v / 1000.0}s".replace(".0s", "s") else "${v}ms"

    /** Caption + one row of choices saved as an index into a list in [Prefs]. */
    private fun choice(title: String, key: String, def: Int, labels: List<String>, after: () -> Unit = {}): LinearLayout {
        val sel = Prefs.int(c, key, def).coerceIn(0, labels.size - 1)
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            addView(c.caption(title))
            addView(ChipRow(c, labels, sel) { i -> Prefs.setInt(c, key, i); after() })
        }
    }

    private fun build() {
        val screen = c.realMetrics()
        val width = min(dp(310), screen.widthPixels - dp(16))
        val maxH = (screen.heightPixels * 0.78f).toInt()

        root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = c.rounded(Color.parseColor("#E61C1C1E"), 24, GLASS_EDGE_TOP, 1)
        }

        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(8), dp(10), dp(8))
        }
        val title = c.label("الضغط التلقائي  ⠿", 16f, Color.WHITE).apply { typeface = Fonts.bold }
        val closeBtn = c.glassCircle(34, IconView.CLOSE, Color.parseColor("#66787880")).apply {
            setOnClickListener { hide() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(closeBtn, LinearLayout.LayoutParams(dp(34), dp(34)))
        root.addView(header)

        lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.int(c, Prefs.K_CL_PX, dp(24))
            y = Prefs.int(c, Prefs.K_CL_PY, dp(24))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(6) || abs(e.rawY - ty) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { Prefs.setInt(c, Prefs.K_CL_PX, lp.x); Prefs.setInt(c, Prefs.K_CL_PY, lp.y) }
                    true
                }
                else -> false
            }
        }

        val body = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), 0, dp(14), dp(14))
        }
        body.addView(c.label(
            "1) اسحب النقطة A فوق الزر المطلوب (مثل زر إطلاق النار). " +
                "2) لكل نقطة زر دائري بنفس الحرف: ضعه في مكان يناسب إصبعك. " +
                "3) اضغط الزر مرة فيبدأ الضغط المتواصل على النقطة، ومرة أخرى يوقفه. " +
                "▶ في الشريط يشغّل كل النقاط معًا.", 12f, LABEL2
        ).apply { setPadding(0, 0, 0, dp(4)) })

        accText = c.label("", 13f, IOS_ORANGE)
        body.addView(accText)
        val accRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val half = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) } }
        accRow.addView(c.button("إعدادات إمكانية الوصول") {
            try {
                c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
        }, half())
        if (Prefs.isRootUser(c)) {
            accRow.addView(c.button("تفعيل بالروت") {
                Thread {
                    val ok = RootTools.enableAccessibility(ClickerAccessibilityService.COMPONENT)
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(c, if (ok) "تم التفعيل" else "تعذّر التفعيل بالروت", Toast.LENGTH_SHORT).show()
                        refreshAccessibility()
                    }
                }.start()
            }, half())
        }
        body.addView(accRow)

        body.addView(c.switchRow("أزرار التشغيل (A B C…)", "زر دائري لكل نقطة يضغط عليها وحدها", Prefs.bool(c, Prefs.K_CL_TRIG, true)) { on ->
            Prefs.setBool(c, Prefs.K_CL_TRIG, on); ClickerService.rebuild(); true
        })
        body.addView(choice("طريقة زر التشغيل", Prefs.K_CL_HOLD, 0, listOf("ضغطة تشغّل وضغطة توقف", "يضغط طالما أنا ماسكه")))

        // speed of each target on its own: pick the letter, then its speed
        val ivLabels = listOf("افتراضي") + Prefs.CL_INTERVALS.map { ms(it) }
        var selMarker = 0
        val ivRow = ChipRow(c, ivLabels, Prefs.int(c, Prefs.clIv(0), 0).coerceIn(0, ivLabels.size - 1)) { i ->
            Prefs.setInt(c, Prefs.clIv(selMarker), i)
        }
        val letters = ChipRow(c, (0 until 8).map { ('A' + it).toString() }, 0) { i ->
            selMarker = i
            ivRow.select(Prefs.int(c, Prefs.clIv(i), 0).coerceIn(0, ivLabels.size - 1), false)
        }
        body.addView(c.caption("سرعة كل نقطة على حدة: اختر الحرف ثم سرعته"))
        body.addView(letters)
        body.addView(ivRow)

        body.addView(choice("نمط الضغط (للزر ▶ في الشريط)", Prefs.K_CL_MODE, 0, listOf("واحدة بعد الأخرى", "الكل معًا", "سحب A ← B")))
        body.addView(choice("السرعة الافتراضية (الفاصل بين الضغطات)", Prefs.K_CL_INT, 4, Prefs.CL_INTERVALS.map { ms(it) }))
        body.addView(choice("مدة بقاء الإصبع على الزر", Prefs.K_CL_DUR, 1, Prefs.CL_DURS.map { ms(it) }))
        body.addView(choice("عشوائية الفاصل", Prefs.K_CL_RND, 0, Prefs.CL_RND.map { if (it == 0) "بدون" else "±$it%" }))
        body.addView(choice("انحراف عشوائي للمكان", Prefs.K_CL_JIT, 0, Prefs.CL_JIT.map { if (it == 0) "بدون" else "±$it px" }))
        body.addView(choice("توقف بعد عدد ضغطات", Prefs.K_CL_MAX, 0, Prefs.CL_MAX.map { if (it == 0) "∞" else "$it" }))
        body.addView(choice("توقف بعد مدة", Prefs.K_CL_SEC, 0, Prefs.CL_SEC.map {
            when { it == 0 -> "∞"; it >= 60 -> "${it / 60} د"; else -> "$it ث" }
        }))
        body.addView(choice("تأخير قبل البدء", Prefs.K_CL_DELAY, 0, Prefs.CL_DELAY.map { if (it == 0) "بدون" else "$it ث" }))
        body.addView(choice("حجم النقاط", Prefs.K_CL_SIZE, 1, listOf("صغير", "وسط", "كبير", "كبير جدًا")) { ClickerService.rebuild() })
        body.addView(c.switchRow("إخفاء النقاط أثناء الضغط", "تبقى تعمل لكن لا تظهر", Prefs.bool(c, Prefs.K_CL_HIDE, false)) { on ->
            Prefs.setBool(c, Prefs.K_CL_HIDE, on); true
        })

        val scroll = object : ScrollView(c) {
            override fun onMeasure(w: Int, h: Int) =
                super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }.apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(body)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        built = true
    }
}
