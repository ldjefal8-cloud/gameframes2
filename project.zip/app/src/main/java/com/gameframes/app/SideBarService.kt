package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.BatteryManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/** The thin strip on the screen edge that opens the drawer when swiped inward (its line is optional). */
class EdgeHandleView(context: Context, private val right: Boolean, hint0: Boolean) : View(context) {
    var hint = hint0
        set(v) { if (field != v) { field = v; invalidate() } }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#80FFFFFF") }
    override fun onDraw(c: Canvas) {
        if (!hint) return
        val w = context.dp(4).toFloat()
        val x = if (right) width - context.dp(6).toFloat() - w else context.dp(6).toFloat()
        val h = min(height.toFloat(), context.dp(56).toFloat())
        val top = (height - h) / 2f
        c.drawRoundRect(RectF(x, top, x + w, top + h), w / 2, w / 2, p)
    }
}

/**
 * Game side panel: swipe inward from the screen edge (at the handle) and a drawer slides in with
 * quick tools - record, screenshot, FPS / temperature / battery, crosshair, auto clicker, keep screen on,
 * the floating button, plus volume and brightness. Tap outside to close it.
 */
class SideBarService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.side.close"
        private const val CHANNEL = "sidebar"
        private const val BASE =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        @Volatile var instance: SideBarService? = null
        val alive get() = instance != null
        fun reload() { instance?.apply { handler.post { buildHandle() } } }
    }

    private class Tile(
        val view: LinearLayout, val box: FrameLayout, val icon: IconView, val cap: TextView,
        val state: () -> Boolean, val capFn: (() -> String)?
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var handle: EdgeHandleView? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var drawer: View? = null
    private var drawerLp: WindowManager.LayoutParams? = null
    private val tiles = ArrayList<Tile>()
    private var xhPanel: XhPanel? = null
    private var opening = false
    private var bg: RmEdgeBg? = null
    private var gauge: RmGauge? = null
    private var recText: TextView? = null
    private var batText: TextView? = null
    private val sliders = ArrayList<IosSlider>()
    private var accent = RM_CYAN

    private val tick = object : Runnable {
        override fun run() {
            applyWindowRules()
            VideoMask.update(this@SideBarService)
            updateLook()
            xhPanel?.sync()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_SIDE_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        startFg()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildHandle()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Side bar", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 10,
            Intent(this, SideBarService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("FPS")
            .setContentText("الشريط الجانبي شغّال: اسحب من حافة الشاشة")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
    }

    // ---------------- edge handle ----------------

    private fun buildHandle() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        val right = Prefs.int(this, Prefs.K_SIDE_EDGE, 1) == 1
        val hDp = Prefs.int(this, Prefs.K_SIDE_H, 140)
        val v = EdgeHandleView(this, right, Prefs.bool(this, Prefs.K_SIDE_HINT, true))
        val lp = WindowManager.LayoutParams(
            dp(24), dp(hDp),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (right) Gravity.END else Gravity.START) or Gravity.TOP
            x = 0
            y = dp(Prefs.int(this@SideBarService, Prefs.K_SIDE_Y, 200))
        }
        var downX = 0f; var opened = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; opened = false }
                MotionEvent.ACTION_MOVE -> {
                    val d = if (right) downX - e.rawX else e.rawX - downX
                    if (!opened && d > dp(28)) { opened = true; openDrawer() }
                }
            }
            true
        }
        try { wm.addView(v, lp); handle = v; handleLp = lp } catch (_: Exception) { stopSelf() }
        applyWindowRules()
    }

    /**
     * Video rule: the edge strip and the drawer are never secure windows (that leaves a black block in the video).
     * The strip is just made invisible while recording in the "hidden" modes, and the drawer freezes the video while open.
     */
    private fun applyWindowRules() {
        val mode = Prefs.bubbleVideoMode(this)
        val recording = RecorderService.running && !RecorderService.paused
        val keep = if (Prefs.bool(this, Prefs.K_KEEP_ON, false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0
        handle?.let { v ->
            v.hint = Prefs.bool(this, Prefs.K_SIDE_HINT, true) && !(recording && mode in 1..2)
            handleLp?.let { lp ->
                val f = BASE or keep
                if (lp.flags != f) {
                    lp.flags = f
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
        }
        drawer?.let { v ->
            drawerLp?.let { lp ->
                val f = BASE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or keep
                if (lp.flags != f) {
                    lp.flags = f
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
        }
        xhPanel?.applyVideoMode(mode, recording)
    }

    // ---------------- drawer ----------------

    private fun openDrawer() {
        if (drawer != null || opening) return
        opening = true
        // freeze the video first (when needed) and only then show the panel
        VideoMask.open(this, "drawer") { opening = false; showDrawer() }
    }

    private fun roundBtn(kind: Int, onClick: () -> Unit): FrameLayout =
        glassCircle(34, kind, Color.parseColor("#E62A2C30")).apply { setOnClickListener { onClick() } }

    private fun showDrawer() {
        if (drawer != null) return
        val right = Prefs.int(this, Prefs.K_SIDE_EDGE, 1) == 1
        val screen = realMetrics()
        val w = min(dp(340), (screen.widthPixels * 0.9f).toInt())
        val maxH = (screen.heightPixels * 0.92f).toInt()

        val back = RmEdgeBg(this, right)
        bg = back
        val slant = min(dp(44), (w * 0.16f).toInt())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            if (right) setPadding(slant + dp(10), dp(10), dp(12), dp(12)) else setPadding(dp(12), dp(10), slant + dp(10), dp(12))
        }

        // top row: title + round buttons (home = open the app, ✕ = close the panel)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("FPS", 18f, Color.WHITE).apply { typeface = Fonts.bold },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(roundBtn(IconView.HOME) {
            closeDrawer()
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(8) })
        head.addView(roundBtn(IconView.CLOSE) { closeDrawer() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        content.addView(head)

        tiles.clear(); sliders.clear()
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        // left column: gauge (battery temperature) + record state + battery
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val g = RmGauge(this).also { gauge = it }
        col.addView(g, LinearLayout.LayoutParams(dp(104), dp(122)))
        recText = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER; typeface = Fonts.bold; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        col.addView(recText, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        batText = TextView(this).apply { textSize = 12f; gravity = Gravity.CENTER; setTextColor(RM_TILE_TEXT) }
        col.addView(batText, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        main.addView(col, LinearLayout.LayoutParams(dp(104), LinearLayout.LayoutParams.WRAP_CONTENT))

        // right: two columns of square buttons
        val grid = listOf(
            tile("تسجيل", IconView.REC, { RecorderService.running }) { toggleRecord() },
            tile("لقطة شاشة", IconView.SHOT, { false }) { screenshot() },
            tile("FPS", IconView.FRAMES, { FpsOverlayService.fpsActive }) { toggleFps() },
            tile("الحرارة", IconView.TEMP, { Prefs.bool(this, Prefs.K_HUD_TEMP, false) }) { toggleHud(Prefs.K_HUD_TEMP) },
            tile("البطارية", IconView.BATT, { Prefs.bool(this, Prefs.K_HUD_BAT, false) }) { toggleHud(Prefs.K_HUD_BAT) },
            tile("كروس هير", IconView.CROSS, { CrosshairService.alive }) { toggleCrosshair() },
            tile("إعداد الكروس", IconView.SETTINGS, { xhPanel?.shown == true }) { openCrosshairPanel() },
            tile("ضغط تلقائي", IconView.TAP, { ClickerService.alive }) { toggleClicker() },
            tile("إعداد الضغط", IconView.SETTINGS, { false }) { openClickerPanel() },
            tile("الشاشة مضاءة", IconView.SUN, { Prefs.bool(this, Prefs.K_KEEP_ON, false) }) {
                Prefs.setBool(this, Prefs.K_KEEP_ON, !Prefs.bool(this, Prefs.K_KEEP_ON, false)); applyWindowRules()
            },
            tile("الزر العائم", IconView.RING, { BubbleService.alive }) { toggleBubble() },
            tile("الفيديو", IconView.EYE_OFF, { Prefs.bubbleVideoMode(this) != 0 },
                { when (Prefs.bubbleVideoMode(this)) { 1 -> "مخفي من الفيديو"; 2 -> "مخفي أثناء التسجيل"; else -> "ظاهر بالفيديو" } }) { cycleVideoMode() },
            tile("إيقاف الكل", IconView.CLOSE, { false }) { stopAllTools() }
        )
        val gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in grid.chunked(2)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (t in r) row.addView(t.view, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            gridBox.addView(row)
        }
        main.addView(gridBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(main, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // volume
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        content.addView(sliderRow("الصوت", 0, maxVol, am.getStreamVolume(AudioManager.STREAM_MUSIC), "", accent) { v ->
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) } catch (_: Exception) {}
        }.also { collectSliders(it) })
        // brightness (needs the "modify system settings" permission once)
        if (Settings.System.canWrite(this)) {
            val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
            content.addView(sliderRow("السطوع", 1, 255, cur.coerceIn(1, 255), "", accent) { v ->
                try {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                } catch (_: Exception) {}
            }.also { collectSliders(it) })
        } else {
            content.addView(button("السماح بتعديل السطوع") {
                closeDrawer()
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(8), dp(4), 0) })
        }

        val scroll = object : ScrollView(this) {
            override fun onMeasure(wSpec: Int, hSpec: Int) =
                super.onMeasure(wSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }.apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }
        val root = FrameLayout(this)
        root.addView(back, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -2))
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closeDrawer(); true } else false
        }

        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
            x = 0
        }
        try { wm.addView(root, lp) } catch (_: Exception) { VideoMask.close(this, "drawer"); return }
        drawer = root; drawerLp = lp
        applyWindowRules()
        updateLook()
        root.alpha = 0f
        root.translationX = (if (right) w else -w) * 0.35f
        root.animate().alpha(1f).translationX(0f).setDuration(170).start()
    }

    private fun collectSliders(row: LinearLayout) {
        for (i in 0 until row.childCount) (row.getChildAt(i) as? IosSlider)?.let { sliders.add(it) }
    }

    private fun closeDrawer() {
        val v = drawer ?: return
        drawer = null; drawerLp = null
        tiles.clear(); sliders.clear(); bg = null; gauge = null; recText = null; batText = null
        v.animate().alpha(0f).setDuration(110).withEndAction {
            try { wm.removeView(v) } catch (_: Exception) {}
            VideoMask.close(this, "drawer")
        }.start()
    }

    /** Colour of the panel: cyan, red while recording, orange when the battery is hot. Also refreshes the readings. */
    private fun updateLook() {
        if (drawer == null) return
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val temp = if (t == Int.MIN_VALUE) Float.NaN else t / 10f
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val rec = RecorderService.running
        accent = when {
            rec && !RecorderService.paused -> Color.parseColor("#FF453A")
            !temp.isNaN() && temp >= 42f -> IOS_ORANGE
            else -> RM_CYAN
        }
        bg?.accent = accent
        gauge?.let { g ->
            g.accent = accent
            g.valueText = if (temp.isNaN()) "–" else "%.1f".format(temp)
            g.frac = if (temp.isNaN()) 0f else ((temp - 20f) / 30f)
        }
        recText?.let { r ->
            if (rec) {
                val sec = RecorderService.recordedSec()
                r.text = "REC %02d:%02d".format(sec / 60, sec % 60)
                r.background = rounded(Color.parseColor(if (RecorderService.paused) "#66FF9F0A" else "#66FF453A"), 14)
            } else {
                r.text = "جاهز"
                r.background = rounded(Color.parseColor("#33FFFFFF"), 14)
            }
        }
        batText?.text = if (pct >= 0) "البطارية $pct%" else ""
        for (s in sliders) s.accent = accent
        for (tl in tiles) paintTile(tl)
    }

    private fun tile(caption: String, kind: Int, state: () -> Boolean, capFn: (() -> String)? = null, onClick: () -> Unit): Tile {
        val ic = IconView(this, kind, Color.WHITE)
        val box = FrameLayout(this).apply { addView(ic, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER)) }
        val cap = TextView(this).apply {
            text = capFn?.invoke() ?: caption
            textSize = 10.5f; gravity = Gravity.CENTER; setTextColor(RM_TILE_TEXT)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(box, LinearLayout.LayoutParams(dp(58), dp(58)))
            addView(cap, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            setOnClickListener { onClick(); tiles.forEach { paintTile(it) } }
        }
        val t = Tile(view, box, ic, cap, state, capFn)
        tiles.add(t)
        paintTile(t)
        return t
    }

    private fun paintTile(t: Tile) {
        val on = t.state()
        t.box.background = if (on) rounded((accent and 0x00FFFFFF) or 0x38000000, 16, accent, 2)
        else rounded(RM_TILE, 16, Color.parseColor("#1AFFFFFF"), 1)
        t.icon.set(t.icon.kind, if (on) accent else Color.parseColor("#F2FFFFFF"))
        t.capFn?.let { t.cap.text = it() }
        t.cap.setTextColor(if (on) accent else RM_TILE_TEXT)
    }

    // ---------------- actions ----------------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun toggleRecord() {
        closeDrawer()
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
        } else {
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun screenshot() {
        closeDrawer()
        val svc = ClickerAccessibilityService.instance
        if (svc == null) { toast("فعّل خدمة «الضغط التلقائي» من إمكانية الوصول لتعمل اللقطة"); return }
        handler.postDelayed({ if (!svc.screenshot()) toast("تعذّرت اللقطة") }, 350)
    }

    private fun toggleFps() {
        if (FpsOverlayService.fpsActive) {
            Prefs.setBool(this, Prefs.K_FPS_ON, false)
            FpsOverlayService.dropCounter()
        } else {
            Prefs.setBool(this, Prefs.K_FPS_ON, true)
            if (Prefs.isRootUser(this)) {
                startForegroundService(Intent(this, FpsOverlayService::class.java))
                return
            }
            closeDrawer()
            startActivity(Intent(this, CaptureActivity::class.java).putExtra("fps", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleHud(key: String) {
        val on = !Prefs.bool(this, key, false)
        Prefs.setBool(this, key, on)
        if (on && !FpsOverlayService.alive) startForegroundService(Intent(this, FpsOverlayService::class.java))
        else FpsOverlayService.reload()
    }

    private fun toggleCrosshair() {
        if (CrosshairService.alive) {
            Prefs.setBool(this, Prefs.K_XH_ON, false)
            stopService(Intent(this, CrosshairService::class.java))
        } else {
            Prefs.setBool(this, Prefs.K_XH_ON, true)
            startForegroundService(Intent(this, CrosshairService::class.java))
        }
    }

    private fun openCrosshairPanel() {
        closeDrawer()
        val p = xhPanel ?: XhPanel(this, wm).also { xhPanel = it }
        if (p.shown) p.hide() else p.show()
    }

    private fun toggleClicker() {
        if (ClickerService.alive) stopService(Intent(this, ClickerService::class.java))
        else { closeDrawer(); startForegroundService(Intent(this, ClickerService::class.java)) }
    }

    private fun openClickerPanel() {
        if (!ClickerService.alive) { toast("شغّل «ضغط تلقائي» أولًا"); return }
        closeDrawer()
        ClickerService.openPanel()
    }

    private fun cycleVideoMode() {
        Prefs.setInt(this, Prefs.K_BUBBLE_VIDEO, (Prefs.bubbleVideoMode(this) + 1) % 3)
        applyWindowRules()
    }

    /** One tap to switch off everything that floats over the game (the side bar itself stays). */
    private fun stopAllTools() {
        Prefs.setBool(this, Prefs.K_XH_ON, false)
        stopService(Intent(this, CrosshairService::class.java))
        stopService(Intent(this, ClickerService::class.java))
        Prefs.setBool(this, Prefs.K_FPS_ON, false)
        Prefs.setBool(this, Prefs.K_HUD_TEMP, false)
        Prefs.setBool(this, Prefs.K_HUD_BAT, false)
        startService(Intent(this, FpsOverlayService::class.java).setAction(FpsOverlayService.ACTION_CLOSE))
        xhPanel?.hide()
        toast("تم إيقاف الأدوات")
    }

    private fun toggleBubble() {
        if (BubbleService.alive) {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopService(Intent(this, BubbleService::class.java))
        } else {
            Prefs.setBool(this, Prefs.K_BUBBLE, true)
            startForegroundService(Intent(this, BubbleService::class.java))
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        xhPanel?.hide(); xhPanel = null
        drawer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        drawer = null
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        super.onDestroy()
    }
}
