package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/** The thin invisible-ish strip on the screen edge that opens the drawer when swiped inward. */
class EdgeHandleView(context: Context, private val right: Boolean, private val hint: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#80FFFFFF") }
    override fun onDraw(c: Canvas) {
        if (!hint) return
        val w = context.dp(4).toFloat()
        val x = if (right) width - context.dp(6).toFloat() - w else context.dp(6).toFloat()
        val h = min(height.toFloat(), context.dp(56).toFloat())
        val top = (height - h) / 2f
        c.drawRoundRect(RectF(x, top, x + w, top + h), w / 2, w / 2, p)
    }
}

/**
 * Game side panel: swipe inward from the screen edge (at the handle) and a drawer slides in with
 * quick tools - record, screenshot, FPS / temperature / battery, crosshair, auto clicker, keep screen on,
 * the floating button, plus volume and brightness. Tap outside to close it.
 */
class SideBarService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.side.close"
        private const val CHANNEL = "sidebar"
        private const val BASE =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        @Volatile var instance: SideBarService? = null
        val alive get() = instance != null
        fun reload() { instance?.apply { handler.post { buildHandle() } } }
    }

    private class Tile(val view: LinearLayout, val icon: IconView, val state: () -> Boolean)

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var handle: EdgeHandleView? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var drawer: LinearLayout? = null
    private var drawerLp: WindowManager.LayoutParams? = null
    private val tiles = ArrayList<Tile>()
    private var xhPanel: XhPanel? = null

    private val tick = object : Runnable {
        override fun run() {
            applyWindowRules()
            for (t in tiles) paintTile(t)
            xhPanel?.sync()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_SIDE_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        startFg()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildHandle()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Side bar", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 10,
            Intent(this, SideBarService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("الشريط الجانبي شغّال: اسحب من حافة الشاشة")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
    }

    // ---------------- edge handle ----------------

    private fun buildHandle() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        val right = Prefs.int(this, Prefs.K_SIDE_EDGE, 1) == 1
        val hDp = Prefs.int(this, Prefs.K_SIDE_H, 140)
        val v = EdgeHandleView(this, right, Prefs.bool(this, Prefs.K_SIDE_HINT, true))
        val lp = WindowManager.LayoutParams(
            dp(24), dp(hDp),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (right) Gravity.END else Gravity.START) or Gravity.TOP
            x = 0
            y = dp(Prefs.int(this@SideBarService, Prefs.K_SIDE_Y, 200))
        }
        var downX = 0f; var opened = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; opened = false }
                MotionEvent.ACTION_MOVE -> {
                    val d = if (right) downX - e.rawX else e.rawX - downX
                    if (!opened && d > dp(28)) { opened = true; openDrawer() }
                }
            }
            true
        }
        try { wm.addView(v, lp); handle = v; handleLp = lp } catch (_: Exception) { stopSelf() }
        applyWindowRules()
    }

    /** Same video rule as the floating button (1 = out of the video, 2 = hidden while recording) + keep-awake. */
    private fun applyWindowRules() {
        val mode = Prefs.bubbleVideoMode(this)
        val recording = RecorderService.running && !RecorderService.paused
        val secure = if (mode == 1) WindowManager.LayoutParams.FLAG_SECURE else 0
        val keep = if (Prefs.bool(this, Prefs.K_KEEP_ON, false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0
        val hidden = mode == 2 && recording
        handle?.let { v ->
            handleLp?.let { lp ->
                val f = BASE or secure or keep
                if (lp.flags != f || (v.visibility == View.GONE) != hidden) {
                    lp.flags = f
                    v.visibility = if (hidden) View.GONE else View.VISIBLE
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
        }
        drawer?.let { v ->
            drawerLp?.let { lp ->
                val f = BASE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or secure or keep
                if (lp.flags != f) {
                    lp.flags = f
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
        }
        xhPanel?.applyVideoMode(mode, recording)
    }

    // ---------------- drawer ----------------

    private fun openDrawer() {
        if (drawer != null) return
        val right = Prefs.int(this, Prefs.K_SIDE_EDGE, 1) == 1
        val screen = realMetrics()
        val w = min(dp(310), (screen.widthPixels * 0.82f).toInt())
        val maxH = (screen.heightPixels * 0.90f).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.parseColor("#F0121214"), 26, GLASS_EDGE_TOP, 1)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(10), dp(4))
        }
        head.addView(label("Game Frames", 18f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(glassCircle(32, IconView.CLOSE, Color.parseColor("#66787880")).apply {
            setOnClickListener { closeDrawer() }
        }, LinearLayout.LayoutParams(dp(32), dp(32)))
        root.addView(head)

        tiles.clear()
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(14))
        }
        val grid = listOf(
            tile("تسجيل", IconView.REC, { RecorderService.running }) { toggleRecord() },
            tile("لقطة شاشة", IconView.SHOT, { false }) { screenshot() },
            tile("FPS", IconView.FRAMES, { FpsOverlayService.fpsActive }) { toggleFps() },
            tile("الحرارة", IconView.TEMP, { Prefs.bool(this, Prefs.K_HUD_TEMP, false) }) { toggleHud(Prefs.K_HUD_TEMP) },
            tile("البطارية", IconView.BATT, { Prefs.bool(this, Prefs.K_HUD_BAT, false) }) { toggleHud(Prefs.K_HUD_BAT) },
            tile("كروس هير", IconView.CROSS, { CrosshairService.alive }) { toggleCrosshair() },
            tile("إعداد الكروس", IconView.SETTINGS, { xhPanel?.shown == true }) { openCrosshairPanel() },
            tile("ضغط تلقائي", IconView.TAP, { ClickerService.alive }) { toggleClicker() },
            tile("الشاشة مضاءة", IconView.SUN, { Prefs.bool(this, Prefs.K_KEEP_ON, false) }) {
                Prefs.setBool(this, Prefs.K_KEEP_ON, !Prefs.bool(this, Prefs.K_KEEP_ON, false)); applyWindowRules()
            },
            tile("الزر العائم", IconView.RING, { BubbleService.alive }) { toggleBubble() }
        )
        for (r in grid.chunked(3)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (t in r) row.addView(t.view, LinearLayout.LayoutParams(0, dp(78), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            body.addView(row)
        }

        // volume
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        body.addView(sliderRow("الصوت", 0, maxVol, am.getStreamVolume(AudioManager.STREAM_MUSIC), "") { v ->
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) } catch (_: Exception) {}
        })
        // brightness (needs the "modify system settings" permission once)
        if (Settings.System.canWrite(this)) {
            val cur = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
            body.addView(sliderRow("السطوع", 1, 255, cur.coerceIn(1, 255), "") { v ->
                try {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
                } catch (_: Exception) {}
            })
        } else {
            body.addView(button("السماح بتعديل السطوع") {
                closeDrawer()
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(8), dp(4), 0) })
        }

        val scroll = object : ScrollView(this) {
            override fun onMeasure(wSpec: Int, hSpec: Int) =
                super.onMeasure(wSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }.apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(body)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { closeDrawer(); true } else false
        }

        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
            x = dp(6)
        }
        try { wm.addView(root, lp) } catch (_: Exception) { return }
        drawer = root; drawerLp = lp
        applyWindowRules()
        root.alpha = 0f
        root.translationX = (if (right) w else -w) * 0.4f
        root.animate().alpha(1f).translationX(0f).setDuration(180).start()
        for (t in tiles) paintTile(t)
    }

    private fun closeDrawer() {
        val v = drawer ?: return
        drawer = null; drawerLp = null
        tiles.clear()
        v.animate().alpha(0f).setDuration(120).withEndAction {
            try { wm.removeView(v) } catch (_: Exception) {}
        }.start()
    }

    private fun tile(caption: String, kind: Int, state: () -> Boolean, onClick: () -> Unit): Tile {
        val ic = IconView(this, kind, Color.WHITE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(6), dp(4), dp(6))
            addView(ic, LinearLayout.LayoutParams(dp(30), dp(30)))
            addView(TextView(context).apply {
                this.text = caption; textSize = 11.5f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); maxLines = 2
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
            setOnClickListener { onClick(); tiles.forEach { paintTile(it) } }
        }
        val t = Tile(box, ic, state)
        tiles.add(t)
        paintTile(t)
        return t
    }

    private fun paintTile(t: Tile) {
        val on = t.state()
        t.view.background = rounded(if (on) Color.parseColor("#660A84FF") else Color.parseColor("#26FFFFFF"), 18,
            if (on) IOS_BLUE else GLASS_EDGE_BOT, 1)
        t.icon.set(t.icon.kind, if (on) Color.WHITE else Color.parseColor("#CCFFFFFF"))
    }

    // ---------------- actions ----------------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun toggleRecord() {
        closeDrawer()
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
        } else {
            startActivity(Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun screenshot() {
        closeDrawer()
        val svc = ClickerAccessibilityService.instance
        if (svc == null) { toast("فعّل خدمة «الضغط التلقائي» من إمكانية الوصول لتعمل اللقطة"); return }
        handler.postDelayed({ if (!svc.screenshot()) toast("تعذّرت اللقطة") }, 350)
    }

    private fun toggleFps() {
        if (FpsOverlayService.fpsActive) {
            Prefs.setBool(this, Prefs.K_FPS_ON, false)
            FpsOverlayService.dropCounter()
        } else {
            Prefs.setBool(this, Prefs.K_FPS_ON, true)
            closeDrawer()
            startActivity(Intent(this, CaptureActivity::class.java).putExtra("fps", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun toggleHud(key: String) {
        val on = !Prefs.bool(this, key, false)
        Prefs.setBool(this, key, on)
        if (on && !FpsOverlayService.alive) startForegroundService(Intent(this, FpsOverlayService::class.java))
        else FpsOverlayService.reload()
    }

    private fun toggleCrosshair() {
        if (CrosshairService.alive) {
            Prefs.setBool(this, Prefs.K_XH_ON, false)
            stopService(Intent(this, CrosshairService::class.java))
        } else {
            Prefs.setBool(this, Prefs.K_XH_ON, true)
            startForegroundService(Intent(this, CrosshairService::class.java))
        }
    }

    private fun openCrosshairPanel() {
        closeDrawer()
        val p = xhPanel ?: XhPanel(this, wm).also { xhPanel = it }
        if (p.shown) p.hide() else p.show()
    }

    private fun toggleClicker() {
        if (ClickerService.alive) stopService(Intent(this, ClickerService::class.java))
        else { closeDrawer(); startForegroundService(Intent(this, ClickerService::class.java)) }
    }

    private fun toggleBubble() {
        if (BubbleService.alive) {
            Prefs.setBool(this, Prefs.K_BUBBLE, false)
            stopService(Intent(this, BubbleService::class.java))
        } else {
            Prefs.setBool(this, Prefs.K_BUBBLE, true)
            startForegroundService(Intent(this, BubbleService::class.java))
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        xhPanel?.hide(); xhPanel = null
        drawer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        drawer = null
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        super.onDestroy()
    }
}
