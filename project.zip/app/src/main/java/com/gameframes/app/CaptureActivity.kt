package com.gameframes.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

/**
 * Invisible activity used to start a recording from outside the app (the floating button).
 * It asks for screen-capture consent (skipped automatically for root users after setup),
 * starts the recorder with the saved settings, and closes at once so the game stays in front.
 */
class CaptureActivity : Activity() {

    private val reqCapture = 200
    private val reqAudio = 201
    private val forFps get() = intent?.getBooleanExtra("fps", false) == true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!forFps && RecorderService.running) {
            finish()
            return
        }
        proceed()
    }

    private fun proceed() {
        val audioMode = if (forFps) 0 else Prefs.int(this, Prefs.K_AUDIO, 1)
        if (audioMode != 0 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqAudio)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqAudio) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                proceed()
            } else {
                Toast.makeText(this, "الصوت يحتاج إذن التسجيل الصوتي", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                if (forFps) {
                    startForegroundService(
                        Intent(this, FpsOverlayService::class.java)
                            .putExtra("code", resultCode).putExtra("data", data)
                    )
                } else {
                    // started from inside a game: no countdown needed
                    startForegroundService(Prefs.recorderIntent(this, resultCode, data, delayOverride = 0))
                }
            } else {
                if (forFps) Prefs.setBool(this, Prefs.K_FPS_ON, false)
                Toast.makeText(this, "تم إلغاء التسجيل", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }
}
