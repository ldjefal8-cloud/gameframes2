package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/**
 * Stand-alone FPS meter (no recording needed).
 *  - Root: the game's real FPS from SurfaceFlinger  -> "GAME n".
 *  - No root: counts the frames the screen actually composes through a tiny, never-saved
 *    screen-capture surface (needs the usual screen-capture consent)  -> "FPS n".
 * While a recording is running it can also show "REC n" (frames written to the video).
 */
class FpsOverlayService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.fps.close"
        private const val CHANNEL = "fpsmeter"
        @Volatile var instance: FpsOverlayService? = null
        fun reload() { instance?.apply { handler.post { applyPrefs() } } }
        val alive get() = instance != null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private lateinit var lineMain: TextView
    private lateinit var lineRec: TextView
    private var lp: WindowManager.LayoutParams? = null

    private var rootFps: RootFps? = null
    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val frames = AtomicInteger(0)
    private var lastFrames = 0
    private var measured = -1

    private val tick = object : Runnable {
        override fun run() {
            val rf = rootFps
            if (rf != null) {
                measured = if (rf.ok) rf.fps else -1
            } else if (reader != null) {
                val f = frames.get()
                measured = f - lastFrames
                lastFrames = f
            }
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_FPS_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val useRoot = Prefs.isRootUser(this)
        val useProjection = !useRoot && data != null
        if (!useRoot && !useProjection) { stopSelf(); return START_NOT_STICKY }

        startFg(useProjection)
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay(useRoot)

        if (useRoot) {
            rootFps = RootFps().also { it.start() }
        } else {
            try {
                startCounter(code, data!!)
            } catch (_: Exception) {
                stopSelf(); return START_NOT_STICKY
            }
        }
        handler.postDelayed(tick, 1000)
        return START_NOT_STICKY
    }

    private fun startCounter(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)
        val m = realMetrics()
        val w = (m.widthPixels / 8).coerceAtLeast(16)
        val h = (m.heightPixels / 8).coerceAtLeast(16)
        val t = HandlerThread("gf-fpscount").also { it.start() }
        thread = t
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir ->
            try { ir.acquireLatestImage()?.close(); frames.incrementAndGet() } catch (_: Exception) {}
        }, Handler(t.looper))
        vdisplay = proj.createVirtualDisplay(
            "GameFramesFps", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun buildOverlay(root: Boolean) {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#B31C1C1E"))
                setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }
        lineMain = TextView(this).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(IOS_GREEN)
            text = if (root) "GAME –" else "FPS –"
        }
        lineRec = TextView(this).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(LABEL2)
            visibility = android.view.View.GONE
        }
        l.addView(lineMain); l.addView(lineRec)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.int(this@FpsOverlayService, Prefs.K_FPS_X, dp(12))
            y = Prefs.int(this@FpsOverlayService, Prefs.K_FPS_Y, dp(48))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        l.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(6) || abs(e.rawY - ty) > dp(6)) moved = true
                    if (moved) {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(l, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.K_FPS_X, p.x); Prefs.setInt(this, Prefs.K_FPS_Y, p.y)
                    }
                    true
                }
                else -> false
            }
        }
        lp = p; box = l
        try { wm.addView(l, p) } catch (_: Exception) { box = null; stopSelf() }
        applyPrefs()
    }

    private fun applyPrefs() {
        val b = box ?: return
        val size = Prefs.int(this, Prefs.K_FPS_SIZE, 16).toFloat()
        lineMain.textSize = size
        lineRec.textSize = size * 0.8f
        render()
        try { lp?.let { wm.updateViewLayout(b, it) } } catch (_: Exception) {}
    }

    private fun render() {
        val root = rootFps != null
        val v = measured
        lineMain.text = (if (root) "GAME " else "FPS ") + (if (v >= 0) v.toString() else "–")
        lineMain.setTextColor(
            when {
                v < 0 -> LABEL2
                v >= 50 -> IOS_GREEN
                v >= 25 -> IOS_ORANGE
                else -> IOS_RED
            }
        )
        val showRec = Prefs.bool(this, Prefs.K_FPS_REC_LINE, false) && RecorderService.running
        lineRec.visibility = if (showRec) android.view.View.VISIBLE else android.view.View.GONE
        if (showRec) lineRec.text = "REC ${RecorderService.recFps}"
    }

    private fun startFg(withProjection: Boolean) {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "FPS meter", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 8,
            Intent(this, FpsOverlayService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("عدّاد FPS شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        val type = if (withProjection) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (Build.VERSION.SDK_INT >= 29) startForeground(4, n, type) else startForeground(4, n)
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(tick)
        rootFps?.stop(); rootFps = null
        try { vdisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }
}
