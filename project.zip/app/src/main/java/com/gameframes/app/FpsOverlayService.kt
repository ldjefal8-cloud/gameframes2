package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.Toast
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/**
 * Stand-alone FPS meter (no recording needed).
 *  - Root: the game's real FPS from SurfaceFlinger  -> "GAME n".
 *  - No root: counts the frames the screen actually composes through a tiny, never-saved
 *    screen-capture surface (needs the usual screen-capture consent)  -> "FPS n".
 * While a recording is running it can also show "REC n" (frames written to the video).
 */
class FpsOverlayService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.fps.close"
        private const val CHANNEL = "fpsmeter"
        @Volatile var instance: FpsOverlayService? = null
        fun reload() { instance?.apply { handler.post { applyPrefs() } } }
        val alive get() = instance != null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private lateinit var lineMain: TextView
    private lateinit var lineRec: TextView
    private lateinit var lineTemp: TextView
    private lateinit var lineBatt: TextView
    private lateinit var fpsIcon: IconView
    private var rootChecks = 0
    private var rootWarned = false
    private var lp: WindowManager.LayoutParams? = null

    private var rootFps: RootFps? = null
    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val frames = AtomicInteger(0)
    private var lastFrames = 0
    private var measured = -1

    private val tick = object : Runnable {
        override fun run() {
            val rf = rootFps
            if (rf != null) {
                measured = if (rf.ok) rf.fps else -1
                if (measured < 0 && !rootWarned && ++rootChecks >= 6) {
                    rootWarned = true
                    Toast.makeText(this@FpsOverlayService,
                        "تعذّرت قراءة FPS بالروت. جرّب «مستخدم عادي» من التطبيق.", Toast.LENGTH_LONG).show()
                }
            } else if (reader != null) {
                val f = frames.get()
                measured = f - lastFrames
                lastFrames = f
            }
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_FPS_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» لعدّاد FPS", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val useRoot = Prefs.isRootUser(this)
        val useProjection = !useRoot && data != null
        if (!useRoot && !useProjection) {
            Toast.makeText(this, "عدّاد FPS يحتاج إذن التقاط الشاشة. فعّله من التطبيق مرة ثانية.", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }

        try { startFg(useProjection) } catch (e: Exception) {
            Toast.makeText(this, "تعذّر تشغيل خدمة FPS: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay(useRoot)

        if (useRoot) {
            rootFps = RootFps().also { it.start() }
        } else {
            try {
                startCounter(code, data!!)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذّر بدء عدّ الفريمات: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                stopSelf(); return START_NOT_STICKY
            }
        }
        handler.postDelayed(tick, 1000)
        return START_NOT_STICKY
    }

    private fun startCounter(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopSelf() } }
        }, handler)
        val m = realMetrics()
        val w = (m.widthPixels / 8).coerceAtLeast(16)
        val h = (m.heightPixels / 8).coerceAtLeast(16)
        val t = HandlerThread("gf-fpscount").also { it.start() }
        thread = t
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir ->
            try { ir.acquireLatestImage()?.close(); frames.incrementAndGet() } catch (_: Exception) {}
        }, Handler(t.looper))
        vdisplay = proj.createVirtualDisplay(
            "GameFramesFps", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun buildOverlay(root: Boolean) {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#99303036"))
            }
            setPadding(dp(10), dp(5), dp(12), dp(5))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fpsIcon = IconView(this, IconView.FPS, Color.parseColor("#E6FFFFFF"))
        lineMain = TextView(this).apply {
            typeface = Fonts.medium(context)
            setTextColor(Color.WHITE)
            text = "--FPS"
            includeFontPadding = false
        }
        lineTemp = TextView(this).apply {
            typeface = Fonts.medium(context)
            setTextColor(Color.parseColor("#E6FFFFFF"))
            includeFontPadding = false
            visibility = android.view.View.GONE
        }
        lineBatt = TextView(this).apply {
            typeface = Fonts.medium(context)
            setTextColor(Color.parseColor("#E6FFFFFF"))
            includeFontPadding = false
            visibility = android.view.View.GONE
        }
        lineRec = TextView(this).apply {
            typeface = Fonts.medium(context)
            setTextColor(Color.parseColor("#CCFFFFFF"))
            includeFontPadding = false
            visibility = android.view.View.GONE
        }
        row.addView(fpsIcon, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginEnd = dp(6) })
        row.addView(lineMain)
        row.addView(lineTemp, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
        row.addView(lineBatt, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
        l.addView(row)
        l.addView(lineRec, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.int(this@FpsOverlayService, Prefs.K_FPS_X, dp(12))
            y = Prefs.int(this@FpsOverlayService, Prefs.K_FPS_Y, dp(48))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        l.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(6) || abs(e.rawY - ty) > dp(6)) moved = true
                    if (moved) {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(l, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.K_FPS_X, p.x); Prefs.setInt(this, Prefs.K_FPS_Y, p.y)
                    }
                    true
                }
                else -> false
            }
        }
        lp = p; box = l
        try { wm.addView(l, p) } catch (_: Exception) { box = null; stopSelf() }
        applyPrefs()
    }

    private fun applyPrefs() {
        val b = box ?: return
        val size = Prefs.int(this, Prefs.K_FPS_SIZE, 14).toFloat()
        lineMain.textSize = size
        lineTemp.textSize = size * 0.9f
        lineBatt.textSize = size * 0.9f
        lineRec.textSize = size * 0.8f
        val ic = dp((size * 1.1f).toInt().coerceAtLeast(12))
        (fpsIcon.layoutParams as LinearLayout.LayoutParams).apply { width = ic; height = ic }
        render()
        try { lp?.let { wm.updateViewLayout(b, it) } } catch (_: Exception) {}
    }

    private fun render() {
        val v = measured
        lineMain.text = (if (v >= 0) v.toString() else "--") + "FPS"

        // battery level + temperature (each has its own switch)
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val showBatt = Prefs.bool(this, Prefs.K_FPS_BATT, false)
        val showTemp = Prefs.bool(this, Prefs.K_FPS_TEMP, false)
        if (bi != null) {
            val lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10.0
            if (lvl >= 0) lineBatt.text = "${lvl * 100 / scale}%"
            if (temp > 0) lineTemp.text = "%.1f°C".format(temp)
        }
        lineBatt.visibility = if (showBatt) android.view.View.VISIBLE else android.view.View.GONE
        lineTemp.visibility = if (showTemp) android.view.View.VISIBLE else android.view.View.GONE

        val showRec = Prefs.bool(this, Prefs.K_FPS_REC_LINE, false) && RecorderService.running
        lineRec.visibility = if (showRec) android.view.View.VISIBLE else android.view.View.GONE
        if (showRec) lineRec.text = "REC ${RecorderService.recFps}"
    }

    private fun startFg(withProjection: Boolean) {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "FPS meter", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 8,
            Intent(this, FpsOverlayService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("عدّاد FPS شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (withProjection) {
            startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else if (Build.VERSION.SDK_INT >= 34) {
            startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(4, n)
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(tick)
        rootFps?.stop(); rootFps = null
        try { vdisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }
}
