package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/**
 * Performance bar floating over the game. One row, each part has its own switch in the app:
 *  - FPS (icon + number). Root: the game's real FPS from SurfaceFlinger ("GAME"). No root: frames the
 *    screen actually composes through a tiny, never-saved screen-capture surface (needs the usual consent).
 *  - battery temperature,
 *  - battery level.
 * Temperature and battery work on their own, without FPS counting and without any consent.
 * While a recording is running it can also show "REC n" (frames written to the video) in a second line.
 */
class FpsOverlayService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.fps.close"
        private const val CHANNEL = "fpsmeter"
        @Volatile var instance: FpsOverlayService? = null
        fun reload() { instance?.apply { handler.post { applyPrefs() } } }
        /** Stops only the FPS counting (temperature / battery keep showing if they are on). */
        fun dropCounter() { instance?.apply { handler.post { stopCounter(); applyPrefs() } } }
        val alive get() = instance != null
        val fpsActive get() = instance?.counterActive == true
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private lateinit var row: LinearLayout
    private lateinit var fpsGroup: LinearLayout
    private lateinit var fpsIcon: IconView
    private lateinit var fpsNum: TextView
    private lateinit var fpsTag: TextView
    private lateinit var tempGroup: LinearLayout
    private lateinit var tempIcon: IconView
    private lateinit var tempText: TextView
    private lateinit var batGroup: LinearLayout
    private lateinit var batIcon: IconView
    private lateinit var batText: TextView
    private lateinit var lineRec: TextView
    private var lp: WindowManager.LayoutParams? = null
    private var tickStarted = false

    private var rootFps: RootFps? = null
    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val frames = AtomicInteger(0)
    private var lastFrames = 0
    private var measured = -1

    private var batTemp = Float.NaN
    private var batPct = -1
    private var charging = false

    private val counterActive get() = rootFps != null || reader != null

    private val tick = object : Runnable {
        override fun run() {
            val rf = rootFps
            if (rf != null) {
                measured = if (rf.ok) rf.fps else -1
            } else if (reader != null) {
                val f = frames.get()
                measured = f - lastFrames
                lastFrames = f
            }
            readBattery()
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_FPS_ON, false)
            Prefs.setBool(this, Prefs.K_HUD_TEMP, false)
            Prefs.setBool(this, Prefs.K_HUD_BAT, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }

        val useRoot = Prefs.isRootUser(this)
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val attach = !useRoot && data != null          // fresh screen-capture consent to count frames with

        val first = instance == null
        if (first) {
            startFg(attach)
            instance = this
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            buildOverlay()
            if (box == null) return START_NOT_STICKY
        } else if (attach) {
            startFg(true)                               // upgrade the foreground type before using the projection
        }

        if (!counterActive) {
            if (useRoot && Prefs.bool(this, Prefs.K_FPS_ON, false)) {
                rootFps = RootFps().also { it.start() }
            } else if (attach) {
                try { startCounter(code, data!!) } catch (_: Exception) {
                    stopCounter()
                    Prefs.setBool(this, Prefs.K_FPS_ON, false)
                }
            }
        }
        if (!tickStarted) { tickStarted = true; handler.postDelayed(tick, 1000) }
        readBattery()
        applyPrefs()
        return START_NOT_STICKY
    }

    private fun startCounter(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post {
                    stopCounter()
                    Prefs.setBool(this@FpsOverlayService, Prefs.K_FPS_ON, false)
                    applyPrefs()
                }
            }
        }, handler)
        val m = realMetrics()
        val w = (m.widthPixels / 8).coerceAtLeast(16)
        val h = (m.heightPixels / 8).coerceAtLeast(16)
        val t = HandlerThread("gf-fpscount").also { it.start() }
        thread = t
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir ->
            try { ir.acquireLatestImage()?.close(); frames.incrementAndGet() } catch (_: Exception) {}
        }, Handler(t.looper))
        vdisplay = proj.createVirtualDisplay(
            "GameFramesFps", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        lastFrames = 0; frames.set(0); measured = -1
    }

    private fun stopCounter() {
        rootFps?.stop(); rootFps = null
        try { vdisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        vdisplay = null; reader = null; projection = null; thread = null
        measured = -1
    }

    private fun readBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        batTemp = if (t == Int.MIN_VALUE) Float.NaN else t / 10f
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        batPct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun group(icon: IconView, text: TextView): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(icon, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(4) })
            addView(text)
        }

    private fun mono(color: Int) = TextView(this).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setTextColor(color)
    }

    private fun buildOverlay() {
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#B31C1C1E"))
                setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }
        row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
            dividerDrawable = GradientDrawable().apply { setSize(dp(12), 1); setColor(Color.TRANSPARENT) }
        }

        fpsIcon = IconView(this, IconView.FRAMES, Color.WHITE)
        fpsNum = mono(IOS_GREEN).apply { text = "–" }
        fpsTag = mono(LABEL2).apply { text = "FPS"; setPadding(dp(3), 0, 0, 0) }
        fpsGroup = group(fpsIcon, fpsNum).apply { addView(fpsTag) }

        tempIcon = IconView(this, IconView.TEMP, IOS_GREEN)
        tempText = mono(IOS_GREEN).apply { text = "–" }
        tempGroup = group(tempIcon, tempText)

        batIcon = IconView(this, IconView.BATT, IOS_GREEN)
        batText = mono(IOS_GREEN).apply { text = "–" }
        batGroup = group(batIcon, batText)

        row.addView(fpsGroup); row.addView(tempGroup); row.addView(batGroup)

        lineRec = mono(LABEL2).apply { visibility = View.GONE }
        l.addView(row); l.addView(lineRec)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.int(this@FpsOverlayService, Prefs.K_FPS_X, dp(12))
            y = Prefs.int(this@FpsOverlayService, Prefs.K_FPS_Y, dp(48))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        l.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(6) || abs(e.rawY - ty) > dp(6)) moved = true
                    if (moved) {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(l, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.K_FPS_X, p.x); Prefs.setInt(this, Prefs.K_FPS_Y, p.y)
                    }
                    true
                }
                else -> false
            }
        }
        lp = p; box = l
        try { wm.addView(l, p) } catch (_: Exception) { box = null; stopSelf() }
    }

    private fun applyPrefs() {
        val b = box ?: return
        val showTemp = Prefs.bool(this, Prefs.K_HUD_TEMP, false)
        val showBat = Prefs.bool(this, Prefs.K_HUD_BAT, false)
        if (!counterActive && !showTemp && !showBat) { stopSelf(); return }   // nothing left to show
        val size = Prefs.int(this, Prefs.K_FPS_SIZE, 16).toFloat()
        fpsNum.textSize = size
        fpsTag.textSize = size * 0.6f
        tempText.textSize = size * 0.85f
        batText.textSize = size * 0.85f
        lineRec.textSize = size * 0.8f
        val ic = dp((size * 1.25f).toInt())
        for (g in listOf(fpsGroup, tempGroup, batGroup)) {
            val iv = g.getChildAt(0)
            iv.layoutParams = (iv.layoutParams as LinearLayout.LayoutParams).apply { width = ic; height = ic }
        }
        readBattery()
        render()
        try { lp?.let { wm.updateViewLayout(b, it) } } catch (_: Exception) {}
    }

    private fun render() {
        val showFps = counterActive
        fpsGroup.visibility = if (showFps) View.VISIBLE else View.GONE
        if (showFps) {
            val root = rootFps != null
            val v = measured
            fpsNum.text = if (v >= 0) v.toString() else "–"
            fpsTag.text = if (root) "GAME" else "FPS"
            fpsNum.setTextColor(
                when {
                    v < 0 -> LABEL2
                    v >= 50 -> IOS_GREEN
                    v >= 25 -> IOS_ORANGE
                    else -> IOS_RED
                }
            )
        }

        val showTemp = Prefs.bool(this, Prefs.K_HUD_TEMP, false)
        tempGroup.visibility = if (showTemp) View.VISIBLE else View.GONE
        if (showTemp) {
            val ok = !batTemp.isNaN()
            val col = when {
                !ok -> LABEL2
                batTemp >= 45f -> IOS_RED
                batTemp >= 40f -> IOS_ORANGE
                else -> IOS_GREEN
            }
            tempText.text = if (ok) "%.1f°".format(batTemp) else "–"
            tempText.setTextColor(col)
            tempIcon.set(IconView.TEMP, col)
        }

        val showBat = Prefs.bool(this, Prefs.K_HUD_BAT, false)
        batGroup.visibility = if (showBat) View.VISIBLE else View.GONE
        if (showBat) {
            val ok = batPct >= 0
            val col = when {
                !ok -> LABEL2
                charging -> IOS_GREEN
                batPct <= 15 -> IOS_RED
                batPct <= 30 -> IOS_ORANGE
                else -> Color.WHITE
            }
            batText.text = if (ok) "$batPct%" else "–"
            batText.setTextColor(col)
            batIcon.set(IconView.BATT, col)
            batIcon.level = if (ok) batPct / 100f else 0f
            batIcon.charging = charging
        }

        val showRec = counterActive && Prefs.bool(this, Prefs.K_FPS_REC_LINE, false) && RecorderService.running
        lineRec.visibility = if (showRec) View.VISIBLE else View.GONE
        if (showRec) lineRec.text = "REC ${RecorderService.recFps}"
    }

    private fun startFg(withProjection: Boolean) {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Performance bar", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 8,
            Intent(this, FpsOverlayService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("شريط الأداء شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        when {
            withProjection -> startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            Build.VERSION.SDK_INT >= 34 -> startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else -> startForeground(4, n)
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        stopCounter()
        try { box?.let { wm.removeView(it) } } catch (_: Exception) {}
        box = null
        super.onDestroy()
    }
}
