package com.gameframes.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val reqCapture = 100
    private val reqPick = 101
    private val reqAudioPerm = 102

    private lateinit var status: TextView
    private lateinit var statusSub: TextView
    private lateinit var fpsRowSw: LinearLayout
    private lateinit var xhRowSw: LinearLayout
    private lateinit var acRowSw: LinearLayout
    private lateinit var edRowSw: LinearLayout
    private lateinit var acAccText: TextView
    private lateinit var xhPreview: CrosshairView
    private val shapeTiles = ArrayList<FrameLayout>()
    private lateinit var btnLast: TextView

    private lateinit var presetRow: ChipRow
    private lateinit var qualRow: ChipRow
    private lateinit var fpsRow: ChipRow
    private lateinit var brRow: ChipRow

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Prefs.int(this, Prefs.K_MODE, 0) == 0) askUserType()
    }

    // ---------------- first run: normal user or root user ----------------

    private fun askUserType() {
        AlertDialog.Builder(this)
            .setTitle("أهلًا بك في Game Frames")
            .setMessage(
                "هل تستخدم هاتفك بصلاحية الروت؟\n\n" +
                    "• مستخدم عادي: كل الميزات الأساسية تعمل بدون روت.\n" +
                    "• مستخدم روت: تُفعَّل ميزات إضافية: عدّاد FPS اللعبة الحقيقي، حماية التسجيل من الإغلاق، " +
                    "وإعطاء الأذونات تلقائيًا.\n\n" +
                    "يمكنك تغيير هذا الاختيار لاحقًا من الإعدادات."
            )
            .setCancelable(false)
            .setPositiveButton("مستخدم روت") { _, _ -> chooseRoot() }
            .setNegativeButton("مستخدم عادي") { _, _ ->
                Prefs.setInt(this, Prefs.K_MODE, 1)
                recreate()
            }
            .show()
    }

    /** Asks for su (the root manager shows its own prompt), then prepares permissions. */
    private fun chooseRoot() {
        Toast.makeText(this, "اسمح بصلاحية الروت للتطبيق في KernelSU/Magisk…", Toast.LENGTH_LONG).show()
        Thread {
            val ok = RootTools.hasRoot() && RootTools.setup(this)
            runOnUiThread {
                if (ok) {
                    Prefs.setInt(this, Prefs.K_MODE, 2)
                    Toast.makeText(this, "تم تفعيل وضع الروت وتهيئة الأذونات", Toast.LENGTH_LONG).show()
                } else {
                    Prefs.setInt(this, Prefs.K_MODE, 1)
                    Toast.makeText(this, "لم تُمنح صلاحية الروت، سيعمل التطبيق كمستخدم عادي", Toast.LENGTH_LONG).show()
                }
                recreate()
            }
        }.start()
    }

    // ---------------- UI ----------------

    private fun chips(key: String, def: Int, items: List<String>, after: (Int) -> Unit = {}): ChipRow {
        val sel = Prefs.int(this, key, def).coerceIn(0, items.size - 1)
        return ChipRow(this, items, sel) { i ->
            Prefs.setInt(this, key, i)
            after(i)
        }
    }

    private fun pill(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 15f
            typeface = Fonts.bold(context)
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(bg, 24)
            setPadding(dp(12), dp(13), dp(12), dp(13))
            setOnClickListener { onClick() }
        }

    private fun prefSwitch(text: String, sub: String?, key: String, def: Boolean, onChange: (Boolean) -> Boolean = { true }): LinearLayout =
        switchRow(text, sub, Prefs.bool(this, key, def)) { on ->
            if (onChange(on)) { Prefs.setBool(this, key, on); true } else false
        }

    private fun applyPreset(i: Int) {
        // 0 saver, 1 balanced, 2 quality
        val q = intArrayOf(0, 1, 2)[i]
        val f = intArrayOf(1, 3, 3)[i]
        val b = intArrayOf(3, 5, 7)[i]
        Prefs.setInt(this, Prefs.K_QUALITY, q)
        Prefs.setInt(this, Prefs.K_FPS, f)
        Prefs.setInt(this, Prefs.K_BITRATE, b)
        qualRow.select(q, false)
        fpsRow.select(f, false)
        brRow.select(b, false)
    }

    private fun markCustom() {
        Prefs.setInt(this, Prefs.K_PRESET, 3)
        presetRow.select(3, false)
    }

    private fun xhChanged() {
        xhPreview.load()
        CrosshairService.reload()
    }

    private fun gap(h: Int) = View(this).apply { minimumHeight = dp(h) }

    private fun buildUi() {
        val dm = realMetrics()
        val nShort = min(dm.widthPixels, dm.heightPixels)
        val nLong = max(dm.widthPixels, dm.heightPixels)
        val maxHz = maxRefreshRate()
        val rootUser = Prefs.isRootUser(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(32))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---- large title (iOS style)
        root.addView(label("Game Frames", 34f).apply { typeface = Fonts.bold(context); setPadding(dp(4), dp(6), 0, 0) })
        root.addView(
            label("شاشتك: $nLong×$nShort · حتى ${maxHz}Hz" + if (rootUser) " · وضع الروت" else "", 13f, LABEL2)
                .apply { setPadding(dp(4), dp(2), 0, dp(8)) }
        )

        // ---- status (recording is started from the floating button or the side panel)
        val hero = card()
        status = label("جاهز", 21f, Color.WHITE).apply {
            typeface = Fonts.bold(context)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }
        statusSub = label("ابدأ التسجيل من الزر العائم أو من القائمة الجانبية", 12.5f, LABEL2).apply { gravity = Gravity.CENTER }
        hero.addView(status)
        hero.addView(statusSub)
        root.addView(hero)

        // ---- video
        val video = card("تسجيل الشاشة", "اختر جاهزًا أو عدّل بنفسك. كله يُسجَّل بالقيم المختارة فعلًا.")
        presetRow = chips(Prefs.K_PRESET, 3, listOf("توفير", "متوازن", "جودة", "مخصص")) { i ->
            if (i < 3) applyPreset(i)
        }
        video.addView(caption("جاهزيات سريعة"))
        video.addView(presetRow)

        val qItems = listOf(720, 1080, 1440, 2160).map {
            val n = when (it) { 1440 -> "1440p (2K)"; 2160 -> "2160p (4K)"; else -> "${it}p" }
            if (it > nShort) "$n ↑" else n
        } + "أصلية (${nShort}p)"
        qualRow = chips(Prefs.K_QUALITY, 1, qItems) { markCustom() }
        video.addView(caption("الدقة   (↑ = أعلى من شاشتك)"))
        video.addView(qualRow)

        val fItems = Prefs.FPS_LIST.map { if (it > maxHz) "$it ⚠" else "$it" }
        fpsRow = chips(Prefs.K_FPS, 3, fItems) { markCustom() }
        video.addView(caption("الفريمات FPS   (⚠ = فوق معدل تحديث شاشتك)"))
        video.addView(fpsRow)

        brRow = chips(Prefs.K_BITRATE, 0, Prefs.BITRATES.map { if (it == 0) "تلقائي" else "$it Mbps" }) { markCustom() }
        video.addView(caption("البتريت Bitrate"))
        video.addView(brRow)

        video.addView(caption("صيغة الفيديو (الترميز)"))
        video.addView(chips(Prefs.K_CODEC, 0, listOf("تلقائي", "H.264 (AVC)", "HEVC (H.265)")))
        video.addView(label("HEVC حجم أصغر بنفس الجودة. إن لم يدعمه هاتفك يرجع تلقائيًا لـ H.264 ويُبلغك.", 11.5f, LABEL2)
            .apply { setPadding(dp(2), dp(6), 0, 0) })
        root.addView(video)

        // ---- audio + orientation
        val av = card("الصوت والاتجاه")
        av.addView(caption("مصدر الصوت"))
        av.addView(chips(Prefs.K_AUDIO, 1, listOf("بدون صوت", "صوت اللعبة", "الميكروفون", "اللعبة + المايك")))
        av.addView(caption("اتجاه التسجيل"))
        av.addView(chips(Prefs.K_ORIENT, 0, listOf("تلقائي", "أفقي (ألعاب)", "عمودي")))
        root.addView(av)

        // ---- long recordings
        val long = card("تسجيل طويل", "يقسّم الفيديو لأجزاء حتى لا يتضخم ملف واحد ولا يضيع كله إن حدث خلل.")
        long.addView(caption("تقسيم تلقائي كل"))
        long.addView(chips(Prefs.K_SPLIT, 3, listOf("بدون", "10 د", "20 د", "30 د", "60 د")))
        long.addView(caption("تأخير البدء (عند البدء من التطبيق)"))
        long.addView(chips(Prefs.K_DELAY, 1, listOf("بدون", "3 ث", "5 ث", "10 ث")))
        root.addView(long)

        // ---- floating button
        val ctl = card("زر التحكم العائم", "دائرة فوق اللعبة فيها الوقت؛ اضغطها لتظهر أزرار البدء والإيقاف المؤقت والإنهاء.")
        ctl.addView(prefSwitch("تشغيل الزر العائم", null, Prefs.K_BUBBLE, false) { on ->
            if (on) startBubble() else {
                stopService(Intent(this, BubbleService::class.java))
                true
            }
        })
        ctl.addView(prefSwitch("إخفاء من الفيديو", "يختفي الزر أثناء التسجيل بدون أي مربع أسود. تحكّم من القائمة الجانبية (تُوقف التسجيل مؤقتًا وهي مفتوحة)", Prefs.K_HIDE_BUBBLE, false))
        root.addView(ctl)

        // ---- stand-alone FPS meter
        val fc = card("عدّاد FPS", "يعمل لحاله بدون تسجيل.")
        fpsRowSw = switchRow(
            "تشغيل عدّاد FPS",
            if (rootUser) "وضع الروت: يقرأ فريمات اللعبة الحقيقية" else "بدون روت: يقيس فريمات الشاشة وقد يطلب إذن التقاط الشاشة",
            FpsOverlayService.alive
        ) { on -> if (on) startFps() else { stopService(Intent(this, FpsOverlayService::class.java)); Prefs.setBool(this, Prefs.K_FPS_ON, false); true } }
        fc.addView(fpsRowSw)
        fc.addView(sliderRow("حجم الخط", 10, 36, Prefs.int(this, Prefs.K_FPS_SIZE, 14), "") { v ->
            Prefs.setInt(this, Prefs.K_FPS_SIZE, v); FpsOverlayService.reload()
        })
        fc.addView(prefSwitch("إظهار مستوى البطارية", "بجانب FPS", Prefs.K_FPS_BATT, false) { FpsOverlayService.reload(); true })
        fc.addView(prefSwitch("إظهار حرارة البطارية", "بجانب FPS", Prefs.K_FPS_TEMP, false) { FpsOverlayService.reload(); true })
        fc.addView(prefSwitch("إظهار REC أثناء التسجيل", "فريمات الفيديو المسجَّل في سطر ثانٍ", Prefs.K_FPS_REC_LINE, false) { FpsOverlayService.reload(); true })
        root.addView(fc)

        // ---- auto clicker
        val ac = card("النقر التلقائي", "ضع علامات A و B و C فوق الأزرار في اللعبة، واضغط ▶ فينقر عليها تباعًا حتى تضغط ■.")
        acRowSw = switchRow("إظهار لوحة النقر التلقائي", null, ClickerService.alive) { on ->
            if (on) startClicker() else { stopService(Intent(this, ClickerService::class.java)); Prefs.setBool(this, Prefs.K_AC_ON, false); true }
        }
        ac.addView(acRowSw)
        acAccText = label("", 12.5f, LABEL2).apply { setPadding(dp(2), dp(4), 0, dp(2)) }
        ac.addView(acAccText)
        ac.addView(pill("فتح إعدادات إمكانية الوصول", Color.parseColor("#33FFFFFF"), Color.WHITE) {
            Toast.makeText(this, "اختر «Game Frames - النقر التلقائي» ثم فعّله", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(4)) })
        ac.addView(label("السرعة وباقي الإعدادات (الفاصل، مدة الضغطة، عدد الجولات، العشوائية) من زر ⚙ في اللوحة نفسها.", 11.5f, LABEL2)
            .apply { setPadding(dp(2), dp(6), 0, 0) })
        root.addView(ac)

        // ---- side panel
        val ed = card("القائمة الجانبية", "اسحب من حافة الشاشة لفتح أدوات سريعة فوق اللعبة (تسجيل، FPS، كروس هير، نقر تلقائي، إبقاء الشاشة مضاءة…).")
        edRowSw = switchRow("تشغيل القائمة الجانبية", null, EdgeService.alive) { on ->
            if (on) startEdge() else { stopService(Intent(this, EdgeService::class.java)); Prefs.setBool(this, Prefs.K_EDGE_ON, false); true }
        }
        ed.addView(edRowSw)
        ed.addView(caption("مكان الحافة"))
        ed.addView(chips(Prefs.K_EDGE_SIDE, 0, listOf("يسار", "يمين")) { EdgeService.reload() })
        ed.addView(sliderRow("ارتفاع منطقة السحب", 10, 100, Prefs.int(this, Prefs.K_EDGE_SIZE, 35), "%") { v ->
            Prefs.setInt(this, Prefs.K_EDGE_SIZE, v); EdgeService.reload()
        })
        ed.addView(prefSwitch("إيقاف التسجيل مؤقتًا أثناء فتح القائمة", "عند تفعيل «إخفاء من الفيديو» حتى لا تظهر القائمة في الفيديو", Prefs.K_EDGE_PAUSE, true))
        ed.addView(prefSwitch("إبقاء الشاشة مضاءة", "لا تنطفئ الشاشة أثناء اللعب", Prefs.K_KEEP_AWAKE, false) { EdgeService.reload(); true })
        root.addView(ed)

        // ---- crosshair
        val xc = card("الكروس هير", "علامة تصويب فوق اللعبة، لا تمنع اللمس.")
        xhRowSw = switchRow("تشغيل الكروس هير", null, CrosshairService.alive) { on ->
            if (on) startCrosshair() else { stopService(Intent(this, CrosshairService::class.java)); Prefs.setBool(this, Prefs.K_XH_ON, false); true }
        }
        xc.addView(xhRowSw)

        // live preview
        xhPreview = CrosshairView(this)
        val previewBox = FrameLayout(this).apply {
            background = rounded(Color.parseColor("#66000000"), 20, GLASS_EDGE_BOT, 1)
            addView(xhPreview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        xc.addView(previewBox, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(6), 0, dp(6)) })

        xc.addView(caption("الشكل (${Xh.COUNT} شكل)"))
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val cur = Prefs.int(this, Prefs.K_XH_SHAPE, 3).coerceIn(0, Xh.COUNT - 1)
        for (i in 0 until Xh.COUNT) {
            val tile = FrameLayout(this).apply {
                addView(CrosshairView(context, 30, i), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                setOnClickListener {
                    Prefs.setInt(this@MainActivity, Prefs.K_XH_SHAPE, i)
                    paintTiles(i); xhChanged()
                }
            }
            shapeTiles.add(tile)
            tiles.addView(tile, LinearLayout.LayoutParams(dp(58), dp(58)).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) })
        }
        paintTiles(cur)
        xc.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tiles)
        })

        xc.addView(sliderRow("الحجم", 8, 160, Prefs.int(this, Prefs.K_XH_SIZE, 36), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_SIZE, v); xhChanged() })
        xc.addView(sliderRow("السماكة", 1, 10, (Prefs.int(this, Prefs.K_XH_THICK, 20) / 10).coerceIn(1, 10), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_THICK, v * 10); xhChanged() })
        xc.addView(sliderRow("الفراغ في الوسط", 0, 40, Prefs.int(this, Prefs.K_XH_GAP, 6), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_GAP, v); xhChanged() })
        xc.addView(sliderRow("الشفافية", 10, 100, Prefs.int(this, Prefs.K_XH_ALPHA, 100), "%") { v -> Prefs.setInt(this, Prefs.K_XH_ALPHA, v); xhChanged() })
        xc.addView(sliderRow("الإزاحة أفقيًا", -300, 300, Prefs.int(this, Prefs.K_XH_DX, 0), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_DX, v); xhChanged() })
        xc.addView(sliderRow("الإزاحة عموديًا", -300, 300, Prefs.int(this, Prefs.K_XH_DY, 0), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_DY, v); xhChanged() })

        xc.addView(caption("اللون"))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val dots = ArrayList<View>()
        fun paintDots() {
            val sel = Prefs.int(this, Prefs.K_XH_COLOR, Prefs.XH_COLORS[0])
            dots.forEachIndexed { i, d ->
                d.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Prefs.XH_COLORS[i])
                    if (Prefs.XH_COLORS[i] == sel) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), Color.parseColor("#55FFFFFF"))
                }
            }
        }
        Prefs.XH_COLORS.forEachIndexed { i, col ->
            val d = View(this).apply {
                setOnClickListener { Prefs.setInt(this@MainActivity, Prefs.K_XH_COLOR, col); paintDots(); xhChanged() }
            }
            dots.add(d)
            colors.addView(d, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) })
        }
        paintDots()
        xc.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colors) })
        xc.addView(prefSwitch("حدّ أسود حول العلامة", "لتظهر على أي خلفية", Prefs.K_XH_OUTLINE, true) { xhChanged(); true }.also {
            // reload after the preference is written
            (it.getChildAt(1) as IosSwitch).let { sw ->
                val old = sw.onToggle
                sw.onToggle = { v -> old?.invoke(v); xhChanged() }
            }
        })
        root.addView(xc)

        // ---- root only
        if (rootUser) {
            val rc = card("وضع الروت", "ميزات تعمل فقط مع صلاحية الروت.")
            rc.addView(
                pill("إعادة تهيئة الأذونات بالروت", Color.parseColor("#33FFFFFF"), Color.WHITE) {
                    Toast.makeText(this, "جارٍ التهيئة…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val ok = RootTools.setup(this)
                        runOnUiThread {
                            Toast.makeText(this, if (ok) "تمت التهيئة ✓" else "فشلت: تأكد من منح الروت للتطبيق", Toast.LENGTH_LONG).show()
                        }
                    }.start()
                },
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, dp(8), 0, 0) }
            )
            root.addView(rc)
        }

        // ---- review
        val rv = card("المراجعة")
        btnLast = pill("مراجعة آخر تسجيل", Color.parseColor("#33FFFFFF"), Color.WHITE) {
            RecorderService.lastUri?.let { openReview(it) }
        }
        val btnPick = pill("فتح فيديو للمراجعة", Color.parseColor("#33FFFFFF"), Color.WHITE) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(i, reqPick)
        }
        val half = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(10), dp(4), 0) } }
        val rrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rrow.addView(btnLast, half())
        rrow.addView(btnPick, half())
        rv.addView(rrow)
        root.addView(rv)

        // ---- user type
        val ut = card("نوع الاستخدام")
        val modeSel = (Prefs.int(this, Prefs.K_MODE, 1) - 1).coerceIn(0, 1)
        ut.addView(ChipRow(this, listOf("مستخدم عادي", "مستخدم روت"), modeSel) { i ->
            if (i == 1) {
                chooseRoot()
            } else {
                Prefs.setInt(this, Prefs.K_MODE, 1)
                recreate()
            }
        })
        root.addView(ut)

        // ---- tips
        root.addView(
            card(
                "نصائح للألعاب الثقيلة",
                "• ابدأ بـ «متوازن» أو «توفير» إذا شعرت بتقطيع: الدقة والبتريت الأقل يخفّفان الحمل.\n" +
                    "• لا يتجاوز FPS المسجّل معدل تحديث شاشتك ولا FPS اللعبة نفسها.\n" +
                    "• التقسيم التلقائي (30 د) مناسب للتسجيل الطويل.\n" +
                    "• صوت اللعبة يُلتقط مباشرة، وبعض الألعاب تمنع التقاطه.\n" +
                    "• الفيديوهات في Movies/GameFrames، واللقطات في Pictures/GameFrames."
            )
        )

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(root)
        }
        setContentView(FrameLayout(this).apply {
            addView(AuroraBg(context), FrameLayout.LayoutParams(-1, -1))
            addView(scroll, FrameLayout.LayoutParams(-1, -1))
        })
    }

    private fun paintTiles(sel: Int) {
        shapeTiles.forEachIndexed { i, t ->
            t.background = if (i == sel) rounded(Color.parseColor("#400A84FF"), 16, IOS_BLUE, 2)
            else rounded(Color.parseColor("#1AFFFFFF"), 16, GLASS_EDGE_BOT, 1)
        }
    }

    private fun startFps(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل العدّاد", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        Prefs.setBool(this, Prefs.K_FPS_ON, true)
        if (Prefs.isRootUser(this)) {
            startForegroundService(Intent(this, FpsOverlayService::class.java))
            return true
        }
        // no root: ask for screen-capture consent once (the screen is only counted, never saved)
        startActivity(Intent(this, CaptureActivity::class.java).putExtra("fps", true))
        return false
    }

    private fun startClicker(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل النقر التلقائي", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        Prefs.setBool(this, Prefs.K_AC_ON, true)
        startForegroundService(Intent(this, ClickerService::class.java))
        return true
    }

    private fun startEdge(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل القائمة الجانبية", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        Prefs.setBool(this, Prefs.K_EDGE_ON, true)
        startForegroundService(Intent(this, EdgeService::class.java))
        return true
    }

    private fun startCrosshair(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل الكروس هير", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        Prefs.setBool(this, Prefs.K_XH_ON, true)
        startForegroundService(Intent(this, CrosshairService::class.java))
        return true
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        // bring the floating button back after the app was restarted
        if (Prefs.bool(this, Prefs.K_BUBBLE, false) && Settings.canDrawOverlays(this) && !BubbleService.alive) {
            startForegroundService(Intent(this, BubbleService::class.java))
        }
        if (Prefs.bool(this, Prefs.K_XH_ON, false) && Settings.canDrawOverlays(this) && !CrosshairService.alive) {
            startForegroundService(Intent(this, CrosshairService::class.java))
        }
        if (Prefs.bool(this, Prefs.K_AC_ON, false) && Settings.canDrawOverlays(this) && !ClickerService.alive) {
            startForegroundService(Intent(this, ClickerService::class.java))
        }
        if (Prefs.bool(this, Prefs.K_EDGE_ON, false) && Settings.canDrawOverlays(this) && !EdgeService.alive) {
            startForegroundService(Intent(this, EdgeService::class.java))
        }
        if (Prefs.bool(this, Prefs.K_FPS_ON, false) && Prefs.isRootUser(this) &&
            Settings.canDrawOverlays(this) && !FpsOverlayService.alive
        ) {
            startForegroundService(Intent(this, FpsOverlayService::class.java))
        }
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun startBubble(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل الزر", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        return true
    }

    private fun refresh() {
        val running = RecorderService.running
        val paused = RecorderService.paused
        btnLast.alpha = if (RecorderService.lastUri != null) 1f else 0.4f
        (fpsRowSw.getChildAt(1) as IosSwitch).checked = FpsOverlayService.alive
        (xhRowSw.getChildAt(1) as IosSwitch).checked = CrosshairService.alive
        (acRowSw.getChildAt(1) as IosSwitch).checked = ClickerService.alive
        (edRowSw.getChildAt(1) as IosSwitch).checked = EdgeService.alive
        if (AutoClickService.enabled) {
            acAccText.text = "خدمة النقر: مفعّلة ✓"
            acAccText.setTextColor(IOS_GREEN)
        } else {
            acAccText.text = "خدمة النقر: غير مفعّلة. لازم تفعّلها من إمكانية الوصول حتى تعمل النقرات."
            acAccText.setTextColor(IOS_ORANGE)
        }

        if (running) {
            val now = SystemClock.elapsedRealtime()
            if (now < RecorderService.startMs) {
                val left = (RecorderService.startMs - now + 999) / 1000
                status.text = "يبدأ بعد $left ث"
                status.setTextColor(IOS_ORANGE)
                statusSub.text = "انتقل للعبة الآن"
            } else {
                val s = RecorderService.recordedSec()
                val t = "%02d:%02d".format(s / 60, s % 60)
                if (paused) {
                    status.text = "متوقف مؤقتًا  $t"
                    status.setTextColor(IOS_ORANGE)
                } else {
                    status.text = "جارٍ التسجيل  $t"
                    status.setTextColor(IOS_RED)
                }
                statusSub.text = "أنهِ التسجيل من الزر العائم أو القائمة الجانبية"
            }
        } else {
            status.text = "جاهز"
            status.setTextColor(Color.WHITE)
            statusSub.text = "ابدأ التسجيل من الزر العائم أو من القائمة الجانبية"
        }
    }

    private fun togglePause() {
        if (!RecorderService.running) return
        val a = if (RecorderService.paused) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE
        startService(Intent(this, RecorderService::class.java).setAction(a))
    }

    private fun start() {
        if (Prefs.int(this, Prefs.K_AUDIO, 1) != 0 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqAudioPerm)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqAudioPerm) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                start()
            } else {
                Toast.makeText(this, "الصوت يحتاج إذن التسجيل الصوتي. اختر «بدون صوت» أو اسمح بالإذن.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stop() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                startForegroundService(Prefs.recorderIntent(this, resultCode, data))
                val d = Prefs.DELAYS[Prefs.int(this, Prefs.K_DELAY, 1).coerceIn(0, Prefs.DELAYS.size - 1)]
                val msg = if (d > 0) "سيبدأ التسجيل بعد $d ثوان، انتقل للعبة" else "بدأ التسجيل، ارجع للعبة"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        } else if (requestCode == reqPick && resultCode == RESULT_OK) {
            data?.data?.let { openReview(it) }
        }
    }

    private fun openReview(uri: Uri) {
        startActivity(
            Intent(this, ReviewActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
