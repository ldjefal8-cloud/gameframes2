package com.gameframes.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val reqPick = 101

    private lateinit var fpsRowSw: LinearLayout
    private lateinit var xhRowSw: LinearLayout
    private lateinit var xhPreview: CrosshairView
    private val shapeTiles = ArrayList<FrameLayout>()
    private lateinit var btnLast: TextView

    private lateinit var presetRow: ChipRow
    private lateinit var qualRow: ChipRow
    private lateinit var fpsRow: ChipRow
    private lateinit var brRow: ChipRow

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Prefs.int(this, Prefs.K_MODE, 0) == 0) askUserType()
    }

    // ---------------- first run: normal user or root user ----------------

    private fun askUserType() {
        AlertDialog.Builder(this)
            .setTitle("أهلًا بك في Game Frames")
            .setMessage(
                "هل تستخدم هاتفك بصلاحية الروت؟\n\n" +
                    "• مستخدم عادي: كل الميزات الأساسية تعمل بدون روت.\n" +
                    "• مستخدم روت: تُفعَّل ميزات إضافية: عدّاد FPS اللعبة الحقيقي، حماية التسجيل من الإغلاق، " +
                    "وإعطاء الأذونات تلقائيًا.\n\n" +
                    "يمكنك تغيير هذا الاختيار لاحقًا من الإعدادات."
            )
            .setCancelable(false)
            .setPositiveButton("مستخدم روت") { _, _ -> chooseRoot() }
            .setNegativeButton("مستخدم عادي") { _, _ ->
                Prefs.setInt(this, Prefs.K_MODE, 1)
                recreate()
            }
            .show()
    }

    /** Asks for su (the root manager shows its own prompt), then prepares permissions. */
    private fun chooseRoot() {
        Toast.makeText(this, "اسمح بصلاحية الروت للتطبيق في KernelSU/Magisk…", Toast.LENGTH_LONG).show()
        Thread {
            val ok = RootTools.hasRoot() && RootTools.setup(this)
            runOnUiThread {
                if (ok) {
                    Prefs.setInt(this, Prefs.K_MODE, 2)
                    Toast.makeText(this, "تم تفعيل وضع الروت وتهيئة الأذونات", Toast.LENGTH_LONG).show()
                } else {
                    Prefs.setInt(this, Prefs.K_MODE, 1)
                    Toast.makeText(this, "لم تُمنح صلاحية الروت، سيعمل التطبيق كمستخدم عادي", Toast.LENGTH_LONG).show()
                }
                recreate()
            }
        }.start()
    }

    // ---------------- UI ----------------

    private fun chips(key: String, def: Int, items: List<String>, after: (Int) -> Unit = {}): ChipRow {
        val sel = Prefs.int(this, key, def).coerceIn(0, items.size - 1)
        return ChipRow(this, items, sel) { i ->
            Prefs.setInt(this, key, i)
            after(i)
        }
    }

    private fun pill(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(bg, 24)
            setPadding(dp(12), dp(13), dp(12), dp(13))
            setOnClickListener { onClick() }
        }

    private fun prefSwitch(text: String, sub: String?, key: String, def: Boolean, onChange: (Boolean) -> Boolean = { true }): LinearLayout =
        switchRow(text, sub, Prefs.bool(this, key, def)) { on ->
            if (onChange(on)) { Prefs.setBool(this, key, on); true } else false
        }

    private fun applyPreset(i: Int) {
        // 0 saver, 1 balanced, 2 quality
        val q = intArrayOf(0, 1, 2)[i]
        val f = intArrayOf(1, 3, 3)[i]
        val b = intArrayOf(3, 5, 7)[i]
        Prefs.setInt(this, Prefs.K_QUALITY, q)
        Prefs.setInt(this, Prefs.K_FPS, f)
        Prefs.setInt(this, Prefs.K_BITRATE, b)
        qualRow.select(q, false)
        fpsRow.select(f, false)
        brRow.select(b, false)
    }

    private fun markCustom() {
        Prefs.setInt(this, Prefs.K_PRESET, 3)
        presetRow.select(3, false)
    }

    private fun xhChanged() {
        xhPreview.load()
        CrosshairService.reload()
    }

    private fun gap(h: Int) = View(this).apply { minimumHeight = dp(h) }

    private fun buildUi() {
        val dm = realMetrics()
        val nShort = min(dm.widthPixels, dm.heightPixels)
        val nLong = max(dm.widthPixels, dm.heightPixels)
        val maxHz = maxRefreshRate()
        val rootUser = Prefs.isRootUser(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(32))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---- large title (iOS style)
        root.addView(label("Game Frames", 34f).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(6), 0, 0) })
        root.addView(
            label("شاشتك: $nLong×$nShort · حتى ${maxHz}Hz" + if (rootUser) " · وضع الروت" else "", 13f, LABEL2)
                .apply { setPadding(dp(4), dp(2), 0, dp(8)) }
        )

        // ---- floating button (recording starts from here only)
        val ctl = card("زر التسجيل العائم", "التسجيل يبدأ من هذا الزر فقط: دائرة كبيرة فوق اللعبة. اضغطها لتفتح الأزرار (إيقاف مؤقت، إنهاء، الكروس هير)، وعلامة ✕ تطويها فقط.")
        ctl.addView(prefSwitch("تشغيل الزر العائم", null, Prefs.K_BUBBLE, false) { on ->
            if (on) startBubble() else {
                stopService(Intent(this, BubbleService::class.java))
                true
            }
        })
        ctl.addView(caption("ظهور الزر في الفيديو"))
        ctl.addView(ChipRow(this, listOf("يظهر", "مخفي من الفيديو فقط", "مخفي أثناء التسجيل"), Prefs.bubbleVideoMode(this)) { i ->
            Prefs.setInt(this, Prefs.K_BUBBLE_VIDEO, i)
        })
        ctl.addView(label(
            "«مخفي من الفيديو فقط»: يبقى ظاهرًا لك على الشاشة ولا يدخل في التسجيل. " +
                "إن ظهر مربع أسود مكانه في هاتفك اختر «مخفي أثناء التسجيل».", 11.5f, LABEL2
        ).apply { setPadding(dp(2), dp(6), 0, 0) })
        root.addView(ctl)

        // ---- video
        val video = card("تسجيل الشاشة", "اختر جاهزًا أو عدّل بنفسك. كله يُسجَّل بالقيم المختارة فعلًا.")
        presetRow = chips(Prefs.K_PRESET, 3, listOf("توفير", "متوازن", "جودة", "مخصص")) { i ->
            if (i < 3) applyPreset(i)
        }
        video.addView(caption("جاهزيات سريعة"))
        video.addView(presetRow)

        val qItems = listOf(720, 1080, 1440, 2160).map {
            val n = when (it) { 1440 -> "1440p (2K)"; 2160 -> "2160p (4K)"; else -> "${it}p" }
            if (it > nShort) "$n ↑" else n
        } + "أصلية (${nShort}p)"
        qualRow = chips(Prefs.K_QUALITY, 1, qItems) { markCustom() }
        video.addView(caption("الدقة   (↑ = أعلى من شاشتك)"))
        video.addView(qualRow)

        val fItems = Prefs.FPS_LIST.map { if (it > maxHz) "$it ⚠" else "$it" }
        fpsRow = chips(Prefs.K_FPS, 3, fItems) { markCustom() }
        video.addView(caption("الفريمات FPS   (⚠ = فوق معدل تحديث شاشتك)"))
        video.addView(fpsRow)

        brRow = chips(Prefs.K_BITRATE, 0, Prefs.BITRATES.map { if (it == 0) "تلقائي" else "$it Mbps" }) { markCustom() }
        video.addView(caption("البتريت Bitrate"))
        video.addView(brRow)

        video.addView(caption("صيغة الفيديو (الترميز)"))
        video.addView(chips(Prefs.K_CODEC, 0, listOf("تلقائي", "H.264 (AVC)", "HEVC (H.265)")))
        video.addView(label("HEVC حجم أصغر بنفس الجودة. إن لم يدعمه هاتفك يرجع تلقائيًا لـ H.264 ويُبلغك.", 11.5f, LABEL2)
            .apply { setPadding(dp(2), dp(6), 0, 0) })
        root.addView(video)

        // ---- audio + orientation
        val av = card("الصوت والاتجاه")
        av.addView(caption("مصدر الصوت"))
        av.addView(chips(Prefs.K_AUDIO, 1, listOf("بدون صوت", "صوت اللعبة", "الميكروفون", "اللعبة + المايك")))
        av.addView(caption("اتجاه التسجيل"))
        av.addView(chips(Prefs.K_ORIENT, 0, listOf("تلقائي", "أفقي (ألعاب)", "عمودي")))
        root.addView(av)

        // ---- long recordings
        val long = card("تسجيل طويل", "يقسّم الفيديو لأجزاء حتى لا يتضخم ملف واحد ولا يضيع كله إن حدث خلل.")
        long.addView(caption("تقسيم تلقائي كل"))
        long.addView(chips(Prefs.K_SPLIT, 3, listOf("بدون", "10 د", "20 د", "30 د", "60 د")))
        long.addView(caption("تأخير البدء (عند البدء من التطبيق)"))
        long.addView(chips(Prefs.K_DELAY, 1, listOf("بدون", "3 ث", "5 ث", "10 ث")))
        root.addView(long)

        // ---- performance bar: FPS + battery temperature + battery level
        val fc = card("شريط الأداء", "FPS والحرارة والبطارية فوق اللعبة، كل واحد له مفتاحه. الحرارة والبطارية تعملان بدون تسجيل وبدون إذن التقاط الشاشة.")
        fpsRowSw = switchRow(
            "عرض FPS",
            if (rootUser) "وضع الروت: يعرض فريمات اللعبة الحقيقية (GAME)" else "بدون روت: يقيس فريمات الشاشة (FPS) وقد يطلب إذن التقاط الشاشة",
            FpsOverlayService.fpsActive
        ) { on ->
            if (on) startFps() else {
                Prefs.setBool(this, Prefs.K_FPS_ON, false)
                FpsOverlayService.dropCounter()
                true
            }
        }
        fc.addView(fpsRowSw)
        fc.addView(hudSwitch("عرض حرارة البطارية", "بالدرجة المئوية، يتلوّن عند السخونة", Prefs.K_HUD_TEMP))
        fc.addView(hudSwitch("عرض مستوى البطارية", "النسبة المئوية مع علامة الشحن", Prefs.K_HUD_BAT))
        fc.addView(sliderRow("حجم الخط", 10, 36, Prefs.int(this, Prefs.K_FPS_SIZE, 16), "") { v ->
            Prefs.setInt(this, Prefs.K_FPS_SIZE, v); FpsOverlayService.reload()
        })
        fc.addView(prefSwitch("إظهار REC أثناء التسجيل", "فريمات الفيديو المسجَّل في سطر ثانٍ", Prefs.K_FPS_REC_LINE, false) { FpsOverlayService.reload(); true })
        root.addView(fc)

        // ---- crosshair
        val xc = card("الكروس هير", "علامة تصويب فوق اللعبة، لا تمنع اللمس. للتعديل وأنت داخل اللعبة: افتح الزر العائم واضغط أيقونة الكروس هير.")
        xhRowSw = switchRow("تشغيل الكروس هير", null, CrosshairService.alive) { on ->
            if (on) startCrosshair() else { stopService(Intent(this, CrosshairService::class.java)); Prefs.setBool(this, Prefs.K_XH_ON, false); true }
        }
        xc.addView(xhRowSw)

        // live preview
        xhPreview = CrosshairView(this)
        val previewBox = FrameLayout(this).apply {
            background = rounded(Color.parseColor("#66000000"), 20, GLASS_EDGE_BOT, 1)
            addView(xhPreview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        xc.addView(previewBox, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(6), 0, dp(6)) })

        xc.addView(caption("الشكل (${Xh.COUNT} شكل)"))
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val cur = Prefs.int(this, Prefs.K_XH_SHAPE, 3).coerceIn(0, Xh.COUNT - 1)
        for (i in 0 until Xh.COUNT) {
            val tile = FrameLayout(this).apply {
                addView(CrosshairView(context, 30, i), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                setOnClickListener {
                    Prefs.setInt(this@MainActivity, Prefs.K_XH_SHAPE, i)
                    paintTiles(i); xhChanged()
                }
            }
            shapeTiles.add(tile)
            tiles.addView(tile, LinearLayout.LayoutParams(dp(58), dp(58)).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) })
        }
        paintTiles(cur)
        xc.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tiles)
        })

        xc.addView(sliderRow("الحجم", 8, 160, Prefs.int(this, Prefs.K_XH_SIZE, 36), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_SIZE, v); xhChanged() })
        xc.addView(sliderRow("السماكة", 1, 10, (Prefs.int(this, Prefs.K_XH_THICK, 20) / 10).coerceIn(1, 10), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_THICK, v * 10); xhChanged() })
        xc.addView(sliderRow("الفراغ في الوسط", 0, 40, Prefs.int(this, Prefs.K_XH_GAP, 6), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_GAP, v); xhChanged() })
        xc.addView(sliderRow("الشفافية", 10, 100, Prefs.int(this, Prefs.K_XH_ALPHA, 100), "%") { v -> Prefs.setInt(this, Prefs.K_XH_ALPHA, v); xhChanged() })
        xc.addView(sliderRow("الإزاحة أفقيًا", -300, 300, Prefs.int(this, Prefs.K_XH_DX, 0), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_DX, v); xhChanged() })
        xc.addView(sliderRow("الإزاحة عموديًا", -300, 300, Prefs.int(this, Prefs.K_XH_DY, 0), " dp") { v -> Prefs.setInt(this, Prefs.K_XH_DY, v); xhChanged() })

        xc.addView(caption("اللون"))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val dots = ArrayList<View>()
        fun paintDots() {
            val sel = Prefs.int(this, Prefs.K_XH_COLOR, Prefs.XH_COLORS[0])
            dots.forEachIndexed { i, d ->
                d.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Prefs.XH_COLORS[i])
                    if (Prefs.XH_COLORS[i] == sel) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), Color.parseColor("#55FFFFFF"))
                }
            }
        }
        Prefs.XH_COLORS.forEachIndexed { i, col ->
            val d = View(this).apply {
                setOnClickListener { Prefs.setInt(this@MainActivity, Prefs.K_XH_COLOR, col); paintDots(); xhChanged() }
            }
            dots.add(d)
            colors.addView(d, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) })
        }
        paintDots()
        xc.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colors) })
        xc.addView(prefSwitch("حدّ أسود حول العلامة", "لتظهر على أي خلفية", Prefs.K_XH_OUTLINE, true) { xhChanged(); true }.also {
            // reload after the preference is written
            (it.getChildAt(1) as IosSwitch).let { sw ->
                val old = sw.onToggle
                sw.onToggle = { v -> old?.invoke(v); xhChanged() }
            }
        })
        root.addView(xc)

        // ---- root only
        if (rootUser) {
            val rc = card("وضع الروت", "ميزات تعمل فقط مع صلاحية الروت.")
            rc.addView(
                pill("إعادة تهيئة الأذونات بالروت", Color.parseColor("#33FFFFFF"), Color.WHITE) {
                    Toast.makeText(this, "جارٍ التهيئة…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val ok = RootTools.setup(this)
                        runOnUiThread {
                            Toast.makeText(this, if (ok) "تمت التهيئة ✓" else "فشلت: تأكد من منح الروت للتطبيق", Toast.LENGTH_LONG).show()
                        }
                    }.start()
                },
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, dp(8), 0, 0) }
            )
            root.addView(rc)
        }

        // ---- review
        val rv = card("المراجعة")
        btnLast = pill("مراجعة آخر تسجيل", Color.parseColor("#33FFFFFF"), Color.WHITE) {
            RecorderService.lastUri?.let { openReview(it) }
        }
        val btnPick = pill("فتح فيديو للمراجعة", Color.parseColor("#33FFFFFF"), Color.WHITE) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(i, reqPick)
        }
        val half = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(10), dp(4), 0) } }
        val rrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rrow.addView(btnLast, half())
        rrow.addView(btnPick, half())
        rv.addView(rrow)
        root.addView(rv)

        // ---- user type
        val ut = card("نوع الاستخدام")
        val modeSel = (Prefs.int(this, Prefs.K_MODE, 1) - 1).coerceIn(0, 1)
        ut.addView(ChipRow(this, listOf("مستخدم عادي", "مستخدم روت"), modeSel) { i ->
            if (i == 1) {
                chooseRoot()
            } else {
                Prefs.setInt(this, Prefs.K_MODE, 1)
                recreate()
            }
        })
        root.addView(ut)

        // ---- tips
        root.addView(
            card(
                "نصائح للألعاب الثقيلة",
                "• ابدأ بـ «متوازن» أو «توفير» إذا شعرت بتقطيع: الدقة والبتريت الأقل يخفّفان الحمل.\n" +
                    "• لا يتجاوز FPS المسجّل معدل تحديث شاشتك ولا FPS اللعبة نفسها.\n" +
                    "• التقسيم التلقائي (30 د) مناسب للتسجيل الطويل.\n" +
                    "• صوت اللعبة يُلتقط مباشرة، وبعض الألعاب تمنع التقاطه.\n" +
                    "• الفيديوهات في Movies/GameFrames، واللقطات في Pictures/GameFrames."
            )
        )

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(root)
        }
        setContentView(FrameLayout(this).apply {
            addView(AuroraBg(context), FrameLayout.LayoutParams(-1, -1))
            addView(scroll, FrameLayout.LayoutParams(-1, -1))
        })
    }

    private fun paintTiles(sel: Int) {
        shapeTiles.forEachIndexed { i, t ->
            t.background = if (i == sel) rounded(Color.parseColor("#400A84FF"), 16, IOS_BLUE, 2)
            else rounded(Color.parseColor("#1AFFFFFF"), 16, GLASS_EDGE_BOT, 1)
        }
    }

    /** Switch for one part of the performance bar (temperature / battery); works without FPS counting. */
    private fun hudSwitch(text: String, sub: String, key: String): LinearLayout =
        switchRow(text, sub, Prefs.bool(this, key, false)) { on ->
            if (on && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل الخيار", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                false
            } else {
                Prefs.setBool(this, key, on)
                if (on && !FpsOverlayService.alive) startForegroundService(Intent(this, FpsOverlayService::class.java))
                else FpsOverlayService.reload()
                true
            }
        }

    private fun startFps(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل العدّاد", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        Prefs.setBool(this, Prefs.K_FPS_ON, true)
        if (Prefs.isRootUser(this)) {
            startForegroundService(Intent(this, FpsOverlayService::class.java))
            return true
        }
        // no root: ask for screen-capture consent once (the screen is only counted, never saved)
        startActivity(Intent(this, CaptureActivity::class.java).putExtra("fps", true))
        return false
    }

    private fun startCrosshair(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل الكروس هير", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        Prefs.setBool(this, Prefs.K_XH_ON, true)
        startForegroundService(Intent(this, CrosshairService::class.java))
        return true
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        // bring the floating button back after the app was restarted
        if (Prefs.bool(this, Prefs.K_BUBBLE, false) && Settings.canDrawOverlays(this) && !BubbleService.alive) {
            startForegroundService(Intent(this, BubbleService::class.java))
        }
        if (Prefs.bool(this, Prefs.K_XH_ON, false) && Settings.canDrawOverlays(this) && !CrosshairService.alive) {
            startForegroundService(Intent(this, CrosshairService::class.java))
        }
        val fpsWanted = Prefs.bool(this, Prefs.K_FPS_ON, false) && Prefs.isRootUser(this)
        val infoWanted = Prefs.bool(this, Prefs.K_HUD_TEMP, false) || Prefs.bool(this, Prefs.K_HUD_BAT, false)
        if ((fpsWanted || infoWanted) && Settings.canDrawOverlays(this) && !FpsOverlayService.alive) {
            startForegroundService(Intent(this, FpsOverlayService::class.java))
        }
        // crosshair values were changed from the panel over the game: rebuild so the sliders match
        if (XhPanel.dirty) {
            XhPanel.dirty = false
            handler.post { recreate() }
        }
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun startBubble(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل الزر", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        return true
    }

    private fun refresh() {
        btnLast.alpha = if (RecorderService.lastUri != null) 1f else 0.4f
        (fpsRowSw.getChildAt(1) as IosSwitch).checked = FpsOverlayService.fpsActive
        (xhRowSw.getChildAt(1) as IosSwitch).checked = CrosshairService.alive
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK) {
            data?.data?.let { openReview(it) }
        }
    }

    private fun openReview(uri: Uri) {
        startActivity(
            Intent(this, ReviewActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
