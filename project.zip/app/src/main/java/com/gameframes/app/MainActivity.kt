package com.gameframes.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val reqCapture = 100
    private val reqPick = 101
    private val reqAudioPerm = 102

    private lateinit var status: TextView
    private lateinit var statusSub: TextView
    private lateinit var recBtn: RecordButton
    private lateinit var pauseBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var btnLast: TextView

    private lateinit var presetRow: ChipRow
    private lateinit var qualRow: ChipRow
    private lateinit var fpsRow: ChipRow
    private lateinit var brRow: ChipRow

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Prefs.int(this, Prefs.K_MODE, 0) == 0) askUserType()
    }

    // ---------------- first run: normal user or root user ----------------

    private fun askUserType() {
        AlertDialog.Builder(this)
            .setTitle("أهلًا بك في Game Frames")
            .setMessage(
                "هل تستخدم هاتفك بصلاحية الروت؟\n\n" +
                    "• مستخدم عادي: كل الميزات الأساسية تعمل بدون روت.\n" +
                    "• مستخدم روت: تُفعَّل ميزات إضافية: عدّاد FPS اللعبة الحقيقي، حماية التسجيل من الإغلاق، " +
                    "وإعطاء الأذونات تلقائيًا.\n\n" +
                    "يمكنك تغيير هذا الاختيار لاحقًا من الإعدادات."
            )
            .setCancelable(false)
            .setPositiveButton("مستخدم روت") { _, _ -> chooseRoot() }
            .setNegativeButton("مستخدم عادي") { _, _ ->
                Prefs.setInt(this, Prefs.K_MODE, 1)
                recreate()
            }
            .show()
    }

    /** Asks for su (the root manager shows its own prompt), then prepares permissions. */
    private fun chooseRoot() {
        Toast.makeText(this, "اسمح بصلاحية الروت للتطبيق في KernelSU/Magisk…", Toast.LENGTH_LONG).show()
        Thread {
            val ok = RootTools.hasRoot() && RootTools.setup(this)
            runOnUiThread {
                if (ok) {
                    Prefs.setInt(this, Prefs.K_MODE, 2)
                    Toast.makeText(this, "تم تفعيل وضع الروت وتهيئة الأذونات", Toast.LENGTH_LONG).show()
                } else {
                    Prefs.setInt(this, Prefs.K_MODE, 1)
                    Toast.makeText(this, "لم تُمنح صلاحية الروت، سيعمل التطبيق كمستخدم عادي", Toast.LENGTH_LONG).show()
                }
                recreate()
            }
        }.start()
    }

    // ---------------- UI ----------------

    private fun chips(key: String, def: Int, items: List<String>, after: (Int) -> Unit = {}): ChipRow {
        val sel = Prefs.int(this, key, def).coerceIn(0, items.size - 1)
        return ChipRow(this, items, sel) { i ->
            Prefs.setInt(this, key, i)
            after(i)
        }
    }

    private fun pill(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(bg, 14)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            setOnClickListener { onClick() }
        }

    private fun switchRow(text: String, key: String, def: Boolean, onChange: (Boolean) -> Boolean = { true }): Switch =
        Switch(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            isChecked = Prefs.bool(this@MainActivity, key, def)
            setPadding(0, dp(8), 0, dp(8))
            var reverting = false
            setOnCheckedChangeListener { v, checked ->
                if (reverting) return@setOnCheckedChangeListener
                // onChange returns false to refuse (e.g. missing permission) and revert the switch
                if (onChange(checked)) {
                    Prefs.setBool(this@MainActivity, key, checked)
                } else {
                    reverting = true
                    v.isChecked = !checked
                    reverting = false
                }
            }
        }

    private fun applyPreset(i: Int) {
        // 0 saver, 1 balanced, 2 quality
        val q = intArrayOf(0, 1, 2)[i]
        val f = intArrayOf(1, 3, 3)[i]
        val b = intArrayOf(3, 5, 7)[i]
        Prefs.setInt(this, Prefs.K_QUALITY, q)
        Prefs.setInt(this, Prefs.K_FPS, f)
        Prefs.setInt(this, Prefs.K_BITRATE, b)
        qualRow.select(q, false)
        fpsRow.select(f, false)
        brRow.select(b, false)
    }

    private fun markCustom() {
        Prefs.setInt(this, Prefs.K_PRESET, 3)
        presetRow.select(3, false)
    }

    private fun buildUi() {
        val dm = realMetrics()
        val nShort = min(dm.widthPixels, dm.heightPixels)
        val nLong = max(dm.widthPixels, dm.heightPixels)
        val maxHz = maxRefreshRate()
        val rootUser = Prefs.isRootUser(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // ---- header
        root.addView(label("🎮 Game Frames", 26f).apply { typeface = Typeface.DEFAULT_BOLD })
        root.addView(
            label("سجّل ألعابك بجودة حقيقية، وراجع كل فريم بدقة.", 13f, MUTE)
                .apply { setPadding(0, dp(2), 0, dp(6)) }
        )
        root.addView(
            label("شاشتك: $nLong×$nShort · حتى ${maxHz}Hz" + if (rootUser) " · وضع الروت ✓" else "", 12f, ACCENT)
        )

        // ---- hero: big record button + status + pause / end
        val hero = card()
        hero.gravity = Gravity.CENTER_HORIZONTAL
        recBtn = RecordButton(this).apply {
            setOnClickListener { if (RecorderService.running) stop() else start() }
        }
        hero.addView(recBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(8), 0, dp(8)) })

        status = label("جاهز", 20f, ACCENT).apply {
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        statusSub = label("اضغط الدائرة للبدء", 12f, MUTE).apply { gravity = Gravity.CENTER }
        hero.addView(status)
        hero.addView(statusSub)

        pauseBtn = pill("⏸ إيقاف مؤقت", CHIP, Color.WHITE) { togglePause() }
        stopBtn = pill("■ إنهاء التسجيل", Color.parseColor("#7f1d1d"), Color.WHITE) { stop() }
        val ctrl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val half = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(12), dp(4), 0) } }
        ctrl.addView(pauseBtn, half())
        ctrl.addView(stopBtn, half())
        hero.addView(ctrl, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(hero)

        // ---- presets + video
        val video = card("الفيديو", "اختر جاهزًا أو عدّل بنفسك. كله يُسجَّل بالقيم المختارة فعلًا.")
        presetRow = chips(Prefs.K_PRESET, 3, listOf("⚡ توفير", "⚖ متوازن", "🎯 جودة", "✏ مخصص")) { i ->
            if (i < 3) applyPreset(i)
        }
        video.addView(caption("جاهزيات سريعة"))
        video.addView(presetRow)

        val qItems = listOf(720, 1080, 1440, 2160).map {
            val n = when (it) { 1440 -> "1440p (2K)"; 2160 -> "2160p (4K)"; else -> "${it}p" }
            if (it > nShort) "$n ↑" else n
        } + "أصلية (${nShort}p)"
        qualRow = chips(Prefs.K_QUALITY, 1, qItems) { markCustom() }
        video.addView(caption("الدقة   (↑ = أعلى من شاشتك)"))
        video.addView(qualRow)

        val fItems = Prefs.FPS_LIST.map { if (it > maxHz) "$it ⚠" else "$it" }
        fpsRow = chips(Prefs.K_FPS, 3, fItems) { markCustom() }
        video.addView(caption("الفريمات FPS   (⚠ = فوق معدل تحديث شاشتك)"))
        video.addView(fpsRow)

        brRow = chips(Prefs.K_BITRATE, 0, Prefs.BITRATES.map { if (it == 0) "تلقائي" else "$it Mbps" }) { markCustom() }
        video.addView(caption("البتريت Bitrate"))
        video.addView(brRow)
        root.addView(video)

        // ---- audio + orientation
        val av = card("الصوت والاتجاه")
        av.addView(caption("مصدر الصوت"))
        av.addView(chips(Prefs.K_AUDIO, 1, listOf("بدون صوت", "صوت اللعبة", "الميكروفون", "اللعبة + المايك")))
        av.addView(caption("اتجاه التسجيل"))
        av.addView(chips(Prefs.K_ORIENT, 0, listOf("تلقائي", "أفقي (ألعاب)", "عمودي")))
        root.addView(av)

        // ---- long recordings
        val long = card("تسجيل طويل", "يقسّم الفيديو لأجزاء حتى لا يتضخم ملف واحد ولا يضيع كله إن حدث خلل.")
        long.addView(caption("تقسيم تلقائي كل"))
        long.addView(chips(Prefs.K_SPLIT, 3, listOf("بدون", "10 د", "20 د", "30 د", "60 د")))
        long.addView(caption("تأخير البدء (عند البدء من التطبيق)"))
        long.addView(chips(Prefs.K_DELAY, 1, listOf("بدون", "3 ث", "5 ث", "10 ث")))
        root.addView(long)

        // ---- controls
        val ctl = card("التحكم والعرض")
        ctl.addView(switchRow("الزر العائم (ابدأ/أوقف من داخل اللعبة)", Prefs.K_BUBBLE, false) { on ->
            if (on) startBubble() else {
                stopService(Intent(this, BubbleService::class.java))
                true
            }
        })
        ctl.addView(switchRow("إخفاء الزر أثناء التسجيل (لا يظهر في الفيديو)", Prefs.K_HIDE_BUBBLE, false))
        ctl.addView(switchRow("عدّاد FPS فوق اللعبة", Prefs.K_OVERLAY, true))
        root.addView(ctl)

        // ---- root only
        if (rootUser) {
            val rc = card("وضع الروت", "ميزات تعمل فقط مع صلاحية الروت.")
            rc.addView(switchRow("عدّاد FPS اللعبة الحقيقي + حماية من الإغلاق", Prefs.K_ROOT_FEATURES, true))
            rc.addView(
                pill("🔧 إعادة تهيئة الأذونات بالروت", CHIP, Color.WHITE) {
                    Toast.makeText(this, "جارٍ التهيئة…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val ok = RootTools.setup(this)
                        runOnUiThread {
                            Toast.makeText(this, if (ok) "تمت التهيئة ✓" else "فشلت: تأكد من منح الروت للتطبيق", Toast.LENGTH_LONG).show()
                        }
                    }.start()
                },
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, dp(8), 0, 0) }
            )
            root.addView(rc)
        }

        // ---- review
        val rv = card("المراجعة")
        btnLast = pill("🎞 مراجعة آخر تسجيل", CHIP, Color.WHITE) {
            RecorderService.lastUri?.let { openReview(it) }
        }
        val btnPick = pill("📂 فتح فيديو للمراجعة", CHIP, Color.WHITE) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            startActivityForResult(i, reqPick)
        }
        val rrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rrow.addView(btnLast, half())
        rrow.addView(btnPick, half())
        rv.addView(rrow)
        root.addView(rv)

        // ---- user type
        val ut = card("نوع الاستخدام")
        val modeSel = (Prefs.int(this, Prefs.K_MODE, 1) - 1).coerceIn(0, 1)
        ut.addView(ChipRow(this, listOf("مستخدم عادي", "مستخدم روت"), modeSel) { i ->
            if (i == 1) {
                chooseRoot()
            } else {
                Prefs.setInt(this, Prefs.K_MODE, 1)
                recreate()
            }
        })
        root.addView(ut)

        // ---- tips
        root.addView(
            card(
                "نصائح للألعاب الثقيلة (مثل ببجي)",
                "• ابدأ بـ «⚖ متوازن» أو «⚡ توفير» إذا شعرت بتقطيع: الدقة والبتريت الأقل يخفّفان الحمل.\n" +
                    "• لا يتجاوز FPS المسجّل معدل تحديث شاشتك ولا FPS اللعبة نفسها.\n" +
                    "• التقسيم التلقائي (30 د) مناسب للتسجيل الطويل. تأكد من وجود مساحة كافية؛ يتوقف التسجيل ويحفظ ما سُجّل إذا قلّت المساحة.\n" +
                    "• صوت اللعبة يُلتقط مباشرة، وبعض الألعاب تمنع التقاطه.\n" +
                    "• الفيديوهات في Movies/GameFrames، واللقطات في Pictures/GameFrames."
            )
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        // bring the floating button back after the app was restarted
        if (Prefs.bool(this, Prefs.K_BUBBLE, false) && Settings.canDrawOverlays(this) && !BubbleService.alive) {
            startForegroundService(Intent(this, BubbleService::class.java))
        }
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun startBubble(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع وفعّل الزر", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        return true
    }

    private fun refresh() {
        val running = RecorderService.running
        val paused = RecorderService.paused
        btnLast.alpha = if (RecorderService.lastUri != null) 1f else 0.4f
        pauseBtn.alpha = if (running) 1f else 0.4f
        stopBtn.alpha = if (running) 1f else 0.4f

        if (running) {
            val now = SystemClock.elapsedRealtime()
            if (now < RecorderService.startMs) {
                val left = (RecorderService.startMs - now + 999) / 1000
                recBtn.state = 1
                status.text = "يبدأ بعد $left ث"
                status.setTextColor(AMBER)
                statusSub.text = "انتقل للعبة الآن"
                pauseBtn.alpha = 0.4f
            } else {
                val s = RecorderService.recordedSec()
                val t = "%02d:%02d".format(s / 60, s % 60)
                if (paused) {
                    recBtn.state = 2
                    status.text = "⏸ متوقف مؤقتًا  $t"
                    status.setTextColor(AMBER)
                    pauseBtn.text = "▶ استئناف"
                } else {
                    recBtn.state = 1
                    status.text = "● جارٍ التسجيل  $t"
                    status.setTextColor(REC_RED)
                    pauseBtn.text = "⏸ إيقاف مؤقت"
                }
                statusSub.text = "اضغط الدائرة أو «إنهاء» للإيقاف وحفظ الفيديو"
            }
        } else {
            recBtn.state = 0
            status.text = "جاهز"
            status.setTextColor(ACCENT)
            statusSub.text = "اضغط الدائرة للبدء"
            pauseBtn.text = "⏸ إيقاف مؤقت"
        }
    }

    private fun togglePause() {
        if (!RecorderService.running) return
        val a = if (RecorderService.paused) RecorderService.ACTION_RESUME else RecorderService.ACTION_PAUSE
        startService(Intent(this, RecorderService::class.java).setAction(a))
    }

    private fun start() {
        if (Prefs.int(this, Prefs.K_AUDIO, 1) != 0 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqAudioPerm)
            return
        }
        if (Prefs.bool(this, Prefs.K_OVERLAY, true) && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات» ثم ارجع واضغط بدء", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqAudioPerm) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                start()
            } else {
                Toast.makeText(this, "الصوت يحتاج إذن التسجيل الصوتي. اختر «بدون صوت» أو اسمح بالإذن.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun stop() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                startForegroundService(Prefs.recorderIntent(this, resultCode, data))
                val d = Prefs.DELAYS[Prefs.int(this, Prefs.K_DELAY, 1).coerceIn(0, Prefs.DELAYS.size - 1)]
                val msg = if (d > 0) "سيبدأ التسجيل بعد $d ثوان، انتقل للعبة" else "بدأ التسجيل، ارجع للعبة"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        } else if (requestCode == reqPick && resultCode == RESULT_OK) {
            data?.data?.let { openReview(it) }
        }
    }

    private fun openReview(uri: Uri) {
        startActivity(
            Intent(this, ReviewActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
