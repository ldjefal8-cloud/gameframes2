package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.random.Random

/** A draggable lettered target (A, B, C...) that is placed over a button of the game. */
class MarkerView(context: Context, var letter: String) : View(context) {
    var dim = false
        set(v) { if (field != v) { field = v; invalidate() } }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = context.dp(2).toFloat() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Fonts.bold(context)
        textSize = context.dp(17).toFloat()
        color = Color.WHITE
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(44), context.dp(44))

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = width / 2f - ring.strokeWidth
        fill.color = if (dim) Color.parseColor("#4D0A84FF") else Color.parseColor("#B30A84FF")
        ring.color = if (dim) Color.parseColor("#66FFFFFF") else Color.WHITE
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, ring)
        txt.alpha = if (dim) 120 else 255
        val m = txt.fontMetrics
        c.drawText(letter, cx, cy - (m.ascent + m.descent) / 2f, txt)
    }
}

/** Little grip so the control panel can be dragged by it. */
private class GripView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#80FFFFFF") }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(16), context.dp(30))
    override fun onDraw(c: Canvas) {
        val r = context.dp(2).toFloat()
        for (i in 0 until 3) for (j in 0 until 2)
            c.drawCircle(width / 2f + (j - 0.5f) * r * 3.2f, height / 2f + (i - 1) * r * 3.2f, r * 0.8f, p)
    }
}

/**
 * Auto clicker:
 *  - "+" adds a lettered marker; drag it over the button you want to tap.
 *  - ▶ taps the markers again and again (A, B, C... in order, or all together) until ■ is pressed.
 *  - ⚙ opens speed and other settings.
 * The taps themselves are sent by [AutoClickService] (accessibility).
 */
class ClickerService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.click.close"
        const val ACTION_TOGGLE = "gf.click.toggle"
        private const val CHANNEL = "clicker"
        @Volatile var instance: ClickerService? = null
        val alive get() = instance != null
        val running get() = instance?.isRunning == true
        fun toggle() { instance?.apply { handler.post { toggleRun() } } }
        const val MAX_MARKERS = 10
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private class Marker(val view: MarkerView, val lp: WindowManager.LayoutParams)
    private val markers = ArrayList<Marker>()

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var playBtn: FrameLayout? = null
    private var playIcon: IconView? = null
    private var settingsView: LinearLayout? = null
    private var settingsLp: WindowManager.LayoutParams? = null

    private var isRunning = false
    private var seqIndex = 0
    private var tapsDone = 0L
    private var runToken = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CLOSE -> { Prefs.setBool(this, Prefs.K_AC_ON, false); stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE -> { if (instance != null) toggleRun(); return START_NOT_STICKY }
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن «العرض فوق التطبيقات»", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        try { startFg() } catch (e: Exception) {
            Toast.makeText(this, "تعذّر تشغيل النقر التلقائي: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
        restoreMarkers()
        if (!AutoClickService.enabled) {
            Toast.makeText(this, "فعّل خدمة «النقر التلقائي» من إعدادات إمكانية الوصول حتى تعمل النقرات", Toast.LENGTH_LONG).show()
        }
        return START_NOT_STICKY
    }

    // ---------------- windows ----------------

    private fun overlayParams(touchable: Boolean = true): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    private fun buildPanel() {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                cornerRadius = dp(30).toFloat()
                setColor(Color.parseColor("#D91C1C1E"))
                setStroke(dp(1), Color.parseColor("#40FFFFFF"))
            }
            setPadding(dp(4), dp(4), dp(6), dp(4))
        }
        val grip = GripView(this)
        val play = glassCircle(32, IconView.PLAY, Color.parseColor("#E630D158"))
        val add = glassCircle(32, IconView.PLUS, Color.parseColor("#33FFFFFF"))
        val del = glassCircle(32, IconView.MINUS, Color.parseColor("#33FFFFFF"))
        val gear = glassCircle(32, IconView.GEAR, Color.parseColor("#33FFFFFF"))
        val close = glassCircle(26, IconView.CLOSE, Color.parseColor("#66787880"))
        playBtn = play
        playIcon = play.getChildAt(0) as IconView

        fun lp(sz: Int) = LinearLayout.LayoutParams(dp(sz), dp(sz)).apply { setMargins(dp(2), 0, dp(2), 0) }
        b.addView(grip, LinearLayout.LayoutParams(dp(16), dp(30)))
        b.addView(play, lp(32)); b.addView(add, lp(32)); b.addView(del, lp(32)); b.addView(gear, lp(32)); b.addView(close, lp(26))

        play.setOnClickListener { toggleRun() }
        add.setOnClickListener { addMarker() }
        del.setOnClickListener { removeMarker() }
        gear.setOnClickListener { toggleSettings() }
        close.setOnClickListener {
            Prefs.setBool(this, Prefs.K_AC_ON, false)
            stopSelf()
        }

        val p = overlayParams().apply {
            x = Prefs.int(this@ClickerService, Prefs.K_AC_PX, dp(8))
            y = Prefs.int(this@ClickerService, Prefs.K_AC_PY, dp(120))
        }
        panelLp = p; panel = b
        dragBy(grip, b, p) { Prefs.setInt(this, Prefs.K_AC_PX, p.x); Prefs.setInt(this, Prefs.K_AC_PY, p.y); moveSettingsNearPanel() }
        try { wm.addView(b, p) } catch (_: Exception) { stopSelf() }
    }

    /** Drag [target]'s window by touching [handle]. */
    private fun dragBy(handle: View, target: View, p: WindowManager.LayoutParams, onUp: () -> Unit) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                    try { wm.updateViewLayout(target, p) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { onUp(); true }
                else -> false
            }
        }
    }

    // ---------------- markers ----------------

    private fun letterOf(i: Int) = ('A' + i).toString()

    private fun addMarker(x: Int = -1, y: Int = -1) {
        if (markers.size >= MAX_MARKERS) {
            Toast.makeText(this, "الحد الأقصى $MAX_MARKERS علامات", Toast.LENGTH_SHORT).show()
            return
        }
        if (isRunning) return
        val dm = realMetrics()
        val i = markers.size
        val v = MarkerView(this, letterOf(i))
        val p = overlayParams()
        p.x = if (x >= 0) x else dm.widthPixels / 2 - dp(22) + (i % 4) * dp(54) - dp(80)
        p.y = if (y >= 0) y else dm.heightPixels / 2 - dp(22) + (i / 4) * dp(54)
        val m = Marker(v, p)

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(2) || abs(e.rawY - ty) > dp(2)) {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { saveMarkers(); true }
                else -> false
            }
        }
        try { wm.addView(v, p) } catch (_: Exception) { return }
        markers.add(m)
        saveMarkers()
    }

    private fun removeMarker() {
        if (isRunning || markers.isEmpty()) return
        val m = markers.removeAt(markers.size - 1)
        try { wm.removeView(m.view) } catch (_: Exception) {}
        saveMarkers()
    }

    private fun saveMarkers() {
        Prefs.setStr(this, Prefs.K_AC_MARKS, markers.joinToString(";") { "${it.lp.x},${it.lp.y}" })
    }

    private fun restoreMarkers() {
        val s = Prefs.str(this, Prefs.K_AC_MARKS, "")
        if (s.isEmpty()) return
        for (part in s.split(";")) {
            val xy = part.split(",")
            val x = xy.getOrNull(0)?.toIntOrNull() ?: continue
            val y = xy.getOrNull(1)?.toIntOrNull() ?: continue
            addMarker(x, y)
        }
    }

    // ---------------- running ----------------

    private fun toggleRun() { if (isRunning) stopRun() else startRun() }

    private fun startRun() {
        val svc = AutoClickService.instance
        if (svc == null) {
            Toast.makeText(this, "فعّل خدمة «النقر التلقائي» من إمكانية الوصول أولًا", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
            return
        }
        if (markers.isEmpty()) {
            Toast.makeText(this, "اضغط + لإضافة علامة وضعها على الزر", Toast.LENGTH_LONG).show()
            return
        }
        hideSettings()
        isRunning = true
        seqIndex = 0
        tapsDone = 0
        runToken++
        // markers must not catch the touches, they have to reach the game
        val hide = Prefs.bool(this, Prefs.K_AC_HIDE, false)
        for (m in markers) {
            m.lp.flags = m.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            m.view.dim = true
            m.view.visibility = if (hide) View.INVISIBLE else View.VISIBLE
            try { wm.updateViewLayout(m.view, m.lp) } catch (_: Exception) {}
        }
        playIcon?.set(IconView.STOP, Color.WHITE)
        (playBtn?.background as? GradientDrawable)?.setColor(Color.parseColor("#E6FF453A"))
        val token = runToken
        handler.postDelayed({ step(token) }, 150)
    }

    private fun stopRun() {
        isRunning = false
        runToken++
        handler.removeCallbacksAndMessages(null)
        for (m in markers) {
            m.lp.flags = m.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            m.view.dim = false
            m.view.visibility = View.VISIBLE
            try { wm.updateViewLayout(m.view, m.lp) } catch (_: Exception) {}
        }
        playIcon?.set(IconView.PLAY, Color.WHITE)
        (playBtn?.background as? GradientDrawable)?.setColor(Color.parseColor("#E630D158"))
    }

    private fun step(token: Int) {
        if (!isRunning || token != runToken) return
        val svc = AutoClickService.instance
        if (svc == null) {
            Toast.makeText(this, "خدمة النقر التلقائي توقفت", Toast.LENGTH_SHORT).show()
            stopRun(); return
        }
        val interval = Prefs.int(this, Prefs.K_AC_INTERVAL, 100)
        val hold = Prefs.int(this, Prefs.K_AC_HOLD, 30)
        val loops = Prefs.int(this, Prefs.K_AC_LOOPS, 0)
        val jitter = Prefs.int(this, Prefs.K_AC_JITTER, 0)
        val rand = Prefs.int(this, Prefs.K_AC_RANDOM, 0)
        val together = Prefs.int(this, Prefs.K_AC_MODE, 0) == 1

        val targets = if (together) markers.toList() else listOf(markers[seqIndex % markers.size])
        val loc = IntArray(2)
        val pts = targets.map { m ->
            m.view.getLocationOnScreen(loc)
            val jx = if (jitter > 0) Random.nextInt(-jitter, jitter + 1) else 0
            val jy = if (jitter > 0) Random.nextInt(-jitter, jitter + 1) else 0
            Pair(loc[0] + m.view.width / 2f + jx, loc[1] + m.view.height / 2f + jy)
        }
        seqIndex++

        val ok = svc.tap(pts, hold.toLong()) { _ ->
            handler.post {
                if (!isRunning || token != runToken) return@post
                tapsDone++
                // one "round" = every marker tapped once
                val perRound = if (together) 1 else markers.size
                if (loops > 0 && tapsDone >= loops.toLong() * perRound) { stopRun(); return@post }
                var wait = (interval - hold).coerceAtLeast(0)
                if (rand > 0) {
                    val d = interval * rand / 100
                    wait += if (d > 0) Random.nextInt(-d, d + 1) else 0
                }
                handler.postDelayed({ step(token) }, wait.coerceAtLeast(0).toLong())
            }
        }
        if (!ok) {
            // Android refused this gesture (busy); try again shortly instead of dying
            handler.postDelayed({ step(token) }, 120)
        }
    }

    // ---------------- settings card ----------------

    private fun toggleSettings() { if (settingsView == null) showSettings() else hideSettings() }

    private fun hideSettings() {
        settingsView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        settingsView = null
    }

    private fun moveSettingsNearPanel() {
        val s = settingsView ?: return
        val sp = settingsLp ?: return
        val pp = panelLp ?: return
        sp.x = pp.x; sp.y = pp.y + dp(48)
        try { wm.updateViewLayout(s, sp) } catch (_: Exception) {}
    }

    private fun showSettings() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.parseColor("#F2141418"), 22, GLASS_EDGE_TOP, 1)
            setPadding(dp(16), dp(12), dp(16), dp(14))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("إعدادات النقر التلقائي", 16f, Color.WHITE).apply { typeface = Fonts.bold(context) },
            LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(glassCircle(26, IconView.CLOSE, Color.parseColor("#33FFFFFF")).apply { setOnClickListener { hideSettings() } },
            LinearLayout.LayoutParams(dp(26), dp(26)))
        root.addView(head)

        root.addView(sliderRow("السرعة: الفاصل بين النقرات", 10, 2000, Prefs.int(this, Prefs.K_AC_INTERVAL, 100), " ms") {
            Prefs.setInt(this, Prefs.K_AC_INTERVAL, it)
        })
        root.addView(sliderRow("مدة الضغطة الواحدة", 1, 500, Prefs.int(this, Prefs.K_AC_HOLD, 30), " ms") {
            Prefs.setInt(this, Prefs.K_AC_HOLD, it)
        })
        root.addView(sliderRow("عدد الجولات (0 = بلا نهاية)", 0, 500, Prefs.int(this, Prefs.K_AC_LOOPS, 0), "") {
            Prefs.setInt(this, Prefs.K_AC_LOOPS, it)
        })
        root.addView(sliderRow("انحراف عشوائي عن مركز العلامة", 0, 40, Prefs.int(this, Prefs.K_AC_JITTER, 0), " px") {
            Prefs.setInt(this, Prefs.K_AC_JITTER, it)
        })
        root.addView(sliderRow("تغيير عشوائي في السرعة", 0, 50, Prefs.int(this, Prefs.K_AC_RANDOM, 0), "%") {
            Prefs.setInt(this, Prefs.K_AC_RANDOM, it)
        })
        root.addView(caption("طريقة النقر"))
        root.addView(ChipRow(this, listOf("بالتتابع A ثم B", "كلها معًا"), Prefs.int(this, Prefs.K_AC_MODE, 0).coerceIn(0, 1)) {
            Prefs.setInt(this, Prefs.K_AC_MODE, it)
        })
        root.addView(switchRow("إخفاء العلامات أثناء النقر", null, Prefs.bool(this, Prefs.K_AC_HIDE, false)) { on ->
            Prefs.setBool(this, Prefs.K_AC_HIDE, on); true
        })

        val dm = realMetrics()
        val w = minOf(dp(320), dm.widthPixels - dp(24))
        val sp = overlayParams().apply {
            width = w
            val pp = panelLp
            x = pp?.x ?: dp(8)
            y = (pp?.y ?: dp(120)) + dp(48)
            // keep it on screen
            if (x + w > dm.widthPixels) x = (dm.widthPixels - w).coerceAtLeast(0)
        }
        settingsLp = sp; settingsView = root
        try { wm.addView(root, sp) } catch (_: Exception) { settingsView = null }
    }

    // ---------------- service plumbing ----------------

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Auto clicker", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 9,
            Intent(this, ClickerService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("النقر التلقائي شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(5, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(5, n)
    }

    override fun onDestroy() {
        isRunning = false
        runToken++
        instance = null
        handler.removeCallbacksAndMessages(null)
        hideSettings()
        for (m in markers) try { wm.removeView(m.view) } catch (_: Exception) {}
        markers.clear()
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
}
