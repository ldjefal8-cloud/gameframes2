package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.ceil

/** A numbered target (A, B, C…) that is dragged over the button to be pressed. Its centre is the tap point. */
class MarkerView(context: Context, val index: Int, private val sizeDp: Int) : View(context) {
    companion object {
        val COLORS = intArrayOf(
            0xFF0A84FF.toInt(), 0xFFFF453A.toInt(), 0xFF30D158.toInt(), 0xFFFF9F0A.toInt(),
            0xFFBF5AF2.toInt(), 0xFF64D2FF.toInt(), 0xFFFF2D92.toInt(), 0xFFFFD60A.toInt()
        )
    }
    var on = true
        set(v) { if (field != v) { field = v; invalidate() } }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val letter = ('A' + index).toString()

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(sizeDp), context.dp(sizeDp))

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = width / 2f - context.dp(10)
        val col = COLORS[index % COLORS.size]
        val a = if (on) 255 else 90
        fun withA(color: Int, alpha: Int) = (color and 0x00FFFFFF) or ((alpha * a / 255) shl 24)
        p.style = Paint.Style.FILL; p.color = withA(col, 0x40)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = context.dp(2).toFloat(); p.color = withA(col, 0xFF)
        c.drawCircle(cx, cy, r, p)
        val t = r * 0.45f
        c.drawLine(cx - t, cy, cx + t, cy, p); c.drawLine(cx, cy - t, cx, cy + t, p)
        // letter badge on the upper right
        val bx = cx + r * 0.78f; val by = cy - r * 0.78f; val br = context.dp(9).toFloat()
        p.style = Paint.Style.FILL; p.color = withA(col, 0xFF)
        c.drawCircle(bx, by, br, p)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = br * 1.2f
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        c.drawText(letter, bx, by - (p.ascent() + p.descent()) / 2f, p)
    }
}

/**
 * Auto clicker: drag the lettered targets over the buttons you want pressed, then press ▶ and it keeps
 * pressing (one after another, all together, or swiping A → B) at the chosen speed until you press ■
 * or a limit is reached. Taps are sent by [ClickerAccessibilityService]; while running the targets let
 * touches through so the taps reach the game.
 */
class ClickerService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.cl.close"
        private const val CHANNEL = "clicker"
        private const val BASE =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        @Volatile var instance: ClickerService? = null
        val alive get() = instance != null
        fun rebuild() { instance?.apply { handler.post { buildMarkers() } } }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bar: LinearLayout? = null
    private lateinit var barLp: WindowManager.LayoutParams
    private lateinit var playIcon: IconView
    private lateinit var playBtn: FrameLayout
    private lateinit var status: TextView
    private val markers = ArrayList<MarkerView>()
    private val markerLps = ArrayList<WindowManager.LayoutParams>()
    private var panel: ClickerPanel? = null
    private val rnd = java.util.Random()

    private var running = false
    private var count = 0
    private var beginMs = 0L
    private var nextIdx = 0
    private var busy = false
    private var busySince = 0L

    private val ui = object : Runnable {
        override fun run() {
            updateStatus()
            if (running && !ClickerAccessibilityService.connected) {
                stopRun()
                Toast.makeText(this@ClickerService, "خدمة إمكانية الوصول توقفت", Toast.LENGTH_SHORT).show()
            }
            handler.postDelayed(this, 200)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) { stopSelf(); return START_NOT_STICKY }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        startFg()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBar()
        buildMarkers()
        handler.post(ui)
        return START_NOT_STICKY
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Auto clicker", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 9,
            Intent(this, ClickerService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("الضغط التلقائي شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(6, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(6, n)
    }

    // ---------------- control bar ----------------

    private fun buildBar() {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = GradientDrawable().apply {
                cornerRadius = dp(40).toFloat()
                setColor(Color.parseColor("#CC1C1C1E"))
                setStroke(dp(1), Color.parseColor("#40FFFFFF"))
            }
            setPadding(dp(5), dp(5), dp(8), dp(5))
        }
        playBtn = glassCircle(44, IconView.PLAY, Color.parseColor("#E60A84FF"))
        playIcon = playBtn.getChildAt(0) as IconView
        status = TextView(this).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
            minWidth = dp(54)
        }
        val add = glassCircle(32, IconView.PLUS, Color.parseColor("#33FFFFFF"))
        val del = glassCircle(32, IconView.MINUS, Color.parseColor("#33FFFFFF"))
        val set = glassCircle(32, IconView.SETTINGS, Color.parseColor("#33FFFFFF"))
        val close = glassCircle(28, IconView.CLOSE, Color.parseColor("#66787880"))
        fun lpOf(sz: Int) = LinearLayout.LayoutParams(dp(sz), dp(sz)).apply { setMargins(dp(2), 0, dp(2), 0) }
        b.addView(playBtn, lpOf(44))
        b.addView(status, LinearLayout.LayoutParams(-2, -2))
        b.addView(add, lpOf(32)); b.addView(del, lpOf(32)); b.addView(set, lpOf(32)); b.addView(close, lpOf(28))

        playBtn.setOnClickListener { if (running) stopRun() else startRun() }
        add.setOnClickListener { changeCount(1) }
        del.setOnClickListener { changeCount(-1) }
        set.setOnClickListener { togglePanel() }
        close.setOnClickListener { stopSelf() }

        barLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.int(this@ClickerService, Prefs.K_CL_BX, dp(8))
            y = Prefs.int(this@ClickerService, Prefs.K_CL_BY, dp(120))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = barLp.x; sy = barLp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(6) || abs(e.rawY - ty) > dp(6)) moved = true
                    if (moved) {
                        barLp.x = sx + (e.rawX - tx).toInt(); barLp.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(b, barLp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { Prefs.setInt(this, Prefs.K_CL_BX, barLp.x); Prefs.setInt(this, Prefs.K_CL_BY, barLp.y) }
                    true
                }
                else -> false
            }
        }
        try { wm.addView(b, barLp); bar = b } catch (_: Exception) { stopSelf() }
        updateStatus()
    }

    private fun togglePanel() {
        val p = panel
        if (p != null && p.shown) { p.hide(); return }
        (p ?: ClickerPanel(this, wm).also { panel = it }).show()
    }

    private fun changeCount(d: Int) {
        if (running) return
        val n = (Prefs.int(this, Prefs.K_CL_N, 1) + d).coerceIn(1, 8)
        Prefs.setInt(this, Prefs.K_CL_N, n)
        buildMarkers()
    }

    // ---------------- markers ----------------

    private fun buildMarkers() {
        for (m in markers) try { wm.removeView(m) } catch (_: Exception) {}
        markers.clear(); markerLps.clear()
        val n = Prefs.int(this, Prefs.K_CL_N, 1).coerceIn(1, 8)
        val sizeDp = Prefs.CL_SIZES[Prefs.int(this, Prefs.K_CL_SIZE, 1).coerceIn(0, Prefs.CL_SIZES.size - 1)]
        val screen = realMetrics()
        val mask = Prefs.int(this, Prefs.K_CL_MASK, 255)
        for (i in 0 until n) {
            val v = MarkerView(this, i, sizeDp)
            v.on = (mask shr i) and 1 == 1
            val half = dp(sizeDp) / 2
            val defX = screen.widthPixels / 2 + (i - (n - 1) / 2f).times(dp(sizeDp + 12)).toInt()
            val cx = Prefs.int(this, Prefs.clX(i), defX)
            val cy = Prefs.int(this, Prefs.clY(i), screen.heightPixels / 2)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE, PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = cx - half; y = cy - half }
            attachDrag(v, lp, i, half)
            try { wm.addView(v, lp); markers.add(v); markerLps.add(lp) } catch (_: Exception) {}
        }
        applyRunningState()
    }

    /** Drag moves the target; a short tap switches that target on/off. */
    private fun attachDrag(v: MarkerView, lp: WindowManager.LayoutParams, i: Int, half: Int) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(8) || abs(e.rawY - ty) > dp(8)) moved = true
                    if (moved) {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.setInt(this, Prefs.clX(i), lp.x + half); Prefs.setInt(this, Prefs.clY(i), lp.y + half)
                    } else {
                        val mask = Prefs.int(this, Prefs.K_CL_MASK, 255) xor (1 shl i)
                        Prefs.setInt(this, Prefs.K_CL_MASK, mask)
                        v.on = (mask shr i) and 1 == 1
                    }
                    true
                }
                else -> false
            }
        }
    }

    /** While running the targets let touches through (so the taps reach the game) and can hide. */
    private fun applyRunningState() {
        val hide = Prefs.bool(this, Prefs.K_CL_HIDE, false)
        for (i in markers.indices) {
            markerLps[i].flags = BASE or (if (running) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            markers[i].visibility = if (running && hide) View.INVISIBLE else View.VISIBLE
            try { wm.updateViewLayout(markers[i], markerLps[i]) } catch (_: Exception) {}
        }
    }

    // ---------------- engine ----------------

    private fun startRun() {
        if (running) return
        if (!ClickerAccessibilityService.connected) {
            Toast.makeText(this, "فعّل خدمة «الضغط التلقائي» في إمكانية الوصول أولًا (من التطبيق)", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
            return
        }
        val active = activeIndexes()
        if (active.isEmpty()) {
            Toast.makeText(this, "كل النقاط معطّلة. اضغط على نقطة لتفعيلها", Toast.LENGTH_SHORT).show(); return
        }
        if (Prefs.int(this, Prefs.K_CL_MODE, 0) == 2 && active.size < 2) {
            Toast.makeText(this, "السحب يحتاج نقطتين مفعّلتين (A و B)", Toast.LENGTH_SHORT).show(); return
        }
        panel?.hide()
        running = true
        count = 0; nextIdx = 0; busy = false
        val delay = Prefs.CL_DELAY[Prefs.int(this, Prefs.K_CL_DELAY, 0).coerceIn(0, Prefs.CL_DELAY.size - 1)]
        beginMs = SystemClock.elapsedRealtime() + delay * 1000L
        applyRunningState()
        playBtn.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        updateStatus()
        handler.postDelayed(loop, delay * 1000L)
    }

    private fun stopRun() {
        if (!running) return
        running = false
        handler.removeCallbacks(loop)
        applyRunningState()
        playBtn.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        updateStatus()
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val maxSec = Prefs.CL_SEC[Prefs.int(this@ClickerService, Prefs.K_CL_SEC, 0).coerceIn(0, Prefs.CL_SEC.size - 1)]
            val maxCnt = Prefs.CL_MAX[Prefs.int(this@ClickerService, Prefs.K_CL_MAX, 0).coerceIn(0, Prefs.CL_MAX.size - 1)]
            if ((maxSec > 0 && SystemClock.elapsedRealtime() - beginMs >= maxSec * 1000L) || (maxCnt > 0 && count >= maxCnt)) {
                stopRun(); return
            }
            fire()
            var iv = Prefs.CL_INTERVALS[Prefs.int(this@ClickerService, Prefs.K_CL_INT, 4).coerceIn(0, Prefs.CL_INTERVALS.size - 1)].toLong()
            val rp = Prefs.CL_RND[Prefs.int(this@ClickerService, Prefs.K_CL_RND, 0).coerceIn(0, Prefs.CL_RND.size - 1)]
            if (rp > 0) iv = (iv * (1.0 + (rnd.nextDouble() * 2 - 1) * rp / 100.0)).toLong().coerceAtLeast(10L)
            handler.postDelayed(this, iv)
        }
    }

    private fun activeIndexes(): List<Int> {
        val mask = Prefs.int(this, Prefs.K_CL_MASK, 255)
        return markers.indices.filter { (mask shr it) and 1 == 1 }
    }

    private fun pointOf(i: Int, jit: Int): PointF {
        val v = markers[i]
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        var x = loc[0] + v.width / 2f
        var y = loc[1] + v.height / 2f
        if (jit > 0) { x += (rnd.nextFloat() * 2 - 1) * jit; y += (rnd.nextFloat() * 2 - 1) * jit }
        return PointF(x, y)
    }

    private fun fire() {
        val svc = ClickerAccessibilityService.instance
        if (svc == null) { stopRun(); return }
        val now = SystemClock.elapsedRealtime()
        if (busy && now - busySince < 2000) return          // the previous tap is still going: skip this slot
        val idx = activeIndexes()
        if (idx.isEmpty()) return
        val jit = Prefs.CL_JIT[Prefs.int(this, Prefs.K_CL_JIT, 0).coerceIn(0, Prefs.CL_JIT.size - 1)]
        val dur = Prefs.CL_DURS[Prefs.int(this, Prefs.K_CL_DUR, 1).coerceIn(0, Prefs.CL_DURS.size - 1)].toLong()
        val done = { busy = false }
        busy = true; busySince = now
        val ok = when (Prefs.int(this, Prefs.K_CL_MODE, 0)) {
            1 -> svc.tap(idx.map { pointOf(it, jit) }, dur, done)
            2 -> if (idx.size >= 2) svc.swipe(pointOf(idx[0], jit), pointOf(idx[1], jit), dur.coerceAtLeast(120L), done) else false
            else -> {
                val i = idx[nextIdx % idx.size]; nextIdx++
                svc.tap(listOf(pointOf(i, jit)), dur, done)
            }
        }
        if (ok) count++ else busy = false
    }

    private fun updateStatus() {
        if (bar == null) return
        playIcon.set(if (running) IconView.STOP else IconView.PLAY, Color.WHITE)
        (playBtn.background as? GradientDrawable)?.setColor(
            if (running) Color.parseColor("#E6FF453A") else Color.parseColor("#E60A84FF")
        )
        val now = SystemClock.elapsedRealtime()
        status.text = when {
            !running -> "جاهز"
            now < beginMs -> "${ceil((beginMs - now) / 1000.0).toInt()}"
            else -> "$count"
        }
    }

    override fun onDestroy() {
        instance = null
        running = false
        handler.removeCallbacksAndMessages(null)
        panel?.hide(); panel = null
        for (m in markers) try { wm.removeView(m) } catch (_: Exception) {}
        markers.clear()
        try { bar?.let { wm.removeView(it) } } catch (_: Exception) {}
        bar = null
        super.onDestroy()
    }
}
