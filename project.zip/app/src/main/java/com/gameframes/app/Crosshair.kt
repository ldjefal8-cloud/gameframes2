package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.min

object Xh {
    const val COUNT = 36
    val NAMES = listOf(
        "نقطة", "زائد", "زائد مفتوح", "زائد + نقطة", "علامة X", "دائرة", "دائرة + نقطة",
        "دائرة + خطوط", "مربع", "حرف T", "معيّن", "دائرة + علامات", "سهم ^", "مثلث",
        "حلقة + نقطة", "خطوط طويلة", "زوايا", "حلقتان", "خط أفقي", "خط عمودي",
        "نجمة 4", "زائد + حلقة", "سهمان جانبيان", "ثلاث نقاط", "حلقة مقطّعة", "سداسي",
        "مثلث مقلوب", "علامة V", "X + نقطة", "حلقة + علامات داخلية", "مستطيل", "قوسان",
        "نقطتان", "حلقة سميكة", "زائد مزدوج", "نجمة 8"
    )

    /** Draws one crosshair centred on (cx, cy). [grow] > 0 draws the dark outline pass. */
    fun render(
        c: Canvas, shape: Int, cx: Float, cy: Float, half: Float, gap: Float, thick: Float,
        color: Int, grow: Float, stroke: Paint, fill: Paint
    ) {
        val t = if (shape == 15) thick * 0.6f else thick
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.SQUARE
        stroke.strokeJoin = Paint.Join.MITER
        stroke.strokeWidth = t + grow * 2
        stroke.color = color
        fill.style = Paint.Style.FILL
        fill.color = color

        fun hLines(from: Float, to: Float) {
            c.drawLine(cx - to, cy, cx - from, cy, stroke); c.drawLine(cx + from, cy, cx + to, cy, stroke)
        }
        fun vLines(from: Float, to: Float) {
            c.drawLine(cx, cy - to, cx, cy - from, stroke); c.drawLine(cx, cy + from, cx, cy + to, stroke)
        }
        fun dot(r: Float) = c.drawCircle(cx, cy, r + grow, fill)

        when (shape) {
            0 -> dot(max1(half * 0.18f, thick))
            1 -> { hLines(0f, half); vLines(0f, half) }
            2 -> { hLines(gap, half); vLines(gap, half) }
            3 -> { hLines(gap, half); vLines(gap, half); dot(max1(thick * 0.8f, 1.5f)) }
            4 -> {
                val d = half * 0.7f; val g = gap * 0.7f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * g, cy + sy * g, cx + sx * d, cy + sy * d, stroke)
            }
            5 -> c.drawCircle(cx, cy, half, stroke)
            6 -> { c.drawCircle(cx, cy, half, stroke); dot(max1(thick * 0.8f, 1.5f)) }
            7 -> { c.drawCircle(cx, cy, half * 0.7f, stroke); hLines(gap, half); vLines(gap, half) }
            8 -> c.drawRect(RectF(cx - half * 0.8f, cy - half * 0.8f, cx + half * 0.8f, cy + half * 0.8f), stroke)
            9 -> { hLines(gap, half); c.drawLine(cx, cy + gap, cx, cy + half, stroke) }
            10 -> c.drawPath(Path().apply {
                moveTo(cx, cy - half); lineTo(cx + half, cy); lineTo(cx, cy + half); lineTo(cx - half, cy); close()
            }, stroke)
            11 -> { c.drawCircle(cx, cy, half * 0.55f, stroke); hLines(half * 0.78f, half); vLines(half * 0.78f, half) }
            12 -> c.drawPath(Path().apply {
                moveTo(cx - half * 0.7f, cy + half * 0.35f); lineTo(cx, cy - half * 0.35f); lineTo(cx + half * 0.7f, cy + half * 0.35f)
            }, stroke)
            13 -> c.drawPath(Path().apply {
                moveTo(cx, cy - half * 0.85f); lineTo(cx + half * 0.8f, cy + half * 0.65f); lineTo(cx - half * 0.8f, cy + half * 0.65f); close()
            }, stroke)
            14 -> { c.drawCircle(cx, cy, half, stroke); dot(half * 0.2f) }
            15 -> { hLines(gap, half); vLines(gap, half); dot(max1(thick * 0.5f, 1f)) }
            16 -> {
                val s = half * 0.85f; val l = half * 0.4f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    c.drawLine(cx + sx * s, cy + sy * s, cx + sx * (s - l), cy + sy * s, stroke)
                    c.drawLine(cx + sx * s, cy + sy * s, cx + sx * s, cy + sy * (s - l), stroke)
                }
            }
            17 -> { c.drawCircle(cx, cy, half, stroke); c.drawCircle(cx, cy, half * 0.5f, stroke) }
            18 -> hLines(gap, half)
            19 -> vLines(gap, half)
            20 -> c.drawPath(Path().apply {
                val k = half * 0.22f
                moveTo(cx, cy - half); lineTo(cx + k, cy - k); lineTo(cx + half, cy); lineTo(cx + k, cy + k)
                lineTo(cx, cy + half); lineTo(cx - k, cy + k); lineTo(cx - half, cy); lineTo(cx - k, cy - k); close()
            }, stroke)
            21 -> { hLines(gap + thick * 2, half); vLines(gap + thick * 2, half); c.drawCircle(cx, cy, gap + thick, stroke) }
            22 -> {
                val o = half * 0.35f
                for (sx in intArrayOf(-1, 1)) c.drawPath(Path().apply {
                    moveTo(cx + sx * (half * 0.9f - o), cy - o); lineTo(cx + sx * half * 0.9f, cy); lineTo(cx + sx * (half * 0.9f - o), cy + o)
                }, stroke)
            }
            23 -> { val r = max1(thick * 0.9f, 1.5f); dot(r); c.drawCircle(cx, cy - half * 0.7f, r + grow, fill); c.drawCircle(cx, cy + half * 0.7f, r + grow, fill) }
            24 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                for (a in intArrayOf(-80, 10, 100, 190)) c.drawArc(rc, a.toFloat(), 60f, false, stroke) }
            25 -> c.drawPath(Path().apply {
                for (i in 0 until 6) {
                    val a = Math.toRadians(60.0 * i - 90)
                    val x = cx + half * Math.cos(a).toFloat(); val y = cy + half * Math.sin(a).toFloat()
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }, stroke)
            26 -> c.drawPath(Path().apply {
                moveTo(cx, cy + half * 0.85f); lineTo(cx + half * 0.8f, cy - half * 0.65f); lineTo(cx - half * 0.8f, cy - half * 0.65f); close()
            }, stroke)
            27 -> c.drawPath(Path().apply {
                moveTo(cx - half * 0.7f, cy - half * 0.35f); lineTo(cx, cy + half * 0.35f); lineTo(cx + half * 0.7f, cy - half * 0.35f)
            }, stroke)
            28 -> {
                val d = half * 0.7f; val g = gap * 0.7f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * g, cy + sy * g, cx + sx * d, cy + sy * d, stroke)
                dot(max1(thick * 0.8f, 1.5f))
            }
            29 -> { c.drawCircle(cx, cy, half, stroke); hLines(half * 0.45f, half * 0.8f); vLines(half * 0.45f, half * 0.8f) }
            30 -> c.drawRect(RectF(cx - half, cy - half * 0.5f, cx + half, cy + half * 0.5f), stroke)
            31 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                c.drawArc(rc, 150f, 60f, false, stroke); c.drawArc(rc, -30f, 60f, false, stroke) }
            32 -> { val r = max1(thick * 0.9f, 1.5f); c.drawCircle(cx - half * 0.45f, cy, r + grow, fill); c.drawCircle(cx + half * 0.45f, cy, r + grow, fill) }
            33 -> { stroke.strokeWidth = thick * 3 + grow * 2; c.drawCircle(cx, cy, half * 0.7f, stroke) }
            34 -> { hLines(gap, half * 0.6f); vLines(gap, half * 0.6f); hLines(half * 0.8f, half); vLines(half * 0.8f, half) }
            35 -> {
                val d = half * 0.7f
                hLines(gap, half); vLines(gap, half)
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * gap * 0.7f, cy + sy * gap * 0.7f, cx + sx * d * 0.7f, cy + sy * d * 0.7f, stroke)
            }
        }
    }
    private fun max1(a: Float, b: Float) = if (a > b) a else b
}

/** Shows a crosshair. Used both for the live overlay and for the previews inside the app. */
class CrosshairView(context: Context, private val fixedSizeDp: Int = 0, private val fixedShape: Int = -1) : View(context) {
    var shape = 0; var sizeDp = 36; var thickTenths = 20; var gapDp = 6
    var color = Color.GREEN; var alpha100 = 100; var outline = true
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun load() {
        val c = context
        shape = if (fixedShape >= 0) fixedShape else Prefs.int(c, Prefs.K_XH_SHAPE, 3).coerceIn(0, Xh.COUNT - 1)
        sizeDp = if (fixedSizeDp > 0) fixedSizeDp else Prefs.int(c, Prefs.K_XH_SIZE, 36)
        thickTenths = if (fixedSizeDp > 0) 20 else Prefs.int(c, Prefs.K_XH_THICK, 20)
        gapDp = if (fixedSizeDp > 0) (fixedSizeDp / 6) else Prefs.int(c, Prefs.K_XH_GAP, 6)
        alpha100 = if (fixedSizeDp > 0) 100 else Prefs.int(c, Prefs.K_XH_ALPHA, 100)
        color = if (fixedSizeDp > 0) Color.WHITE else Prefs.int(c, Prefs.K_XH_COLOR, Prefs.XH_COLORS[0])
        outline = if (fixedSizeDp > 0) false else Prefs.bool(c, Prefs.K_XH_OUTLINE, true)
        requestLayout(); invalidate()
    }

    init { load() }

    private fun side() = context.dp(sizeDp) + context.dp(12)
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(side(), side())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val half = context.dp(sizeDp) / 2f
        val thick = context.resources.displayMetrics.density * thickTenths / 10f
        val gap = context.dp(gapDp).toFloat()
        val col = (color and 0x00FFFFFF) or ((255 * alpha100 / 100) shl 24)
        if (outline) {
            val oc = ((255 * alpha100 / 100) shl 24) or 0x000000
            Xh.render(c, shape, cx, cy, half, gap, thick, oc, thick * 0.6f + 1f, stroke, fill)
        }
        Xh.render(c, shape, cx, cy, half, gap, thick, col, 0f, stroke, fill)
    }
}

/** Always-on-top crosshair; touches pass through to the game. */
class CrosshairService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.xh.close"
        private const val CHANNEL = "xh"
        @Volatile var instance: CrosshairService? = null
        fun reload() { instance?.apply { handler.post { applyPrefs() } } }
        val alive get() = instance != null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var view: CrosshairView? = null
    private var lp: WindowManager.LayoutParams? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_XH_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        startFg()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = CrosshairView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        view = v; lp = p
        try { wm.addView(v, p) } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        applyPrefs()
        return START_NOT_STICKY
    }

    private fun applyPrefs() {
        val v = view ?: return
        val p = lp ?: return
        v.load()
        p.x = dp(Prefs.int(this, Prefs.K_XH_DX, 0))
        p.y = dp(Prefs.int(this, Prefs.K_XH_DY, 0))
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Crosshair", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 7,
            Intent(this, CrosshairService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Game Frames")
            .setContentText("الكروس هير شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    override fun onDestroy() {
        instance = null
        try { view?.let { wm.removeView(it) } } catch (_: Exception) {}
        view = null
        super.onDestroy()
    }
}
