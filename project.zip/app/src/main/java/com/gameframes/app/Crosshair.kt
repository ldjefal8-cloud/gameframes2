package com.gameframes.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.min

object Xh {
    const val COUNT = 108
    val NAMES = listOf(
        "نقطة", "زائد", "زائد مفتوح", "زائد + نقطة", "علامة X", "دائرة", "دائرة + نقطة",
        "دائرة + خطوط", "مربع", "حرف T", "معيّن", "دائرة + علامات", "سهم ^", "مثلث",
        "حلقة + نقطة", "خطوط طويلة", "زوايا", "حلقتان", "خط أفقي", "خط عمودي",
        "نجمة 4", "زائد + حلقة", "سهمان جانبيان", "ثلاث نقاط", "حلقة مقطّعة", "سداسي",
        "مثلث مقلوب", "علامة V", "X + نقطة", "حلقة + علامات داخلية", "مستطيل", "قوسان",
        "نقطتان", "حلقة سميكة", "زائد مزدوج", "نجمة 8",
        "دائرتان + نقطة", "زائد + حلقة صغيرة", "أقواس قطرية", "T مقلوب", "زائد قصير سميك", "ثلاث نقاط عمودية", "سهمان عموديان", "دائرة + زائد داخلي", "X طويلة", "نجمة 6", "نجمة 8 خطوط", "مربع + نقطة", "زوايا + نقطة", "معيّن + نقطة", "قوس علوي", "قوس سفلي", "مستطيل عمودي", "ثلاث حلقات", "سهم أفقي", "سهم لأعلى", "زائد بنهايات نقطية", "حلقة + X", "حلقة مفرغة صغيرة", "نقطة كبيرة", "خماسي", "سداسي + نقطة", "ثماني", "صليب لاتيني", "زاويتان علويتان", "خط مائل", "خطان عموديان", "خطان أفقيان", "دائرة + خط عمودي", "عين الثور", "نقاط الزوايا", "نقاط المحاور",
        "حلقة + علامات قصيرة", "أسهم نحو المركز", "مربعان متداخلان", "زائد بنهايات عرضية", "X + حلقة", "أربع حرف T", "مثلث + نقطة", "مثلث مقلوب + نقطة", "خماسي + نقطة", "معيّن + زائد", "نجمة خماسية", "نجمة سداسية", "بوصلة", "زائد متقطّع", "معيّن + حلقة", "سهمان علويان", "حلقتان متقاطعتان", "تسع نقاط", "خمس نقاط أفقية", "خمس نقاط عمودية", "نقاط قطرية", "حلقة متقطّعة 8", "حلقة متقطّعة 12", "قوسان جانبيان + نقطة", "قوسان علوي وسفلي + نقطة", "زاويتان سفليتان", "مستطيل مفتوح", "حلقتان متقطّعتان + نقطة", "زائد + مربع صغير", "نجمة 12", "قوسان علويان", "حرف Y", "خطان عموديان + نقطة", "سداسي + زائد", "عين", "معيّن مزدوج"
    )

    /** Draws one crosshair centred on (cx, cy). [grow] > 0 draws the dark outline pass. */
    fun render(
        c: Canvas, shape: Int, cx: Float, cy: Float, half: Float, gap: Float, thick: Float,
        color: Int, grow: Float, stroke: Paint, fill: Paint
    ) {
        val t = if (shape == 15) thick * 0.6f else thick
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.SQUARE
        stroke.strokeJoin = Paint.Join.MITER
        stroke.strokeWidth = t + grow * 2
        stroke.color = color
        fill.style = Paint.Style.FILL
        fill.color = color

        fun hLines(from: Float, to: Float) {
            c.drawLine(cx - to, cy, cx - from, cy, stroke); c.drawLine(cx + from, cy, cx + to, cy, stroke)
        }
        fun vLines(from: Float, to: Float) {
            c.drawLine(cx, cy - to, cx, cy - from, stroke); c.drawLine(cx, cy + from, cx, cy + to, stroke)
        }
        fun dot(r: Float) = c.drawCircle(cx, cy, r + grow, fill)

        fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(cx + x1, cy + y1, cx + x2, cy + y2, stroke)
        fun ring(r: Float) = c.drawCircle(cx, cy, r, stroke)
        fun dotAt(x: Float, y: Float, r: Float) = c.drawCircle(cx + x, cy + y, r + grow, fill)
        fun poly(n: Int, r: Float, rot: Double = -90.0) = c.drawPath(Path().apply {
            for (i in 0 until n) {
                val a = Math.toRadians(360.0 / n * i + rot)
                val x = cx + r * Math.cos(a).toFloat(); val y = cy + r * Math.sin(a).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }, stroke)
        fun spokes(n: Int, from: Float, to: Float) {
            for (i in 0 until n) {
                val a = Math.PI * i / n
                val dx = Math.cos(a).toFloat(); val dy = Math.sin(a).toFloat()
                ln(dx * from, dy * from, dx * to, dy * to); ln(-dx * from, -dy * from, -dx * to, -dy * to)
            }
        }
        val th = max1(thick * 0.9f, 1.5f)

        when (shape) {
            0 -> dot(max1(half * 0.18f, thick))
            1 -> { hLines(0f, half); vLines(0f, half) }
            2 -> { hLines(gap, half); vLines(gap, half) }
            3 -> { hLines(gap, half); vLines(gap, half); dot(max1(thick * 0.8f, 1.5f)) }
            4 -> {
                val d = half * 0.7f; val g = gap * 0.7f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * g, cy + sy * g, cx + sx * d, cy + sy * d, stroke)
            }
            5 -> c.drawCircle(cx, cy, half, stroke)
            6 -> { c.drawCircle(cx, cy, half, stroke); dot(max1(thick * 0.8f, 1.5f)) }
            7 -> { c.drawCircle(cx, cy, half * 0.7f, stroke); hLines(gap, half); vLines(gap, half) }
            8 -> c.drawRect(RectF(cx - half * 0.8f, cy - half * 0.8f, cx + half * 0.8f, cy + half * 0.8f), stroke)
            9 -> { hLines(gap, half); c.drawLine(cx, cy + gap, cx, cy + half, stroke) }
            10 -> c.drawPath(Path().apply {
                moveTo(cx, cy - half); lineTo(cx + half, cy); lineTo(cx, cy + half); lineTo(cx - half, cy); close()
            }, stroke)
            11 -> { c.drawCircle(cx, cy, half * 0.55f, stroke); hLines(half * 0.78f, half); vLines(half * 0.78f, half) }
            12 -> c.drawPath(Path().apply {
                moveTo(cx - half * 0.7f, cy + half * 0.35f); lineTo(cx, cy - half * 0.35f); lineTo(cx + half * 0.7f, cy + half * 0.35f)
            }, stroke)
            13 -> c.drawPath(Path().apply {
                moveTo(cx, cy - half * 0.85f); lineTo(cx + half * 0.8f, cy + half * 0.65f); lineTo(cx - half * 0.8f, cy + half * 0.65f); close()
            }, stroke)
            14 -> { c.drawCircle(cx, cy, half, stroke); dot(half * 0.2f) }
            15 -> { hLines(gap, half); vLines(gap, half); dot(max1(thick * 0.5f, 1f)) }
            16 -> {
                val s = half * 0.85f; val l = half * 0.4f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    c.drawLine(cx + sx * s, cy + sy * s, cx + sx * (s - l), cy + sy * s, stroke)
                    c.drawLine(cx + sx * s, cy + sy * s, cx + sx * s, cy + sy * (s - l), stroke)
                }
            }
            17 -> { c.drawCircle(cx, cy, half, stroke); c.drawCircle(cx, cy, half * 0.5f, stroke) }
            18 -> hLines(gap, half)
            19 -> vLines(gap, half)
            20 -> c.drawPath(Path().apply {
                val k = half * 0.22f
                moveTo(cx, cy - half); lineTo(cx + k, cy - k); lineTo(cx + half, cy); lineTo(cx + k, cy + k)
                lineTo(cx, cy + half); lineTo(cx - k, cy + k); lineTo(cx - half, cy); lineTo(cx - k, cy - k); close()
            }, stroke)
            21 -> { hLines(gap + thick * 2, half); vLines(gap + thick * 2, half); c.drawCircle(cx, cy, gap + thick, stroke) }
            22 -> {
                val o = half * 0.35f
                for (sx in intArrayOf(-1, 1)) c.drawPath(Path().apply {
                    moveTo(cx + sx * (half * 0.9f - o), cy - o); lineTo(cx + sx * half * 0.9f, cy); lineTo(cx + sx * (half * 0.9f - o), cy + o)
                }, stroke)
            }
            23 -> { val r = max1(thick * 0.9f, 1.5f); dot(r); c.drawCircle(cx, cy - half * 0.7f, r + grow, fill); c.drawCircle(cx, cy + half * 0.7f, r + grow, fill) }
            24 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                for (a in intArrayOf(-80, 10, 100, 190)) c.drawArc(rc, a.toFloat(), 60f, false, stroke) }
            25 -> c.drawPath(Path().apply {
                for (i in 0 until 6) {
                    val a = Math.toRadians(60.0 * i - 90)
                    val x = cx + half * Math.cos(a).toFloat(); val y = cy + half * Math.sin(a).toFloat()
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }, stroke)
            26 -> c.drawPath(Path().apply {
                moveTo(cx, cy + half * 0.85f); lineTo(cx + half * 0.8f, cy - half * 0.65f); lineTo(cx - half * 0.8f, cy - half * 0.65f); close()
            }, stroke)
            27 -> c.drawPath(Path().apply {
                moveTo(cx - half * 0.7f, cy - half * 0.35f); lineTo(cx, cy + half * 0.35f); lineTo(cx + half * 0.7f, cy - half * 0.35f)
            }, stroke)
            28 -> {
                val d = half * 0.7f; val g = gap * 0.7f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * g, cy + sy * g, cx + sx * d, cy + sy * d, stroke)
                dot(max1(thick * 0.8f, 1.5f))
            }
            29 -> { c.drawCircle(cx, cy, half, stroke); hLines(half * 0.45f, half * 0.8f); vLines(half * 0.45f, half * 0.8f) }
            30 -> c.drawRect(RectF(cx - half, cy - half * 0.5f, cx + half, cy + half * 0.5f), stroke)
            31 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                c.drawArc(rc, 150f, 60f, false, stroke); c.drawArc(rc, -30f, 60f, false, stroke) }
            32 -> { val r = max1(thick * 0.9f, 1.5f); c.drawCircle(cx - half * 0.45f, cy, r + grow, fill); c.drawCircle(cx + half * 0.45f, cy, r + grow, fill) }
            33 -> { stroke.strokeWidth = thick * 3 + grow * 2; c.drawCircle(cx, cy, half * 0.7f, stroke) }
            34 -> { hLines(gap, half * 0.6f); vLines(gap, half * 0.6f); hLines(half * 0.8f, half); vLines(half * 0.8f, half) }
            35 -> {
                val d = half * 0.7f
                hLines(gap, half); vLines(gap, half)
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * gap * 0.7f, cy + sy * gap * 0.7f, cx + sx * d * 0.7f, cy + sy * d * 0.7f, stroke)
            }
            36 -> { ring(half); ring(half * 0.5f); dot(th) }
            37 -> { hLines(gap, half); vLines(gap, half); ring(max1(gap * 0.7f, thick * 2f)) }
            38 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                for (a in intArrayOf(25, 115, 205, 295)) c.drawArc(rc, a.toFloat(), 40f, false, stroke) }
            39 -> { hLines(gap, half); ln(0f, -gap, 0f, -half) }
            40 -> { stroke.strokeWidth = thick * 1.8f + grow * 2; hLines(0f, half * 0.5f); vLines(0f, half * 0.5f) }
            41 -> { dot(th); dotAt(0f, -half * 0.7f, th); dotAt(0f, half * 0.7f, th) }
            42 -> { val o = half * 0.35f
                c.drawPath(Path().apply { moveTo(cx - o, cy - half * 0.45f); lineTo(cx, cy - half * 0.9f); lineTo(cx + o, cy - half * 0.45f) }, stroke)
                c.drawPath(Path().apply { moveTo(cx - o, cy + half * 0.45f); lineTo(cx, cy + half * 0.9f); lineTo(cx + o, cy + half * 0.45f) }, stroke) }
            43 -> { ring(half * 0.8f); hLines(0f, half * 0.45f); vLines(0f, half * 0.45f) }
            44 -> { val d = half * 0.95f; val g = gap * 0.7f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * g, cy + sy * g, cx + sx * d, cy + sy * d, stroke) }
            45 -> spokes(3, gap, half)
            46 -> spokes(4, gap, half)
            47 -> { c.drawRect(RectF(cx - half * 0.7f, cy - half * 0.7f, cx + half * 0.7f, cy + half * 0.7f), stroke); dot(th) }
            48 -> { val s2 = half * 0.85f; val l = half * 0.4f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    c.drawLine(cx + sx * s2, cy + sy * s2, cx + sx * (s2 - l), cy + sy * s2, stroke)
                    c.drawLine(cx + sx * s2, cy + sy * s2, cx + sx * s2, cy + sy * (s2 - l), stroke)
                }
                dot(th) }
            49 -> { poly(4, half); dot(th) }
            50 -> c.drawArc(RectF(cx - half, cy - half, cx + half, cy + half), 200f, 140f, false, stroke)
            51 -> c.drawArc(RectF(cx - half, cy - half, cx + half, cy + half), 20f, 140f, false, stroke)
            52 -> c.drawRect(RectF(cx - half * 0.5f, cy - half, cx + half * 0.5f, cy + half), stroke)
            53 -> { ring(half); ring(half * 0.66f); ring(half * 0.33f) }
            54 -> { ln(-half, 0f, half, 0f); ln(half, 0f, half * 0.6f, -half * 0.3f); ln(half, 0f, half * 0.6f, half * 0.3f) }
            55 -> { ln(0f, half, 0f, -half); ln(0f, -half, -half * 0.3f, -half * 0.6f); ln(0f, -half, half * 0.3f, -half * 0.6f) }
            56 -> { hLines(gap, half); vLines(gap, half)
                dotAt(-half, 0f, th); dotAt(half, 0f, th); dotAt(0f, -half, th); dotAt(0f, half, th) }
            57 -> { ring(half * 0.6f); val d = half * 0.42f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) c.drawLine(cx + sx * d, cy + sy * d, cx + sx * d * 1.6f, cy + sy * d * 1.6f, stroke) }
            58 -> ring(half * 0.25f)
            59 -> dot(half * 0.3f)
            60 -> poly(5, half)
            61 -> { poly(6, half); dot(th) }
            62 -> poly(8, half, -67.5)
            63 -> { ln(0f, -half, 0f, half); ln(-half * 0.45f, -half * 0.3f, half * 0.45f, -half * 0.3f) }
            64 -> { val o = half * 0.4f
                c.drawPath(Path().apply { moveTo(cx - half * 0.9f, cy - half * 0.2f); lineTo(cx - half * 0.45f, cy - half * 0.2f - o); lineTo(cx, cy - half * 0.2f) }, stroke)
                c.drawPath(Path().apply { moveTo(cx, cy - half * 0.2f); lineTo(cx + half * 0.45f, cy - half * 0.2f - o); lineTo(cx + half * 0.9f, cy - half * 0.2f) }, stroke) }
            65 -> ln(-half * 0.7f, half * 0.7f, half * 0.7f, -half * 0.7f)
            66 -> { ln(-half * 0.3f, -half, -half * 0.3f, half); ln(half * 0.3f, -half, half * 0.3f, half) }
            67 -> { ln(-half, -half * 0.3f, half, -half * 0.3f); ln(-half, half * 0.3f, half, half * 0.3f) }
            68 -> { ring(half); vLines(0f, half) }
            69 -> { ring(half); ring(half * 0.55f); dot(max1(half * 0.14f, thick)) }
            70 -> { val q = half * 0.7f
                dotAt(-q, -q, th); dotAt(q, -q, th); dotAt(-q, q, th); dotAt(q, q, th) }
            71 -> { dot(th); val q = half * 0.8f
                dotAt(-q, 0f, th); dotAt(q, 0f, th); dotAt(0f, -q, th); dotAt(0f, q, th) }

            72 -> { ring(half); hLines(half * 0.25f, half * 0.6f); vLines(half * 0.25f, half * 0.6f) }
            73 -> { val o = half * 0.28f; val d = half * 0.7f
                c.drawPath(Path().apply { moveTo(cx - o, cy - d - o); lineTo(cx, cy - d); lineTo(cx + o, cy - d - o) }, stroke)
                c.drawPath(Path().apply { moveTo(cx - o, cy + d + o); lineTo(cx, cy + d); lineTo(cx + o, cy + d + o) }, stroke)
                c.drawPath(Path().apply { moveTo(cx - d - o, cy - o); lineTo(cx - d, cy); lineTo(cx - d - o, cy + o) }, stroke)
                c.drawPath(Path().apply { moveTo(cx + d + o, cy - o); lineTo(cx + d, cy); lineTo(cx + d + o, cy + o) }, stroke) }
            74 -> { c.drawRect(RectF(cx - half, cy - half, cx + half, cy + half), stroke)
                c.drawRect(RectF(cx - half * 0.5f, cy - half * 0.5f, cx + half * 0.5f, cy + half * 0.5f), stroke) }
            75 -> { hLines(gap, half); vLines(gap, half); val k = half * 0.22f
                ln(half, -k, half, k); ln(-half, -k, -half, k); ln(-k, half, k, half); ln(-k, -half, k, -half) }
            76 -> { ring(half * 0.55f); val d = half * 0.7f; val g = half * 0.4f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1))
                    c.drawLine(cx + sx * g, cy + sy * g, cx + sx * d, cy + sy * d, stroke) }
            77 -> { hLines(gap, half); vLines(gap, half); val k = half * 0.2f
                ln(half, -k, half, k); ln(-half, -k, -half, k); ln(-k, half, k, half); ln(-k, -half, k, -half); dot(th) }
            78 -> { poly(3, half); dot(th) }
            79 -> { poly(3, half, 90.0); dot(th) }
            80 -> { poly(5, half); dot(th) }
            81 -> { poly(4, half); hLines(0f, half * 0.5f); vLines(0f, half * 0.5f) }
            82 -> c.drawPath(Path().apply {
                for (i in 0 until 10) {
                    val a = Math.toRadians(36.0 * i - 90); val r = if (i % 2 == 0) half else half * 0.42f
                    val x = cx + r * Math.cos(a).toFloat(); val y = cy + r * Math.sin(a).toFloat()
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }, stroke)
            83 -> { poly(3, half); poly(3, half, 90.0) }
            84 -> { ring(half * 0.7f)
                for (k in 0 until 8) { val a = Math.toRadians(45.0 * k); val ca = Math.cos(a).toFloat(); val sa = Math.sin(a).toFloat()
                    ln(ca * half * 0.82f, sa * half * 0.82f, ca * half, sa * half) } }
            85 -> { hLines(gap, gap + half * 0.22f); hLines(gap + half * 0.4f, half)
                vLines(gap, gap + half * 0.22f); vLines(gap + half * 0.4f, half) }
            86 -> { poly(4, half); ring(max1(gap * 0.8f, thick * 2f)) }
            87 -> { val o = half * 0.32f
                c.drawPath(Path().apply { moveTo(cx - half * 0.6f, cy + o * 0.2f); lineTo(cx, cy - o * 0.8f); lineTo(cx + half * 0.6f, cy + o * 0.2f) }, stroke)
                c.drawPath(Path().apply { moveTo(cx - half * 0.6f, cy + o * 1.4f); lineTo(cx, cy + o * 0.4f); lineTo(cx + half * 0.6f, cy + o * 1.4f) }, stroke) }
            88 -> { c.drawCircle(cx - half * 0.35f, cy, half * 0.6f, stroke); c.drawCircle(cx + half * 0.35f, cy, half * 0.6f, stroke) }
            89 -> { val q = half * 0.6f
                for (ix in -1..1) for (iy in -1..1) dotAt(ix * q, iy * q, th * 0.8f) }
            90 -> { for (i in -2..2) dotAt(i * half * 0.45f, 0f, th) }
            91 -> { for (i in -2..2) dotAt(0f, i * half * 0.45f, th) }
            92 -> { dot(th); for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                dotAt(sx * half * 0.4f, sy * half * 0.4f, th); dotAt(sx * half * 0.8f, sy * half * 0.8f, th) } }
            93 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                for (k in 0 until 8) c.drawArc(rc, 45f * k, 30f, false, stroke) }
            94 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                for (k in 0 until 12) c.drawArc(rc, 30f * k, 15f, false, stroke) }
            95 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                c.drawArc(rc, 120f, 120f, false, stroke); c.drawArc(rc, -60f, 120f, false, stroke); dot(th) }
            96 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                c.drawArc(rc, 210f, 120f, false, stroke); c.drawArc(rc, 30f, 120f, false, stroke); dot(th) }
            97 -> { val s2 = half * 0.85f; val l = half * 0.45f
                for (sx in intArrayOf(-1, 1)) {
                    c.drawLine(cx + sx * s2, cy + s2, cx + sx * (s2 - l), cy + s2, stroke)
                    c.drawLine(cx + sx * s2, cy + s2, cx + sx * s2, cy + s2 - l, stroke) } }
            98 -> { val w = half; val h2 = half * 0.6f; val g2 = half * 0.3f
                ln(-w, -h2, -g2, -h2); ln(g2, -h2, w, -h2); ln(-w, h2, -g2, h2); ln(g2, h2, w, h2)
                ln(-w, -h2, -w, -g2 * 0.6f); ln(-w, g2 * 0.6f, -w, h2); ln(w, -h2, w, -g2 * 0.6f); ln(w, g2 * 0.6f, w, h2) }
            99 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half)
                for (a in intArrayOf(-70, 20, 110, 200)) c.drawArc(rc, a.toFloat(), 50f, false, stroke)
                ring(half * 0.5f); dot(th) }
            100 -> { hLines(gap + thick * 2, half); vLines(gap + thick * 2, half)
                val q = max1(gap * 0.7f, thick * 1.5f); c.drawRect(RectF(cx - q, cy - q, cx + q, cy + q), stroke) }
            101 -> spokes(6, gap, half)
            102 -> { val rc = RectF(cx - half, cy - half, cx + half, cy + half); val r2 = RectF(cx - half * 0.7f, cy - half * 0.7f, cx + half * 0.7f, cy + half * 0.7f)
                c.drawArc(rc, 215f, 110f, false, stroke); c.drawArc(r2, 215f, 110f, false, stroke) }
            103 -> { val q = half * 0.7f; ln(-q, -q, 0f, 0f); ln(q, -q, 0f, 0f); ln(0f, 0f, 0f, half) }
            104 -> { ln(-half * 0.3f, -half, -half * 0.3f, half); ln(half * 0.3f, -half, half * 0.3f, half); dot(th) }
            105 -> { poly(6, half); hLines(0f, half * 0.4f); vLines(0f, half * 0.4f) }
            106 -> { c.drawOval(RectF(cx - half, cy - half * 0.55f, cx + half, cy + half * 0.55f), stroke); dot(max1(half * 0.2f, thick)) }
            107 -> { poly(4, half); poly(4, half * 0.5f) }
        }
    }
    private fun max1(a: Float, b: Float) = if (a > b) a else b
}

/** Shows a crosshair. Used both for the live overlay and for the previews inside the app. */
class CrosshairView(context: Context, private val fixedSizeDp: Int = 0, private val fixedShape: Int = -1) : View(context) {
    var shape = 0; var sizeDp = 36; var thickTenths = 20; var gapDp = 6
    var color = Color.GREEN; var alpha100 = 100; var outline = true
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun load() {
        val c = context
        shape = if (fixedShape >= 0) fixedShape else Prefs.int(c, Prefs.K_XH_SHAPE, 3).coerceIn(0, Xh.COUNT - 1)
        sizeDp = if (fixedSizeDp > 0) fixedSizeDp else Prefs.int(c, Prefs.K_XH_SIZE, 36)
        thickTenths = if (fixedSizeDp > 0) 20 else Prefs.int(c, Prefs.K_XH_THICK, 20)
        gapDp = if (fixedSizeDp > 0) (fixedSizeDp / 6) else Prefs.int(c, Prefs.K_XH_GAP, 6)
        alpha100 = if (fixedSizeDp > 0) 100 else Prefs.int(c, Prefs.K_XH_ALPHA, 100)
        color = if (fixedSizeDp > 0) Color.WHITE else Prefs.int(c, Prefs.K_XH_COLOR, Prefs.XH_COLORS[0])
        outline = if (fixedSizeDp > 0) false else Prefs.bool(c, Prefs.K_XH_OUTLINE, true)
        requestLayout(); invalidate()
    }

    init { load() }

    private fun side() = context.dp(sizeDp) + context.dp(12)
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(side(), side())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val half = context.dp(sizeDp) / 2f
        val thick = context.resources.displayMetrics.density * thickTenths / 10f
        val gap = context.dp(gapDp).toFloat()
        val col = (color and 0x00FFFFFF) or ((255 * alpha100 / 100) shl 24)
        if (outline) {
            val oc = ((255 * alpha100 / 100) shl 24) or 0x000000
            Xh.render(c, shape, cx, cy, half, gap, thick, oc, thick * 0.6f + 1f, stroke, fill)
        }
        Xh.render(c, shape, cx, cy, half, gap, thick, col, 0f, stroke, fill)
    }
}

/** Always-on-top crosshair; touches pass through to the game. */
class CrosshairService : Service() {

    companion object {
        const val ACTION_CLOSE = "gf.xh.close"
        private const val CHANNEL = "xh"
        @Volatile var instance: CrosshairService? = null
        fun reload() { instance?.apply { handler.post { applyPrefs() } } }
        val alive get() = instance != null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var view: CrosshairView? = null
    private var lp: WindowManager.LayoutParams? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            Prefs.setBool(this, Prefs.K_XH_ON, false)
            stopSelf(); return START_NOT_STICKY
        }
        if (instance != null) return START_NOT_STICKY
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        startFg()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = CrosshairView(this)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        view = v; lp = p
        try { wm.addView(v, p) } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        applyPrefs()
        return START_NOT_STICKY
    }

    private fun applyPrefs() {
        val v = view ?: return
        val p = lp ?: return
        v.load()
        p.x = dp(Prefs.int(this, Prefs.K_XH_DX, 0))
        p.y = dp(Prefs.int(this, Prefs.K_XH_DY, 0))
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Crosshair", NotificationManager.IMPORTANCE_MIN))
        val close = PendingIntent.getService(this, 7,
            Intent(this, CrosshairService::class.java).setAction(ACTION_CLOSE), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("FPS")
            .setContentText("الكروس هير شغّال")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "إيقاف", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    override fun onDestroy() {
        instance = null
        try { view?.let { wm.removeView(it) } } catch (_: Exception) {}
        view = null
        super.onDestroy()
    }
}
