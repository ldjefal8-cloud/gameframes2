package com.gameframes.app

import android.content.Context
import android.graphics.Typeface

/**
 * Inter (SIL OFL) – the open-source font closest to Apple's San Francisco.
 * Arabic letters are not in Inter, so Android falls back to the system Arabic font for them.
 */
object Fonts {
    private var reg: Typeface? = null
    private var med: Typeface? = null
    private var semi: Typeface? = null
    private var bld: Typeface? = null

    private fun load(c: Context, id: Int, fallback: Typeface): Typeface =
        try { c.applicationContext.resources.getFont(id) } catch (_: Exception) { fallback }

    fun regular(c: Context): Typeface = reg ?: load(c, R.font.inter_regular, Typeface.DEFAULT).also { reg = it }
    fun medium(c: Context): Typeface = med ?: load(c, R.font.inter_medium, Typeface.DEFAULT).also { med = it }
    fun semibold(c: Context): Typeface = semi ?: load(c, R.font.inter_semibold, Typeface.DEFAULT_BOLD).also { semi = it }
    fun bold(c: Context): Typeface = bld ?: load(c, R.font.inter_bold, Typeface.DEFAULT_BOLD).also { bld = it }
}
