package com.gameframes.app

import android.app.Application
import android.content.Context
import android.graphics.Typeface

/**
 * App-wide font. Inter is the open-source typeface closest to Apple's SF Pro (same grotesque shapes, same
 * numerals), and it is bundled in res/font so it looks the same on every phone. Arabic letters are not in
 * Inter, so Android draws them with the phone's own Arabic font automatically.
 */
object Fonts {
    @Volatile var regular: Typeface = Typeface.DEFAULT
    @Volatile var medium: Typeface = Typeface.DEFAULT
    @Volatile var semibold: Typeface = Typeface.DEFAULT_BOLD
    @Volatile var bold: Typeface = Typeface.DEFAULT_BOLD

    fun init(c: Context) {
        fun load(id: Int, fallback: Typeface): Typeface = try {
            c.resources.getFont(id)
        } catch (_: Exception) {
            fallback
        }
        regular = load(R.font.inter_regular, Typeface.DEFAULT)
        medium = load(R.font.inter_medium, regular)
        semibold = load(R.font.inter_semibold, Typeface.DEFAULT_BOLD)
        bold = load(R.font.inter_bold, Typeface.DEFAULT_BOLD)
    }
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Fonts.init(this)
    }
}
