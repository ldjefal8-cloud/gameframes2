package com.gameframes.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/** Frame-by-frame review of a recorded video; any frame can be saved as PNG. */
class ReviewActivity : Activity() {

    private lateinit var image: ImageView
    private lateinit var seek: SeekBar
    private lateinit var timeLabel: TextView
    private lateinit var fpsEdit: EditText

    private var retriever: MediaMetadataRetriever? = null
    private var videoUri: Uri? = null
    private var durUs = 0L
    private var curUs = 0L
    private var bitmap: Bitmap? = null
    private var request = 0
    private val exec = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }
        videoUri = uri

        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر فتح الفيديو", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        retriever = r
        durUs = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(12), dp(16), dp(12), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        timeLabel = label("00:00.000", 16f, GREEN)
        root.addView(timeLabel)

        image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        root.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))

        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) showAt(durUs * p / 1000)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(seek)

        fpsEdit = EditText(this).apply {
            setText("60")
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }
        root.addView(row(label("FPS للتنقل بين الفريمات", 13f, MUTE), fpsEdit))

        root.addView(row(
            button("⏮ فريم") { step(-1) },
            button("فريم ⏭") { step(1) }
        ))
        root.addView(row(
            button("−1 ثانية") { showAt(curUs - 1_000_000) },
            button("+1 ثانية") { showAt(curUs + 1_000_000) }
        ))
        root.addView(row(
            button("📸 حفظ الفريم PNG", primary = true) { saveFrame() },
            button("▶ تشغيل خارجي") { playExternal() }
        ))

        setContentView(root)
        showAt(0)
    }

    private fun stepUs(): Long {
        val fps = fpsEdit.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: 60
        return 1_000_000L / fps
    }

    private fun step(dir: Int) = showAt(curUs + dir * stepUs())

    private fun showAt(us: Long) {
        val r = retriever ?: return
        val t = max(0L, if (durUs > 0) min(us, durUs) else us)
        curUs = t
        timeLabel.text = fmt(t) + " / " + fmt(durUs)
        if (durUs > 0) seek.progress = (t * 1000 / durUs).toInt()
        val id = ++request
        exec.execute {
            val b = try {
                r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST)
            } catch (_: Exception) {
                null
            }
            runOnUiThread {
                if (id == request && b != null) {
                    bitmap = b
                    image.setImageBitmap(b)
                }
            }
        }
    }

    private fun fmt(us: Long): String {
        val ms = us / 1000
        return "%02d:%02d.%03d".format(ms / 60000, (ms / 1000) % 60, ms % 1000)
    }

    private fun saveFrame() {
        val b = bitmap ?: return
        val name = "frame-" + fmt(curUs).replace(":", "-").replace(".", "-") + "-" + (System.currentTimeMillis() % 100000) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GameFrames")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "تعذّر الحفظ", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            Toast.makeText(this, "تم الحفظ في Pictures/GameFrames", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            Toast.makeText(this, "تعذّر الحفظ", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playExternal() {
        val uri = videoUri ?: return
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "لا يوجد مشغّل فيديو", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        exec.shutdownNow()
        try { retriever?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
