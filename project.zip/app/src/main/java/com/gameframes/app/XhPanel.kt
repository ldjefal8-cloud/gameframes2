package com.gameframes.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/**
 * Small settings panel that floats over the game to tune the crosshair without leaving it:
 * up/down/left/right nudge buttons (with an adjustable step so it never moves too much or too little),
 * shape, size, thickness, gap, opacity and colour. Every change is saved and applied live.
 * Opened from the crosshair button of the floating bar.
 */
class XhPanel(private val c: Context, private val wm: WindowManager) {

    companion object {
        private const val BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        /** Set when a value changed here, so the app screen refreshes its sliders next time it opens. */
        @Volatile var dirty = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var xhSwitch: IosSwitch
    private lateinit var offsetText: TextView
    private lateinit var shapeBox: FrameLayout
    private lateinit var shapeName: TextView
    private var built = false
    var shown = false
        private set
    private var lastMode = -1
    private var lastHidden = false

    private fun dp(n: Int) = c.dp(n)

    // ---------------- window ----------------

    fun show() {
        if (shown) return
        if (!built) build()
        try {
            wm.addView(root, lp)
            shown = true
        } catch (_: Exception) {
            shown = false
        }
    }

    fun hide() {
        if (!shown) return
        try { wm.removeView(root) } catch (_: Exception) {}
        shown = false
        lastMode = -1
    }

    /** Keeps the live crosshair switch honest (the service can be stopped from elsewhere). */
    fun sync() {
        if (!shown) return
        xhSwitch.checked = CrosshairService.alive
    }

    /** Same video rule as the floating bar: 1 = secure (out of the video), 2 = hidden while recording. */
    fun applyVideoMode(mode: Int, recording: Boolean) {
        if (!shown) return
        val hidden = mode == 2 && recording
        if (mode == lastMode && hidden == lastHidden) return
        lastMode = mode; lastHidden = hidden
        lp.flags = BASE_FLAGS or (if (mode == 1) WindowManager.LayoutParams.FLAG_SECURE else 0)
        root.visibility = if (hidden) View.GONE else View.VISIBLE
        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
    }

    private fun changed() {
        dirty = true
        CrosshairService.reload()
    }

    // ---------------- building ----------------

    private fun build() {
        val screen = c.realMetrics()
        val maxW = min(dp(310), screen.widthPixels - dp(16))
        val maxH = (screen.heightPixels * 0.78f).toInt()

        root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = c.rounded(Color.parseColor("#E61C1C1E"), 24, GLASS_EDGE_TOP, 1)
        }

        // header: drag handle + live switch + close
        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(8), dp(10), dp(8))
        }
        val title = c.label("الكروس هير  ⠿", 16f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD }
        xhSwitch = IosSwitch(c).apply {
            checked = CrosshairService.alive
            onToggle = { want -> if (toggleCrosshair(want)) checked = want }
        }
        val closeBtn = c.glassCircle(34, IconView.CLOSE, Color.parseColor("#66787880")).apply {
            setOnClickListener { hide() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(xhSwitch, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
        header.addView(closeBtn, LinearLayout.LayoutParams(dp(34), dp(34)))
        root.addView(header)

        lp = WindowManager.LayoutParams(
            maxW, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.int(c, Prefs.K_XHP_X, dp(24))
            y = Prefs.int(c, Prefs.K_XHP_Y, dp(24))
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tx) > dp(6) || abs(e.rawY - ty) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { Prefs.setInt(c, Prefs.K_XHP_X, lp.x); Prefs.setInt(c, Prefs.K_XHP_Y, lp.y) }
                    true
                }
                else -> false
            }
        }

        // body (scrolls when the screen is short, e.g. landscape)
        val body = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), 0, dp(14), dp(14))
        }
        body.addView(c.caption("الإزاحة (أزرار الاتجاه، اضغط مطوّلًا للتكرار)"))
        body.addView(buildPad())
        offsetText = c.label("", 12.5f, LABEL2).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }
        body.addView(offsetText)
        updateOffsetText()

        body.addView(c.caption("الحساسية: مسافة كل ضغطة (dp)"))
        val stepSel = Prefs.int(c, Prefs.K_XH_STEP, 1).coerceIn(0, Prefs.XH_STEPS.size - 1)
        body.addView(ChipRow(c, Prefs.XH_STEPS.map { "$it" }, stepSel) { i -> Prefs.setInt(c, Prefs.K_XH_STEP, i) })

        body.addView(c.caption("الشكل"))
        body.addView(buildShapePicker())

        body.addView(c.caption("المقاسات"))
        body.addView(stepper("الحجم", Prefs.K_XH_SIZE, 36, 8, 160, 2) { "$it dp" })
        body.addView(stepper("السماكة", Prefs.K_XH_THICK, 20, 5, 100, 5) { "%.1f dp".format(it / 10f) })
        body.addView(stepper("الفراغ", Prefs.K_XH_GAP, 6, 0, 40, 1) { "$it dp" })
        body.addView(stepper("الشفافية", Prefs.K_XH_ALPHA, 100, 10, 100, 5) { "$it%" })

        body.addView(c.caption("اللون"))
        body.addView(buildColors())

        body.addView(c.switchRow("حدّ أسود حول العلامة", null, Prefs.bool(c, Prefs.K_XH_OUTLINE, true)) { on ->
            Prefs.setBool(c, Prefs.K_XH_OUTLINE, on); changed(); true
        })

        val scroll = object : ScrollView(c) {
            override fun onMeasure(w: Int, h: Int) =
                super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }.apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(body)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        built = true
    }

    private fun toggleCrosshair(want: Boolean): Boolean {
        if (want) {
            Prefs.setBool(c, Prefs.K_XH_ON, true)
            c.startForegroundService(Intent(c, CrosshairService::class.java))
        } else {
            Prefs.setBool(c, Prefs.K_XH_ON, false)
            c.stopService(Intent(c, CrosshairService::class.java))
        }
        return true
    }

    // ---------------- nudge pad ----------------

    private fun buildPad(): LinearLayout {
        fun cell(v: View?): View = v ?: View(c)
        fun row(a: View?, b: View?, d: View?) = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            for (v in listOf(cell(a), cell(b), cell(d))) {
                addView(v, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
        }
        val center = c.glassCircle(46, IconView.CROSS, Color.parseColor("#400A84FF")).apply {
            setOnClickListener {
                Prefs.setInt(c, Prefs.K_XH_DX, 0); Prefs.setInt(c, Prefs.K_XH_DY, 0)
                updateOffsetText(); changed()
            }
        }
        val pad = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        pad.addView(row(null, nudgeBtn(IconView.UP, 0, -1), null))
        pad.addView(row(nudgeBtn(IconView.LEFT, -1, 0), center, nudgeBtn(IconView.RIGHT, 1, 0)))
        pad.addView(row(null, nudgeBtn(IconView.DOWN, 0, 1), null))
        return pad
    }

    private fun nudgeBtn(kind: Int, dx: Int, dy: Int): FrameLayout {
        val f = c.glassCircle(46, kind, Color.parseColor("#33FFFFFF"))
        holdRepeat(f) { nudge(dx, dy) }
        return f
    }

    private fun nudge(dx: Int, dy: Int) {
        val step = Prefs.XH_STEPS[Prefs.int(c, Prefs.K_XH_STEP, 1).coerceIn(0, Prefs.XH_STEPS.size - 1)]
        val nx = (Prefs.int(c, Prefs.K_XH_DX, 0) + dx * step).coerceIn(-300, 300)
        val ny = (Prefs.int(c, Prefs.K_XH_DY, 0) + dy * step).coerceIn(-300, 300)
        Prefs.setInt(c, Prefs.K_XH_DX, nx); Prefs.setInt(c, Prefs.K_XH_DY, ny)
        updateOffsetText(); changed()
    }

    private fun updateOffsetText() {
        offsetText.text = "أفقيًا ${Prefs.int(c, Prefs.K_XH_DX, 0)} dp   ·   عموديًا ${Prefs.int(c, Prefs.K_XH_DY, 0)} dp"
    }

    /** Runs [act] on press, then keeps repeating while the finger stays down. */
    private fun holdRepeat(v: View, act: () -> Unit) {
        val rep = object : Runnable {
            override fun run() { act(); handler.postDelayed(this, 80) }
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.alpha = 0.6f
                    act()
                    handler.postDelayed(rep, 400)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(rep)
                    view.alpha = 1f
                    true
                }
                else -> true
            }
        }
    }

    // ---------------- shape / sizes / colours ----------------

    private fun curShape() = Prefs.int(c, Prefs.K_XH_SHAPE, 3).coerceIn(0, Xh.COUNT - 1)

    private fun buildShapePicker(): LinearLayout {
        shapeBox = FrameLayout(c).apply {
            background = c.rounded(Color.parseColor("#66000000"), 16, GLASS_EDGE_BOT, 1)
        }
        shapeName = c.label("", 12.5f, LABEL2).apply { gravity = Gravity.CENTER }
        fun go(d: Int) {
            val n = (curShape() + d + Xh.COUNT) % Xh.COUNT
            Prefs.setInt(c, Prefs.K_XH_SHAPE, n)
            paintShape(); changed()
        }
        val prev = c.glassCircle(40, IconView.LEFT, Color.parseColor("#33FFFFFF")).apply { setOnClickListener { go(-1) } }
        val next = c.glassCircle(40, IconView.RIGHT, Color.parseColor("#33FFFFFF")).apply { setOnClickListener { go(1) } }
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        row.addView(prev, LinearLayout.LayoutParams(dp(40), dp(40)))
        row.addView(shapeBox, LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
        row.addView(next, LinearLayout.LayoutParams(dp(40), dp(40)))
        paintShape()
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(row)
        col.addView(shapeName)
        return col
    }

    private fun paintShape() {
        val i = curShape()
        shapeBox.removeAllViews()
        shapeBox.addView(CrosshairView(c, 36, i), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        shapeName.text = "${i + 1}/${Xh.COUNT} · ${Xh.NAMES.getOrElse(i) { "" }}"
    }

    /** Title, [−] value [+]; holding a button keeps stepping. */
    private fun stepper(
        title: String, key: String, def: Int, min: Int, max: Int, step: Int, fmt: (Int) -> String
    ): LinearLayout {
        val value = c.label(fmt(Prefs.int(c, key, def).coerceIn(min, max)), 14f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            minWidth = dp(72)
        }
        fun bump(d: Int) {
            val nv = (Prefs.int(c, key, def) + d * step).coerceIn(min, max)
            Prefs.setInt(c, key, nv)
            value.text = fmt(nv)
            changed()
        }
        val minus = c.glassCircle(38, IconView.MINUS, Color.parseColor("#33FFFFFF"))
        val plus = c.glassCircle(38, IconView.PLUS, Color.parseColor("#33FFFFFF"))
        holdRepeat(minus) { bump(-1) }
        holdRepeat(plus) { bump(1) }
        val ctrl = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(minus, LinearLayout.LayoutParams(dp(38), dp(38)))
            addView(value)
            addView(plus, LinearLayout.LayoutParams(dp(38), dp(38)))
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
            addView(c.label(title, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            addView(ctrl)
        }
    }

    private fun buildColors(): HorizontalScrollView {
        val colors = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val dots = ArrayList<View>()
        fun paint() {
            val sel = Prefs.int(c, Prefs.K_XH_COLOR, Prefs.XH_COLORS[0])
            dots.forEachIndexed { i, d ->
                d.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Prefs.XH_COLORS[i])
                    if (Prefs.XH_COLORS[i] == sel) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), Color.parseColor("#55FFFFFF"))
                }
            }
        }
        Prefs.XH_COLORS.forEach { col ->
            val d = View(c).apply {
                setOnClickListener { Prefs.setInt(c, Prefs.K_XH_COLOR, col); paint(); changed() }
            }
            dots.add(d)
            colors.addView(d, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) })
        }
        paint()
        return HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false; addView(colors) }
    }
}
