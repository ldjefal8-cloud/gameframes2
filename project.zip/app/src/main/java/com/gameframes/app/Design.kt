package com.gameframes.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

// ---------- iOS 26 "Liquid Glass" palette (dark) ----------
val GLASS = Color.parseColor("#26FFFFFF")          // card fill
val GLASS_SOFT = Color.parseColor("#1AFFFFFF")
val GLASS_EDGE_TOP = Color.parseColor("#59FFFFFF")
val GLASS_EDGE_BOT = Color.parseColor("#14FFFFFF")
val LABEL2 = Color.parseColor("#99EBEBF5")
val IOS_BLUE = Color.parseColor("#0A84FF")
val IOS_GREEN = Color.parseColor("#30D158")
val IOS_RED = Color.parseColor("#FF453A")
val IOS_ORANGE = Color.parseColor("#FF9F0A")

// kept for older screens
val CARD = GLASS
val CARD_STROKE = GLASS_EDGE_BOT
val CHIP = Color.parseColor("#33FFFFFF")
val ACCENT = IOS_BLUE
val ACCENT_DARK = Color.WHITE
val REC_RED = IOS_RED
val AMBER = IOS_ORANGE

fun Context.rounded(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

/** Glass surface: translucent fill + bright top edge fading to a faint bottom edge. */
fun Context.glass(radiusDp: Int, fill: Int = GLASS): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), GLASS_EDGE_BOT)
    }

/** Soft aurora background that makes the glass cards look like glass. */
class AuroraBg(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#05070D"), Color.parseColor("#0B1020"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        blob(c, w * 0.15f, h * 0.10f, w * 0.75f, Color.parseColor("#660A84FF"))
        blob(c, w * 0.95f, h * 0.38f, w * 0.70f, Color.parseColor("#55BF5AF2"))
        blob(c, w * 0.10f, h * 0.75f, w * 0.80f, Color.parseColor("#4430D158"))
    }
    private fun blob(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        p.shader = RadialGradient(x, y, r, col, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }
}

/** Section card (grouped, inset, glass). */
fun Context.card(title: String? = null, subtitle: String? = null): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = glass(26)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(7), 0, dp(7)) }
        if (title != null) addView(label(title, 17f, Color.WHITE).apply { typeface = Fonts.bold })
        if (subtitle != null) addView(label(subtitle, 12.5f, LABEL2).apply { setPadding(0, dp(3), 0, dp(4)) })
    }

fun Context.caption(text: String): TextView =
    label(text, 12.5f, LABEL2).apply { setPadding(dp(2), dp(12), 0, dp(6)) }

/** Selectable segments (one at a time) – scrollable pill row like iOS segmented control. */
class ChipRow(
    context: Context,
    items: List<String>,
    selected: Int,
    private val onSelect: (Int) -> Unit
) : HorizontalScrollView(context) {

    var index = selected
        private set
    private val chips = ArrayList<TextView>()

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = context.glass(18, Color.parseColor("#1F000000"))
            setPadding(context.dp(3), context.dp(3), context.dp(3), context.dp(3))
        }
        items.forEachIndexed { i, t ->
            val tv = TextView(context).apply {
                text = t
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(context.dp(15), context.dp(8), context.dp(15), context.dp(8))
                setOnClickListener { select(i, true) }
            }
            box.addView(tv, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(context.dp(1), 0, context.dp(1), 0) })
            chips.add(tv)
        }
        addView(box)
        paint()
    }

    fun select(i: Int, notify: Boolean) {
        if (i < 0 || i >= chips.size) return
        index = i
        paint()
        if (notify) onSelect(i)
    }

    private fun paint() {
        chips.forEachIndexed { i, tv ->
            val on = i == index
            tv.background = if (on) context.rounded(Color.parseColor("#4DFFFFFF"), 15) else null
            tv.setTextColor(if (on) Color.WHITE else LABEL2)
            tv.typeface = if (on) Fonts.bold else Fonts.regular
        }
    }
}

/** iOS style switch (green track, white knob). */
class IosSwitch(context: Context) : View(context) {
    var checked = false
        set(v) { if (field != v) { field = v; invalidate() } }
    var onToggle: ((Boolean) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    init { setOnClickListener { onToggle?.invoke(!checked) } }
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(context.dp(52), context.dp(32))
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = if (checked) IOS_GREEN else Color.parseColor("#47787880")
        c.drawRoundRect(RectF(0f, 0f, w, h), h / 2, h / 2, p)
        val r = h / 2 - context.dp(2)
        val cx = if (checked) w - h / 2 else h / 2
        p.color = Color.parseColor("#33000000")
        c.drawCircle(cx, h / 2 + 1.5f, r, p)
        p.color = Color.WHITE
        c.drawCircle(cx, h / 2, r, p)
    }
}

/** Row: label (+ small description) on one side and an iOS switch on the other. */
fun Context.switchRow(text: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Boolean): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(8), 0, dp(8))
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(text, 15f, Color.WHITE))
            if (sub != null) addView(label(sub, 12f, LABEL2).apply { setPadding(0, dp(2), 0, 0) })
        }
        addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            .apply { marginEnd = dp(12) })
        val sw = IosSwitch(context).apply { this.checked = checked }
        sw.onToggle = { want -> if (onChange(want)) sw.checked = want }
        addView(sw)
    }

/** Slider with a thin glass track and white knob; shows the value on the side. */
class IosSlider(
    context: Context, private val min: Int, private val max: Int, value: Int,
    private val onChange: (Int) -> Unit
) : View(context) {
    var accent = IOS_BLUE
    var value = value.coerceIn(min, max)
        set(v) { field = v.coerceIn(min, max); invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) =
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(36))
    override fun onDraw(c: Canvas) {
        val pad = context.dp(14).toFloat()
        val cy = height / 2f
        val tw = width - pad * 2
        val frac = (value - min).toFloat() / (max - min)
        p.color = Color.parseColor("#33FFFFFF")
        c.drawRoundRect(RectF(pad, cy - 3.5f * resources.displayMetrics.density, pad + tw, cy + 3.5f * resources.displayMetrics.density), 20f, 20f, p)
        p.color = accent
        c.drawRoundRect(RectF(pad, cy - 3.5f * resources.displayMetrics.density, pad + tw * frac, cy + 3.5f * resources.displayMetrics.density), 20f, 20f, p)
        val kx = pad + tw * frac
        p.color = Color.parseColor("#40000000")
        c.drawCircle(kx, cy + 2f, context.dp(13).toFloat(), p)
        p.color = Color.WHITE
        c.drawCircle(kx, cy, context.dp(13).toFloat(), p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            val pad = context.dp(14).toFloat()
            val f = ((e.x - pad) / (width - pad * 2)).coerceIn(0f, 1f)
            val nv = min + Math.round(f * (max - min))
            if (nv != value) { value = nv; onChange(nv) }
            return true
        }
        return e.action == MotionEvent.ACTION_UP
    }
}

/** Labelled slider row: title + live value + slider. */
fun Context.sliderRow(title: String, min: Int, max: Int, value: Int, unit: String = "", accent: Int = IOS_BLUE, onChange: (Int) -> Unit): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val head = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val t = label(title, 14f, Color.WHITE)
        val v = label("$value$unit", 14f, LABEL2)
        head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(v)
        addView(head)
        addView(IosSlider(context, min, max, value) { nv ->
            v.text = "$nv$unit"
            onChange(nv)
        }.also { it.accent = accent })
        setPadding(0, dp(8), 0, dp(2))
    }

/** Flat glyphs drawn in code (SF-Symbols look) so no emoji/text glyphs are needed. */
class IconView(context: Context, var kind: Int, var tint: Int = Color.WHITE) : View(context) {
    companion object {
        const val PLAY = 0; const val PAUSE = 1; const val STOP = 2; const val REC = 3; const val CLOSE = 4
        const val FRAMES = 5; const val TEMP = 6; const val BATT = 7; const val CROSS = 8
        const val UP = 9; const val DOWN = 10; const val LEFT = 11; const val RIGHT = 12
        const val MINUS = 13; const val PLUS = 14; const val SETTINGS = 15
        const val SHOT = 16; const val TAP = 17; const val SUN = 18; const val RING = 19
        const val HOME = 20; const val EYE = 21; const val EYE_OFF = 22
    }
    /** Battery fill (0..1) and charging bolt, used by [BATT]. */
    var level = 1f
        set(v) { if (field != v) { field = v; invalidate() } }
    var charging = false
        set(v) { if (field != v) { field = v; invalidate() } }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun set(k: Int, c: Int = tint) { if (kind != k || tint != c) { kind = k; tint = c; invalidate() } }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = min(w, h); val cx = w / 2; val cy = h / 2
        val x0 = cx - s / 2; val y0 = cy - s / 2          // top-left of the square the glyph lives in
        p.color = tint; p.style = Paint.Style.FILL
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            PLAY -> {
                val path = Path().apply {
                    moveTo(cx - s * 0.17f, cy - s * 0.24f)
                    lineTo(cx + s * 0.27f, cy)
                    lineTo(cx - s * 0.17f, cy + s * 0.24f); close()
                }
                p.strokeWidth = s * 0.08f
                p.style = Paint.Style.FILL_AND_STROKE
                c.drawPath(path, p)
            }
            PAUSE -> {
                val bw = s * 0.12f; val bh = s * 0.46f
                c.drawRoundRect(RectF(cx - bw * 1.7f, cy - bh / 2, cx - bw * 0.5f, cy + bh / 2), bw / 2, bw / 2, p)
                c.drawRoundRect(RectF(cx + bw * 0.5f, cy - bh / 2, cx + bw * 1.7f, cy + bh / 2), bw / 2, bw / 2, p)
            }
            STOP -> { val a = s * 0.21f; c.drawRoundRect(RectF(cx - a, cy - a, cx + a, cy + a), a * 0.35f, a * 0.35f, p) }
            REC -> c.drawCircle(cx, cy, s * 0.26f, p)
            CLOSE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.09f
                val a = s * 0.17f
                c.drawLine(cx - a, cy - a, cx + a, cy + a, p); c.drawLine(cx + a, cy - a, cx - a, cy + a, p)
            }
            FRAMES -> {
                // two overlapping rounded squares: outlined one behind, solid one in front
                val r = s * 0.14f
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.09f
                p.color = (tint and 0x00FFFFFF) or 0xB3000000.toInt()
                c.drawRoundRect(RectF(x0 + s * 0.10f, y0 + s * 0.08f, x0 + s * 0.60f, y0 + s * 0.58f), r, r, p)
                p.style = Paint.Style.FILL; p.color = tint
                c.drawRoundRect(RectF(x0 + s * 0.36f, y0 + s * 0.36f, x0 + s * 0.92f, y0 + s * 0.92f), r, r, p)
            }
            TEMP -> {
                // thermometer: stem + bulb + two ticks
                c.drawRoundRect(RectF(cx - s * 0.10f, y0 + s * 0.08f, cx + s * 0.10f, y0 + s * 0.68f), s * 0.10f, s * 0.10f, p)
                c.drawCircle(cx, y0 + s * 0.76f, s * 0.20f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawLine(cx + s * 0.20f, y0 + s * 0.20f, cx + s * 0.34f, y0 + s * 0.20f, p)
                c.drawLine(cx + s * 0.20f, y0 + s * 0.38f, cx + s * 0.34f, y0 + s * 0.38f, p)
            }
            BATT -> {
                val bl = x0 + s * 0.04f; val br = x0 + s * 0.86f
                val bt = cy - s * 0.22f; val bb = cy + s * 0.22f
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawRoundRect(RectF(bl, bt, br, bb), s * 0.10f, s * 0.10f, p)
                p.style = Paint.Style.FILL
                c.drawRoundRect(RectF(br + s * 0.03f, cy - s * 0.08f, br + s * 0.10f, cy + s * 0.08f), s * 0.03f, s * 0.03f, p)
                val inset = s * 0.07f
                val fw = (br - bl - inset * 2) * level.coerceIn(0f, 1f)
                if (fw > 0f) c.drawRoundRect(RectF(bl + inset, bt + inset, bl + inset + fw, bb - inset), s * 0.04f, s * 0.04f, p)
                if (charging) {
                    p.color = Color.WHITE
                    c.drawPath(Path().apply {
                        val mx = (bl + br) / 2
                        moveTo(mx + s * 0.04f, cy - s * 0.20f); lineTo(mx - s * 0.10f, cy + s * 0.02f)
                        lineTo(mx - s * 0.01f, cy + s * 0.02f); lineTo(mx - s * 0.04f, cy + s * 0.20f)
                        lineTo(mx + s * 0.10f, cy - s * 0.03f); lineTo(mx + s * 0.01f, cy - s * 0.03f); close()
                    }, p)
                }
            }
            CROSS -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.08f
                c.drawCircle(cx, cy, s * 0.20f, p)
                val a = s * 0.28f; val b = s * 0.40f
                c.drawLine(cx - b, cy, cx - a, cy, p); c.drawLine(cx + a, cy, cx + b, cy, p)
                c.drawLine(cx, cy - b, cx, cy - a, p); c.drawLine(cx, cy + a, cx, cy + b, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * 0.045f, p)
            }
            UP, DOWN, LEFT, RIGHT -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.10f
                val a = s * 0.17f; val b = s * 0.09f
                val path = Path()
                when (kind) {
                    UP -> { path.moveTo(cx - a, cy + b); path.lineTo(cx, cy - b); path.lineTo(cx + a, cy + b) }
                    DOWN -> { path.moveTo(cx - a, cy - b); path.lineTo(cx, cy + b); path.lineTo(cx + a, cy - b) }
                    LEFT -> { path.moveTo(cx + b, cy - a); path.lineTo(cx - b, cy); path.lineTo(cx + b, cy + a) }
                    else -> { path.moveTo(cx - b, cy - a); path.lineTo(cx + b, cy); path.lineTo(cx - b, cy + a) }
                }
                c.drawPath(path, p)
            }
            SHOT -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawRoundRect(RectF(x0 + s * 0.12f, y0 + s * 0.28f, x0 + s * 0.88f, y0 + s * 0.80f), s * 0.10f, s * 0.10f, p)
                c.drawLine(x0 + s * 0.36f, y0 + s * 0.28f, x0 + s * 0.42f, y0 + s * 0.18f, p)
                c.drawLine(x0 + s * 0.42f, y0 + s * 0.18f, x0 + s * 0.58f, y0 + s * 0.18f, p)
                c.drawLine(x0 + s * 0.58f, y0 + s * 0.18f, x0 + s * 0.64f, y0 + s * 0.28f, p)
                c.drawCircle(cx, y0 + s * 0.54f, s * 0.13f, p)
            }
            TAP -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * 0.10f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawCircle(cx, cy, s * 0.24f, p)
                p.color = (tint and 0x00FFFFFF) or 0x80000000.toInt()
                c.drawCircle(cx, cy, s * 0.38f, p)
            }
            SUN -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawCircle(cx, cy, s * 0.14f, p)
                for (k in 0 until 8) {
                    val a = Math.toRadians(45.0 * k)
                    val ca = Math.cos(a).toFloat(); val sa = Math.sin(a).toFloat()
                    c.drawLine(cx + ca * s * 0.24f, cy + sa * s * 0.24f, cx + ca * s * 0.36f, cy + sa * s * 0.36f, p)
                }
            }
            RING -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.08f
                c.drawCircle(cx, cy, s * 0.30f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * 0.12f, p)
            }
            SETTINGS -> {
                // three sliders: line + knob
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                val a = s * 0.26f
                for (i in -1..1) c.drawLine(cx - a, cy + i * s * 0.20f, cx + a, cy + i * s * 0.20f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx + s * 0.10f, cy - s * 0.20f, s * 0.07f, p)
                c.drawCircle(cx - s * 0.12f, cy, s * 0.07f, p)
                c.drawCircle(cx + s * 0.06f, cy + s * 0.20f, s * 0.07f, p)
            }
            HOME -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.08f
                c.drawPath(Path().apply {
                    moveTo(cx - s * 0.33f, cy - s * 0.02f); lineTo(cx, cy - s * 0.32f); lineTo(cx + s * 0.33f, cy - s * 0.02f)
                    moveTo(cx - s * 0.22f, cy - s * 0.12f); lineTo(cx - s * 0.22f, cy + s * 0.30f)
                    lineTo(cx + s * 0.22f, cy + s * 0.30f); lineTo(cx + s * 0.22f, cy - s * 0.12f)
                }, p)
            }
            EYE, EYE_OFF -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.07f
                c.drawOval(RectF(cx - s * 0.36f, cy - s * 0.21f, cx + s * 0.36f, cy + s * 0.21f), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * 0.09f, p)
                if (kind == EYE_OFF) {
                    p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.08f
                    c.drawLine(cx - s * 0.30f, cy + s * 0.30f, cx + s * 0.30f, cy - s * 0.30f, p)
                }
            }
            MINUS, PLUS -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.10f
                val a = s * 0.18f
                c.drawLine(cx - a, cy, cx + a, cy, p)
                if (kind == PLUS) c.drawLine(cx, cy - a, cx, cy + a, p)
            }
        }
    }
}

/** Round glass button with an icon. */
fun Context.glassCircle(sizeDp: Int, kind: Int, fill: Int = Color.parseColor("#B31C1C1E"), tint: Int = Color.WHITE): android.widget.FrameLayout =
    android.widget.FrameLayout(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke(dp(1), Color.parseColor("#40FFFFFF"))
        }
        addView(IconView(context, kind, tint), android.widget.FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp)))
        minimumWidth = dp(sizeDp); minimumHeight = dp(sizeDp)
    }

/** Big round record button. state: 0 idle, 1 recording, 2 paused. [timeText] replaces the glyph while recording. */
class RecordButton(context: Context, private val sizeDp: Int = 92) : View(context) {
    var state = 0
        set(v) { if (field != v) { field = v; invalidate() } }
    var timeText: String? = null
        set(v) { if (field != v) { field = v; invalidate() } }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = context.dp(sizeDp) * 0.045f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    override fun onMeasure(w: Int, h: Int) { val s = context.dp(sizeDp); setMeasuredDimension(s, s) }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = width / 2f - ring.strokeWidth
        ring.color = Color.parseColor("#E6FFFFFF")
        c.drawCircle(cx, cy, r, ring)
        fill.style = Paint.Style.FILL
        val t = timeText
        if (state != 0 && t != null) {
            txt.color = if (state == 2) IOS_ORANGE else IOS_RED
            txt.textSize = r * 0.46f
            c.drawText(t, cx, cy - (txt.ascent() + txt.descent()) / 2f, txt)
            return
        }
        when (state) {
            0 -> { fill.color = IOS_RED; c.drawCircle(cx, cy, r * 0.80f, fill) }
            1 -> { fill.color = IOS_RED; val h = r * 0.40f
                c.drawRoundRect(RectF(cx - h, cy - h, cx + h, cy + h), h * 0.4f, h * 0.4f, fill) }
            else -> { fill.color = IOS_ORANGE; val bw = r * 0.16f; val bh = r * 0.5f
                c.drawRoundRect(RectF(cx - bw * 2f, cy - bh, cx - bw * 0.5f, cy + bh), bw / 2, bw / 2, fill)
                c.drawRoundRect(RectF(cx + bw * 0.5f, cy - bh, cx + bw * 2f, cy + bh), bw / 2, bw / 2, fill) }
        }
    }
}
