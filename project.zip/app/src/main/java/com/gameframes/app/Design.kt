package com.gameframes.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

val CARD = Color.parseColor("#121821")
val CARD_STROKE = Color.parseColor("#1f2a37")
val CHIP = Color.parseColor("#1b2430")
val ACCENT = Color.parseColor("#4ade80")
val ACCENT_DARK = Color.parseColor("#04210f")
val REC_RED = Color.parseColor("#ef4444")
val AMBER = Color.parseColor("#fbbf24")

fun Context.rounded(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

/** A rounded card with a title; children are added with [addView] by the caller. */
fun Context.card(title: String? = null, subtitle: String? = null): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 18, CARD_STROKE, 1)
        setPadding(dp(14), dp(12), dp(14), dp(14))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, dp(6), 0, dp(6)) }
        layoutParams = lp
        if (title != null) {
            addView(label(title, 15f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        }
        if (subtitle != null) {
            addView(label(subtitle, 12f, MUTE).apply { setPadding(0, dp(2), 0, dp(4)) })
        }
    }

/** Small grey caption above a row of chips. */
fun Context.caption(text: String): TextView =
    label(text, 12f, MUTE).apply { setPadding(dp(2), dp(10), 0, dp(2)) }

/** Horizontal, scrollable row of selectable chips (one selected at a time). */
class ChipRow(
    context: Context,
    items: List<String>,
    selected: Int,
    private val onSelect: (Int) -> Unit
) : HorizontalScrollView(context) {

    var index = selected
        private set
    private val chips = ArrayList<TextView>()

    init {
        isHorizontalScrollBarEnabled = false
        val box = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEachIndexed { i, t ->
            val tv = TextView(context).apply {
                text = t
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(context.dp(14), context.dp(9), context.dp(14), context.dp(9))
                setOnClickListener { select(i, true) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(context.dp(3), context.dp(2), context.dp(3), context.dp(2)) }
            box.addView(tv, lp)
            chips.add(tv)
        }
        addView(box)
        paint()
    }

    fun select(i: Int, notify: Boolean) {
        if (i < 0 || i >= chips.size) return
        index = i
        paint()
        if (notify) onSelect(i)
    }

    private fun paint() {
        chips.forEachIndexed { i, tv ->
            val on = i == index
            tv.background = context.rounded(if (on) ACCENT else CHIP, 12)
            tv.setTextColor(if (on) ACCENT_DARK else Color.WHITE)
            tv.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }
}

/** Big round record button: red dot when idle, square when recording, bars when paused. */
class RecordButton(context: Context) : View(context) {

    /** 0 idle, 1 recording, 2 paused */
    var state = 0
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dp(4).toFloat()
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = context.dp(96)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - ring.strokeWidth
        ring.color = when (state) {
            1 -> REC_RED
            2 -> AMBER
            else -> ACCENT
        }
        canvas.drawCircle(cx, cy, r, ring)
        when (state) {
            0 -> {
                fill.color = REC_RED
                canvas.drawCircle(cx, cy, r * 0.62f, fill)
            }
            1 -> {
                fill.color = Color.WHITE
                val h = r * 0.42f
                canvas.drawRoundRect(RectF(cx - h, cy - h, cx + h, cy + h), h * 0.3f, h * 0.3f, fill)
            }
            else -> {
                fill.color = AMBER
                val bw = r * 0.2f
                val bh = r * 0.5f
                canvas.drawRoundRect(RectF(cx - bw * 1.8f, cy - bh, cx - bw * 0.6f, cy + bh), 6f, 6f, fill)
                canvas.drawRoundRect(RectF(cx + bw * 0.6f, cy - bh, cx + bw * 1.8f, cy + bh), 6f, 6f, fill)
            }
        }
    }
}
